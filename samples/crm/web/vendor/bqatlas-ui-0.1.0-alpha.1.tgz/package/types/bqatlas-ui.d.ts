import * as _angular_core from '@angular/core';
import { InjectionToken, Type, WritableSignal, OnInit, Injector, AfterViewInit, OnDestroy, TemplateRef, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { FormValueControl, FormCheckboxControl } from '@angular/forms/signals';

declare class AtlasIcon {
    name: _angular_core.InputSignal<string>;
    readonly paths: Record<string, string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasIcon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasIcon, "atlas-icon", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasButton {
    variant: _angular_core.InputSignal<"primary" | "secondary" | "ghost" | "danger">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasButton, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasButton, "button[atlasButton], a[atlasButton]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasInput {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasInput, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasInput, "input[atlasInput], textarea[atlasInput], select[atlasInput]", never, {}, {}, never, never, true, never>;
}
declare class AtlasBadge {
    tone: _angular_core.InputSignal<"danger" | "neutral" | "success" | "warning" | "info">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasBadge, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasBadge, "atlas-badge", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class AtlasPanel {
    title: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasPanel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasPanel, "atlas-panel", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; }, {}, never, ["[panelActions]", "[panelToolbar]", "*", "[panelFooter]"], true, never>;
}
declare class AtlasField {
    label: _angular_core.InputSignal<string>;
    controlId: _angular_core.InputSignal<string>;
    required: _angular_core.InputSignal<boolean>;
    hint: _angular_core.InputSignal<string>;
    error: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasField, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasField, "atlas-field", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface WindowBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}
interface ScreenDefinition {
    id: string;
    title: string;
    icon: string;
    component: Type<unknown>;
    instance: "singleton" | "keyed" | "multiple";
    width?: number;
    height?: number;
}
interface OpenTask<T = unknown> {
    screen: string;
    key?: string;
    title?: string;
    data: T;
    origin?: string;
}
interface WorkspaceTask<T = unknown> {
    id: string;
    screen: string;
    key?: string;
    title: string;
    icon: string;
    component: Type<unknown>;
    data: WritableSignal<T>;
    dirty: WritableSignal<boolean>;
    saving: WritableSignal<boolean>;
    error: WritableSignal<string>;
    bounds: WindowBounds;
    mode: "floating" | "maximized";
    minimized: boolean;
    origin?: string;
    lifecycle: {
        save?: () => Promise<void>;
        dispose?: () => void;
    };
}
declare const ATLAS_TASK: InjectionToken<WorkspaceTask<unknown>>;
/** Presentation-independent task identity and lifecycle. No ERP or HTTP dependencies. */
declare class WorkspaceService {
    private readonly definitions;
    private sequence;
    readonly tasks: WritableSignal<WorkspaceTask<unknown>[]>;
    readonly activeId: WritableSignal<string | null>;
    readonly stackOrder: WritableSignal<string[]>;
    readonly pendingClose: WritableSignal<string | null>;
    private closeQueue;
    readonly closingAll: WritableSignal<boolean>;
    readonly hasPendingWork: _angular_core.Signal<boolean>;
    readonly active: _angular_core.Signal<WorkspaceTask<unknown> | null>;
    readonly closing: _angular_core.Signal<WorkspaceTask<unknown> | null>;
    readonly viewport: WritableSignal<{
        width: number;
        height: number;
    }>;
    readonly mobile: WritableSignal<boolean>;
    readonly history: string[];
    register(...definitions: ScreenDefinition[]): void;
    open<T>(request: OpenTask<T>): WorkspaceTask<T>;
    activate(id: string): void;
    minimize(id: string): void;
    toggleMaximize(id: string): void;
    move(id: string, bounds: WindowBounds): void;
    snap(id: string, side: "left" | "right"): void;
    setViewport(width: number, height: number, mobile: boolean): void;
    clamp(bounds: WindowBounds): WindowBounds;
    /** Close a snapshot sequentially through the existing save/discard/cancel dialog. */
    requestCloseAll(): boolean;
    private advanceCloseAll;
    requestClose(id: string): Promise<void>;
    cancelClose(): void;
    discardClose(): void;
    save(id: string): Promise<boolean>;
    saveAndClose(): Promise<void>;
    back(): void;
    showDesktop(): void;
    cascade(): void;
    /** Discard all retained task state when the authenticated session ends. */
    disposeAll(): void;
    rekey(id: string, key: string): void;
    private topVisible;
    private patch;
    private remove;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<WorkspaceService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}

declare class AtlasWindow implements OnInit {
    readonly task: _angular_core.InputSignal<WorkspaceTask<unknown>>;
    readonly layer: _angular_core.InputSignal<number>;
    readonly ws: WorkspaceService;
    private readonly parent;
    private readonly element;
    taskInjector: Injector;
    readonly edges: string[];
    private drag;
    ngOnInit(): void;
    activate(): void;
    saveShortcut(event: Event): void;
    maximize(event: MouseEvent): void;
    start(event: PointerEvent, edge: string): void;
    move(event: PointerEvent): void;
    end(event: PointerEvent): void;
    resizeKey(event: KeyboardEvent): void;
    moveKey(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasWindow, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasWindow, "atlas-window", never, { "task": { "alias": "task"; "required": true; "isSignal": true; }; "layer": { "alias": "layer"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtlasWorkspace implements AfterViewInit, OnDestroy {
    readonly ws: WorkspaceService;
    readonly positions: readonly ["top", "left", "right", "bottom"];
    readonly settingsOpen: _angular_core.WritableSignal<boolean>;
    readonly pendingDock: _angular_core.WritableSignal<"left" | "right" | "top" | "bottom">;
    private readonly taskbarMenu;
    private readonly settingsButton;
    openSettings(): void;
    applySettings(): void;
    chooseDock(position: string): void;
    dismissTaskbarMenu(event: PointerEvent): void;
    openTaskbarMenu(event: MouseEvent): void;
    showTaskbarMenu(x: number, y: number): void;
    taskbarKey(event: KeyboardEvent): void;
    menuKey(event: KeyboardEvent): void;
    readonly forceMobile: _angular_core.InputSignal<boolean>;
    readonly dock: _angular_core.WritableSignal<"left" | "right" | "top" | "bottom">;
    setDock(value: string): void;
    private readonly canvas;
    private readonly confirm;
    private observer?;
    private readonly element;
    private readonly focusTargets;
    private destroyed;
    guardPageExit(event: BeforeUnloadEvent): void;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    rememberFocus(event: FocusEvent): void;
    measure(): void;
    home(): void;
    cancel(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasWorkspace, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasWorkspace, "atlas-workspace", never, { "forceMobile": { "alias": "forceMobile"; "required": false; "isSignal": true; }; }, {}, never, ["*", "[atlasWorkspaceLauncher]"], true, never>;
}

/** JSON-serializable, backend-independent collection request. Pages are zero based. */
interface AtlasSort {
    key: string;
    direction: "asc" | "desc";
}
interface AtlasTableQuery {
    page: number;
    pageSize: number;
    search: string;
    filters: Record<string, string>;
    sort: AtlasSort[];
}
declare function sortByColumns<T>(rows: readonly T[], sorts: readonly AtlasSort[], value: (row: T, key: string) => unknown): T[];
declare function matchesColumnFilters<T>(row: T, filters: Record<string, string>, value: (row: T, key: string) => string): boolean;
/** Cancels previous work and rejects stale completions even when an adapter ignores AbortSignal. */
declare class AtlasLatestRequest {
    private controller?;
    run<T>(request: (signal: AbortSignal) => Promise<T>, accept: (result: T) => void, reject: (error: unknown) => void): Promise<void>;
    cancel(): void;
}

interface AtlasSummary<T> {
    key: string;
    label: string;
    /** Receives a precise scope: current page/group or all locally filtered rows. */
    aggregate: (rows: readonly T[]) => string;
}
interface AtlasServerSummary {
    /** Echo the request token; stale responses are never displayed. */
    queryKey: string;
    scope: "query";
    values: Readonly<Record<string, string>>;
}
declare function atlasSummaryQueryKey(query: AtlasTableQuery): string;
declare function atlasHeaderBands(columns: readonly {
    group?: string;
}[]): {
    label: string;
    span: number;
}[];
declare function atlasGroupRows<T>(rows: readonly T[], key: (row: T) => string): {
    key: string;
    rows: T[];
}[];
/** Exact fixed-scale signed decimal sum. Invalid precision is rejected, never rounded. */
declare function atlasSumDecimal(values: readonly string[], scale?: number): string;

interface AtlasColumn<T> {
    group?: string;
    width?: number;
    filterable?: boolean;
    key: keyof T & string;
    label: string;
    format?: (row: T) => string;
    sortValue?: (row: T) => string | number;
    badge?: boolean;
    tone?: (row: T) => "neutral" | "success" | "warning" | "info" | "danger";
    align?: "left" | "right";
    sortable?: boolean;
}
interface AtlasCellContext<T> {
    $implicit: T;
    value: unknown;
}
declare class AtlasCell<T> {
    key: _angular_core.InputSignal<string>;
    /** Supplies the row type to Angular's template checker. */
    rows: _angular_core.InputSignal<readonly T[]>;
    template: TemplateRef<AtlasCellContext<T>>;
    static ngTemplateContextGuard<T>(_directive: AtlasCell<T>, context: unknown): context is AtlasCellContext<T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasCell<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasCell<any>, "ng-template[atlasCell]", never, { "key": { "alias": "atlasCell"; "required": true; "isSignal": true; }; "rows": { "alias": "atlasCellOf"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasRowDetail<T> {
    rows: _angular_core.InputSignal<readonly T[]>;
    template: TemplateRef<{
        $implicit: T;
    }>;
    static ngTemplateContextGuard<T>(_directive: AtlasRowDetail<T>, context: unknown): context is {
        $implicit: T;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasRowDetail<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasRowDetail<any>, "ng-template[atlasRowDetail]", never, { "rows": { "alias": "atlasRowDetailOf"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasTable<T extends object> {
    readonly groupBy: _angular_core.InputSignal<(keyof T & string) | null>;
    readonly summaries: _angular_core.InputSignal<readonly AtlasSummary<T>[]>;
    readonly serverSummary: _angular_core.InputSignal<AtlasServerSummary | null>;
    readonly collapsedGroups: _angular_core.ModelSignal<string[]>;
    readonly hasHeaderGroups: _angular_core.Signal<boolean>;
    readonly headerBands: _angular_core.Signal<{
        label: string;
        span: number;
    }[]>;
    readonly pageGroups: _angular_core.Signal<{
        key: string;
        rows: T[];
    }[]>;
    readonly acceptedServerSummary: _angular_core.Signal<AtlasServerSummary | null>;
    toggleGroup(key: string): void;
    rows: _angular_core.InputSignal<T[]>;
    columns: _angular_core.InputSignal<AtlasColumn<T>[]>;
    keyField: _angular_core.InputSignal<keyof T>;
    pageSize: _angular_core.InputSignal<number>;
    rowActivated: _angular_core.OutputEmitterRef<T>;
    private cells;
    readonly templates: _angular_core.Signal<Map<string, TemplateRef<AtlasCellContext<any>>>>;
    readonly sorts: _angular_core.WritableSignal<AtlasSort[]>;
    readonly addSort: _angular_core.WritableSignal<boolean>;
    readonly page: _angular_core.WritableSignal<number>;
    readonly columnFilters: _angular_core.InputSignal<boolean>;
    readonly multiSort: _angular_core.InputSignal<boolean>;
    readonly columnManage: _angular_core.InputSignal<boolean>;
    readonly server: _angular_core.InputSignal<boolean>;
    readonly total: _angular_core.InputSignal<number>;
    readonly error: _angular_core.InputSignal<string>;
    readonly retry: _angular_core.OutputEmitterRef<void>;
    readonly queryChange: _angular_core.OutputEmitterRef<AtlasTableQuery>;
    readonly filters: _angular_core.WritableSignal<Record<string, string>>;
    readonly order: _angular_core.WritableSignal<string[]>;
    readonly widths: _angular_core.WritableSignal<Record<string, number>>;
    readonly pinned: _angular_core.WritableSignal<string[]>;
    readonly expanded: _angular_core.WritableSignal<string[]>;
    readonly detail: _angular_core.Signal<AtlasRowDetail<any> | undefined>;
    readonly orderedColumns: _angular_core.Signal<AtlasColumn<T>[]>;
    readonly request: _angular_core.Signal<AtlasTableQuery>;
    constructor();
    readonly tableWidth: _angular_core.Signal<number>;
    selected: _angular_core.WritableSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly filterable: _angular_core.InputSignal<boolean>;
    readonly selectable: _angular_core.InputSignal<boolean>;
    readonly columnToggle: _angular_core.InputSignal<boolean>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly selectedKeys: _angular_core.ModelSignal<string[]>;
    readonly query: _angular_core.WritableSignal<string>;
    readonly hiddenColumns: _angular_core.WritableSignal<string[]>;
    readonly visibleColumns: _angular_core.Signal<AtlasColumn<T>[]>;
    readonly filtered: _angular_core.Signal<T[]>;
    readonly sorted: _angular_core.Signal<T[]>;
    readonly totalRecords: _angular_core.Signal<number>;
    readonly pagination: _angular_core.Signal<{
        items: T[];
        page: number;
        pages: number;
        total: number;
        size: number;
    }>;
    readonly pageCount: _angular_core.Signal<number>;
    readonly safePage: _angular_core.Signal<number>;
    readonly paged: _angular_core.Signal<T[]>;
    readonly allPageSelected: _angular_core.Signal<boolean>;
    readonly somePageSelected: _angular_core.Signal<boolean>;
    search(query: string): void;
    toggleColumn(key: string): void;
    toggleRow(row: T): void;
    togglePage(): void;
    sort(key: keyof T & string, append?: boolean): void;
    clearSort(): void;
    sortIndex(key: string): number;
    sortDirection(key: string): "none" | "other" | "ascending" | "descending";
    filterColumn(key: string, value: string): void;
    width(column: AtlasColumn<T>): number;
    setWidth(key: string, value: number): void;
    moveColumn(key: string, delta: number): void;
    pin(key: string): void;
    pinOffset(key: string): number | null;
    toggleDetail(row: T): void;
    private resizing?;
    resizeStart(event: PointerEvent, column: AtlasColumn<T>): void;
    resizeMove(event: PointerEvent): void;
    resizeEnd(event: PointerEvent): void;
    rowKey(row: T): string;
    value(row: T, column: AtlasColumn<T>): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTable<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTable<any>, "atlas-table", never, { "groupBy": { "alias": "groupBy"; "required": false; "isSignal": true; }; "summaries": { "alias": "summaries"; "required": false; "isSignal": true; }; "serverSummary": { "alias": "serverSummary"; "required": false; "isSignal": true; }; "collapsedGroups": { "alias": "collapsedGroups"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "keyField": { "alias": "keyField"; "required": true; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "columnFilters": { "alias": "columnFilters"; "required": false; "isSignal": true; }; "multiSort": { "alias": "multiSort"; "required": false; "isSignal": true; }; "columnManage": { "alias": "columnManage"; "required": false; "isSignal": true; }; "server": { "alias": "server"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "columnToggle": { "alias": "columnToggle"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "selectedKeys": { "alias": "selectedKeys"; "required": false; "isSignal": true; }; }, { "collapsedGroups": "collapsedGroupsChange"; "rowActivated": "rowActivated"; "retry": "retry"; "queryChange": "queryChange"; "selectedKeys": "selectedKeysChange"; }, ["cells", "detail"], never, true, never>;
}

/** Shared collection behavior for list and table presentations. Never mutates consumer data. */
declare function filterCollection<T>(rows: readonly T[], query: string, text: (row: T) => string): T[];
declare function sortCollection<T>(rows: readonly T[], value: (row: T) => unknown, direction?: "asc" | "desc"): T[];
declare function pageCollection<T>(rows: readonly T[], page: number, pageSize: number): {
    items: T[];
    page: number;
    pages: number;
    total: number;
    size: number;
};
interface AtlasOption<T = string> {
    label: string;
    value: T;
    description?: string;
    group?: string;
    disabled?: boolean;
}

/** Shared forms contract; presentation can be native, Atlas, or an adapter. */
declare abstract class AtlasValueControl<T> implements ControlValueAccessor {
    readonly controlId: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly value: _angular_core.WritableSignal<T | null>;
    readonly disabled: _angular_core.WritableSignal<boolean>;
    private change;
    private touch;
    writeValue(value: T | null): void;
    registerOnChange(callback: (value: T | null) => void): void;
    registerOnTouched(callback: () => void): void;
    setDisabledState(disabled: boolean): void;
    protected commit(value: T | null): void;
    markTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasValueControl<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasValueControl<any>, never, never, { "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtlasTextInput extends AtlasValueControl<string> {
    readonly type: _angular_core.InputSignal<"search" | "text" | "email" | "password" | "tel" | "url">;
    readonly icon: _angular_core.InputSignal<string>;
    readonly prefix: _angular_core.InputSignal<string>;
    readonly suffix: _angular_core.InputSignal<string>;
    readonly clearable: _angular_core.InputSignal<boolean>;
    readonly autocomplete: _angular_core.InputSignal<string>;
    readonly maxLength: _angular_core.InputSignal<number | null>;
    readonly revealed: _angular_core.WritableSignal<boolean>;
    edit(value: string): void;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTextInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTextInput, "atlas-text-input", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasNumberInput extends AtlasValueControl<number> {
    readonly min: _angular_core.InputSignal<number | null>;
    readonly max: _angular_core.InputSignal<number | null>;
    readonly step: _angular_core.InputSignal<number>;
    readonly prefix: _angular_core.InputSignal<string>;
    readonly suffix: _angular_core.InputSignal<string>;
    readonly showButtons: _angular_core.InputSignal<boolean>;
    edit(value: string): void;
    increment(direction: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasNumberInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasNumberInput, "atlas-number-input", never, { "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "showButtons": { "alias": "showButtons"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtlasSelect<T = string> extends AtlasValueControl<T> implements OnDestroy {
    readonly options: _angular_core.InputSignal<AtlasOption<T>[]>;
    readonly filter: _angular_core.InputSignal<boolean>;
    readonly clearable: _angular_core.InputSignal<boolean>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly query: _angular_core.WritableSignal<string>;
    readonly opened: _angular_core.WritableSignal<boolean>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly selected: _angular_core.Signal<AtlasOption<T> | undefined>;
    readonly filtered: _angular_core.Signal<AtlasOption<T>[]>;
    private readonly trigger;
    private readonly popup;
    private readonly search;
    private readonly onScroll;
    toggle(): void;
    open(): void;
    close(focus: boolean): void;
    toggled(event: Event): void;
    blur(): void;
    clear(): void;
    choose(option: AtlasOption<T>): void;
    hover(index: number): void;
    searchFor(query: string): void;
    key(event: KeyboardEvent): void;
    setDisabledState(disabled: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasSelect<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasSelect<any>, "atlas-select", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface AtlasListItem {
    id: string;
    title: string;
    description?: string;
    meta?: string;
    icon?: string;
    badge?: string;
    tone?: "neutral" | "success" | "warning" | "info" | "danger";
    disabled?: boolean;
}
declare class AtlasListTemplate {
    template: TemplateRef<{
        $implicit: AtlasListItem;
        selected: boolean;
    }>;
    static ngTemplateContextGuard(_directive: AtlasListTemplate, context: unknown): context is {
        $implicit: AtlasListItem;
        selected: boolean;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasListTemplate, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasListTemplate, "ng-template[atlasListTemplate]", never, {}, {}, never, never, true, never>;
}
declare class AtlasListView {
    readonly itemTemplate: _angular_core.Signal<AtlasListTemplate | undefined>;
    readonly tabstop: _angular_core.Signal<string | undefined>;
    readonly items: _angular_core.InputSignal<AtlasListItem[]>;
    readonly label: _angular_core.InputSignal<string>;
    readonly layout: _angular_core.InputSignal<"grid" | "list">;
    readonly filterable: _angular_core.InputSignal<boolean>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly pageSize: _angular_core.InputSignal<number>;
    readonly selectedId: _angular_core.ModelSignal<string | null>;
    readonly selectionChange: _angular_core.OutputEmitterRef<AtlasListItem>;
    readonly itemActivated: _angular_core.OutputEmitterRef<AtlasListItem>;
    readonly query: _angular_core.WritableSignal<string>;
    readonly page: _angular_core.WritableSignal<number>;
    readonly focusId: _angular_core.WritableSignal<string | null>;
    readonly filtered: _angular_core.Signal<AtlasListItem[]>;
    readonly paged: _angular_core.Signal<{
        items: AtlasListItem[];
        page: number;
        pages: number;
        total: number;
        size: number;
    }>;
    readonly firstEnabled: _angular_core.Signal<number>;
    search(query: string): void;
    changePage(delta: number): void;
    select(item: AtlasListItem): void;
    key(event: KeyboardEvent, item: AtlasListItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasListView, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasListView, "atlas-list-view", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; }, { "selectedId": "selectedIdChange"; "selectionChange": "selectionChange"; "itemActivated": "itemActivated"; }, ["itemTemplate"], never, true, never>;
}

interface AtlasStartItem {
    id: string;
    label: string;
    icon: string;
    separatorBefore?: boolean;
    disabled?: boolean;
}
declare class AtlasStartMenu {
    readonly label: _angular_core.InputSignal<string>;
    readonly accountName: _angular_core.InputSignal<string>;
    readonly accountSelected: _angular_core.OutputEmitterRef<void>;
    openAccount(): void;
    readonly accountActions: _angular_core.InputSignal<AtlasStartItem[]>;
    readonly accountActionSelected: _angular_core.OutputEmitterRef<string>;
    chooseAccount(id: string): void;
    readonly menuId: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<AtlasStartItem[]>;
    readonly itemSelected: _angular_core.OutputEmitterRef<string>;
    readonly opened: _angular_core.WritableSignal<boolean>;
    private readonly trigger;
    private readonly popup;
    toggle(): void;
    open(last?: boolean): void;
    close(): void;
    choose(id: string): void;
    key(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasStartMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasStartMenu, "atlas-start-menu", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "accountName": { "alias": "accountName"; "required": false; "isSignal": true; }; "accountActions": { "alias": "accountActions"; "required": false; "isSignal": true; }; "menuId": { "alias": "menuId"; "required": true; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; }, { "accountSelected": "accountSelected"; "accountActionSelected": "accountActionSelected"; "itemSelected": "itemSelected"; }, never, never, true, never>;
}

interface AtlasLookupColumn<T> {
    key: keyof T & string;
    label: string;
    width?: number;
    align?: "left" | "right";
    format?: (row: T) => string;
    searchable?: boolean;
}
declare function lookupCell<T>(row: T, column: AtlasLookupColumn<T>): string;
declare function filterLookup<T>(rows: readonly T[], columns: readonly AtlasLookupColumn<T>[], query: string): T[];
declare function nextLookupIndex<T>(rows: readonly T[], current: number, key: string, disabled: (row: T) => boolean): number;

/** A record picker: commit a stable key while displaying a human-readable record label. */
declare class AtlasLookup<T, V extends string | number = string> implements FormValueControl<V | null>, OnDestroy {
    readonly actions: _angular_core.InputSignal<readonly {
        id: string;
        label: string;
    }[]>;
    readonly action: _angular_core.OutputEmitterRef<{
        id: string;
        query: string;
    }>;
    runAction(id: string): void;
    readonly controlId: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly rows: _angular_core.InputSignal<readonly T[]>;
    readonly columns: _angular_core.InputSignal<readonly AtlasLookupColumn<T>[]>;
    readonly recordKey: _angular_core.InputSignal<(row: T) => V>;
    readonly displayWith: _angular_core.InputSignal<(row: T) => string>;
    readonly rowDisabled: _angular_core.InputSignal<(row: T) => boolean>;
    readonly value: _angular_core.ModelSignal<V | null>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    readonly clearable: _angular_core.InputSignal<boolean>;
    readonly arrowNavigation: _angular_core.InputSignal<"grid" | "open">;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly error: _angular_core.InputSignal<string>;
    readonly popupWidth: _angular_core.InputSignal<number>;
    readonly touch: _angular_core.OutputEmitterRef<void>;
    readonly recordSelected: _angular_core.OutputEmitterRef<T | null>;
    readonly retry: _angular_core.OutputEmitterRef<void>;
    readonly remote: _angular_core.InputSignal<boolean>;
    readonly selectedText: _angular_core.InputSignal<string>;
    readonly page: _angular_core.InputSignal<number>;
    readonly total: _angular_core.InputSignal<number>;
    readonly pageSize: _angular_core.InputSignal<number>;
    readonly queryChange: _angular_core.OutputEmitterRef<string>;
    readonly pageChange: _angular_core.OutputEmitterRef<number>;
    readonly opened: _angular_core.WritableSignal<boolean>;
    readonly query: _angular_core.WritableSignal<string>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly filtered: _angular_core.Signal<T[]>;
    readonly selected: _angular_core.Signal<T | undefined>;
    readonly selectedLabel: _angular_core.Signal<string>;
    readonly activeId: _angular_core.Signal<string | null>;
    readonly columnWidths: _angular_core.Signal<string>;
    readonly cell: typeof lookupCell;
    private readonly trigger;
    private readonly popup;
    private readonly search;
    private readonly retryButton;
    private readonly scroll;
    private readonly onScroll;
    constructor();
    isSelected(row: T): boolean;
    focus(options?: FocusOptions): void;
    open(): void;
    close(restoreFocus: boolean): void;
    onToggle(event: Event): void;
    searchFor(query: string): void;
    highlight(index: number): void;
    choose(row: T): void;
    clear(): void;
    retryLoad(): void;
    triggerKey(event: KeyboardEvent): void;
    popupKey(event: KeyboardEvent): void;
    private detach;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasLookup<any, any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasLookup<any, any>, "atlas-lookup", never, { "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "recordKey": { "alias": "recordKey"; "required": true; "isSignal": true; }; "displayWith": { "alias": "displayWith"; "required": true; "isSignal": true; }; "rowDisabled": { "alias": "rowDisabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "arrowNavigation": { "alias": "arrowNavigation"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "popupWidth": { "alias": "popupWidth"; "required": false; "isSignal": true; }; "remote": { "alias": "remote"; "required": false; "isSignal": true; }; "selectedText": { "alias": "selectedText"; "required": false; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; }, { "action": "action"; "value": "valueChange"; "touch": "touch"; "recordSelected": "recordSelected"; "retry": "retry"; "queryChange": "queryChange"; "pageChange": "pageChange"; }, never, never, true, never>;
}

declare class AtlasTextarea implements FormValueControl<string> {
    readonly controlId: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly value: _angular_core.ModelSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly maxLength: _angular_core.InputSignal<number | undefined>;
    readonly rows: _angular_core.InputSignal<number>;
    readonly showCount: _angular_core.InputSignal<boolean>;
    readonly touch: _angular_core.OutputEmitterRef<void>;
    private readonly native;
    edit(value: string): void;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTextarea, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTextarea, "atlas-textarea", never, { "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "showCount": { "alias": "showCount"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touch": "touch"; }, never, never, true, never>;
}
declare class AtlasToggle implements FormCheckboxControl {
    readonly controlId: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly checked: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.InputSignal<boolean>;
    readonly touch: _angular_core.OutputEmitterRef<void>;
    private readonly native;
    toggle(): void;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasToggle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasToggle, "atlas-toggle", never, { "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "touch": "touch"; }, never, never, true, never>;
}

declare abstract class AtlasChoiceState {
    readonly controlId: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<readonly AtlasOption<string>[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.InputSignal<boolean>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly touch: _angular_core.OutputEmitterRef<void>;
    guardReadonly(event: Event): void;
    private readonly hostElement;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasChoiceState, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasChoiceState, never, never, { "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; }, { "touch": "touch"; }, never, never, true, never>;
}
declare class AtlasCheckboxGroup extends AtlasChoiceState implements FormValueControl<string[]> {
    readonly value: _angular_core.ModelSignal<string[]>;
    readonly limit: _angular_core.InputSignal<number>;
    blocked(key: string): boolean;
    choose(option: AtlasOption): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasCheckboxGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasCheckboxGroup, "atlas-checkbox-group", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "limit": { "alias": "limit"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
declare class AtlasRadioGroup extends AtlasChoiceState implements FormValueControl<string | null> {
    readonly value: _angular_core.ModelSignal<string | null>;
    choose(option: AtlasOption): void;
    readonlyKey(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasRadioGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasRadioGroup, "atlas-radio-group", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
declare abstract class AtlasChoiceOverlay extends AtlasChoiceState implements OnDestroy {
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly opened: _angular_core.WritableSignal<boolean>;
    readonly query: _angular_core.WritableSignal<string>;
    readonly filtered: _angular_core.Signal<AtlasOption<string>[]>;
    protected readonly trigger: _angular_core.Signal<ElementRef<HTMLElement>>;
    protected readonly popup: _angular_core.Signal<ElementRef<HTMLDivElement>>;
    protected readonly search: _angular_core.Signal<ElementRef<HTMLInputElement>>;
    private readonly onScroll;
    constructor();
    open(): void;
    close(focus?: boolean): void;
    toggled(event: Event): void;
    focus(options?: FocusOptions): void;
    protected dismissKey(event: KeyboardEvent): boolean;
    private detach;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasChoiceOverlay, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasChoiceOverlay, never, never, { "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasMultiSelect extends AtlasChoiceOverlay implements FormValueControl<string[]> {
    readonly value: _angular_core.ModelSignal<string[]>;
    readonly limit: _angular_core.InputSignal<number>;
    optionLabel(key: string): string;
    blocked(key: string): boolean;
    choose(option: AtlasOption): void;
    remove(key: string): void;
    clear(): void;
    key(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasMultiSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasMultiSelect, "atlas-multi-select", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "limit": { "alias": "limit"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
declare class AtlasAutocomplete extends AtlasChoiceOverlay implements FormValueControl<string | null> {
    readonly value: _angular_core.ModelSignal<string | null>;
    readonly active: _angular_core.WritableSignal<number>;
    readonly display: _angular_core.Signal<string>;
    first(): number;
    type(text: string): void;
    open(): void;
    focus(options?: FocusOptions): void;
    choose(option: AtlasOption): void;
    close(focus?: boolean): void;
    toggled(event: Event): void;
    clear(): void;
    key(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasAutocomplete, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasAutocomplete, "atlas-autocomplete", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

interface AtlasDateRange {
    start: string;
    end: string;
}
/** Calendar date only. Never converts a business date through a timezone. */
declare function validCalendarDate(value: string): boolean;
declare function dateRangeError(range: AtlasDateRange, min?: string, max?: string): string;
declare function toggleChoice(values: readonly string[], key: string, limit?: number): string[];
/** Accept locale decimal/group separators and ASCII digits; reject partial/ambiguous input. */
declare function parseLocaleNumber(text: string, locale: string): number | null | undefined;

declare abstract class AtlasEntryState {
    readonly controlId: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.InputSignal<boolean>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly touch: _angular_core.OutputEmitterRef<void>;
    protected readonly native: _angular_core.Signal<ElementRef<HTMLInputElement>>;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasEntryState, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasEntryState, never, never, { "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; }, { "touch": "touch"; }, never, never, true, never>;
}
declare class AtlasDateInput extends AtlasEntryState implements FormValueControl<string> {
    readonly value: _angular_core.ModelSignal<string>;
    readonly minDate: _angular_core.InputSignal<string>;
    readonly maxDate: _angular_core.InputSignal<string>;
    edit(value: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDateInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasDateInput, "atlas-date-input", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
declare class AtlasDateRangeInput extends AtlasEntryState implements FormValueControl<AtlasDateRange> {
    readonly value: _angular_core.ModelSignal<AtlasDateRange>;
    readonly minDate: _angular_core.InputSignal<string>;
    readonly maxDate: _angular_core.InputSignal<string>;
    readonly rangeError: _angular_core.Signal<string>;
    edit(key: "start" | "end", value: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDateRangeInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasDateRangeInput, "atlas-date-range", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
declare class AtlasDecimalInput extends AtlasEntryState implements FormValueControl<number | null> {
    readonly value: _angular_core.ModelSignal<number | null>;
    readonly locale: _angular_core.InputSignal<string>;
    readonly currency: _angular_core.InputSignal<string>;
    readonly fractionDigits: _angular_core.InputSignal<number>;
    readonly parseErrorChange: _angular_core.OutputEmitterRef<boolean>;
    readonly text: _angular_core.WritableSignal<string>;
    readonly parseError: _angular_core.Signal<boolean>;
    constructor();
    reset(): void;
    format(value: number | null, grouping: boolean): string;
    begin(): void;
    edit(text: string): void;
    finish(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDecimalInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasDecimalInput, "atlas-decimal-input", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "currency": { "alias": "currency"; "required": false; "isSignal": true; }; "fractionDigits": { "alias": "fractionDigits"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "parseErrorChange": "parseErrorChange"; }, never, never, true, never>;
}
interface AtlasValidationIssue {
    id: string;
    message: string;
}
declare class AtlasValidationSummary {
    readonly issues: _angular_core.InputSignal<readonly AtlasValidationIssue[]>;
    readonly fieldRequested: _angular_core.OutputEmitterRef<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasValidationSummary, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasValidationSummary, "atlas-validation-summary", never, { "issues": { "alias": "issues"; "required": false; "isSignal": true; }; }, { "fieldRequested": "fieldRequested"; }, never, never, true, never>;
}

interface AtlasTreeNode {
    id: string;
    label: string;
    description?: string;
    disabled?: boolean;
    /** True for a branch whose children may not have loaded yet. undefined children means unloaded. */
    hasChildren?: boolean;
    loading?: boolean;
    error?: string;
    /** Optional display values for AtlasTreeGrid columns. */
    values?: Readonly<Record<string, string | number>>;
    children?: readonly AtlasTreeNode[];
}
interface AtlasTreeRow {
    node: AtlasTreeNode;
    level: number;
    parent: string | null;
    position: number;
    size: number;
    expanded: boolean;
}
/** Filtering includes ancestors of matches. Search expansion does not change saved expansion. */
declare function flattenTree(nodes: readonly AtlasTreeNode[], expanded: readonly string[], query?: string): AtlasTreeRow[];
declare function findTreeNode(nodes: readonly AtlasTreeNode[], id: string | null): AtlasTreeNode | undefined;

declare class AtlasTree {
    readonly nodes: _angular_core.InputSignal<readonly AtlasTreeNode[]>;
    readonly label: _angular_core.InputSignal<string>;
    readonly filterable: _angular_core.InputSignal<boolean>;
    readonly leafOnly: _angular_core.InputSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly error: _angular_core.InputSignal<string>;
    readonly retry: _angular_core.OutputEmitterRef<void>;
    readonly selectedId: _angular_core.ModelSignal<string | null>;
    readonly expandedIds: _angular_core.ModelSignal<string[]>;
    readonly nodeSelected: _angular_core.OutputEmitterRef<AtlasTreeNode>;
    readonly query: _angular_core.WritableSignal<string>;
    readonly focused: _angular_core.WritableSignal<string | null>;
    readonly visible: _angular_core.Signal<AtlasTreeRow[]>;
    readonly tabstop: _angular_core.Signal<string | null>;
    toggle(row: AtlasTreeRow): void;
    choose(row: AtlasTreeRow): void;
    key(event: KeyboardEvent, item: AtlasTreeRow): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTree, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTree, "atlas-tree", never, { "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "leafOnly": { "alias": "leafOnly"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; "expandedIds": { "alias": "expandedIds"; "required": false; "isSignal": true; }; }, { "retry": "retry"; "selectedId": "selectedIdChange"; "expandedIds": "expandedIdsChange"; "nodeSelected": "nodeSelected"; }, never, never, true, never>;
}
declare class AtlasTreeSelect implements FormValueControl<string | null> {
    readonly nodes: _angular_core.InputSignal<readonly AtlasTreeNode[]>;
    readonly value: _angular_core.ModelSignal<string | null>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly controlId: _angular_core.InputSignal<string>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly leafOnly: _angular_core.InputSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.InputSignal<boolean>;
    readonly touchedChange: _angular_core.OutputEmitterRef<boolean>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly error: _angular_core.InputSignal<string>;
    readonly retry: _angular_core.OutputEmitterRef<void>;
    readonly open: _angular_core.WritableSignal<boolean>;
    readonly selected: _angular_core.Signal<AtlasTreeNode | undefined>;
    readonly trigger: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    readonly invert: (value: boolean) => boolean;
    focus(): void;
    close(event?: Event): void;
    commit(node: AtlasTreeNode): void;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTreeSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTreeSelect, "atlas-tree-select", never, { "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "controlId": { "alias": "controlId"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; "leafOnly": { "alias": "leafOnly"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touchedChange": "touchedChange"; "retry": "retry"; }, never, never, true, never>;
}

interface AtlasEditColumn<T> {
    key: keyof T & string;
    label: string;
    type?: "text" | "number" | "select";
    readonly?: boolean;
    required?: boolean;
    min?: number;
    max?: number;
    step?: number;
    options?: readonly {
        value: string;
        label: string;
        disabled?: boolean;
    }[];
    format?: (row: T) => string;
}
declare function validateEditRow<T extends object>(row: T, columns: readonly AtlasEditColumn<T>[]): Record<string, string>;
/** Replaces an existing row by stable key. Never mutates the source collection. */
declare function replaceEditedRow<T extends object>(rows: readonly T[], draft: T, key: keyof T): T[];

declare class AtlasEditableGrid<T extends object> {
    readonly rows: _angular_core.ModelSignal<T[]>;
    readonly draft: _angular_core.ModelSignal<T | null>;
    readonly columns: _angular_core.InputSignal<AtlasEditColumn<T>[]>;
    readonly keyField: _angular_core.InputSignal<keyof T & string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly removable: _angular_core.InputSignal<boolean>;
    readonly removeRequested: _angular_core.OutputEmitterRef<T>;
    readonly rowApplied: _angular_core.OutputEmitterRef<T>;
    readonly attempted: _angular_core.WritableSignal<boolean>;
    readonly notice: _angular_core.WritableSignal<string>;
    readonly errors: _angular_core.Signal<Record<string, string>>;
    private readonly host;
    private readonly id;
    private origin?;
    private editingKey;
    errorId(key: string): string;
    isEditing(row: T): boolean;
    display(row: T, column: AtlasEditColumn<T>): string;
    begin(row: T, event?: Event): void;
    edit(column: AtlasEditColumn<T>, value: string): void;
    apply(): void;
    cancel(): void;
    private restore;
    key(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasEditableGrid<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasEditableGrid<any>, "atlas-editable-grid", never, { "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "draft": { "alias": "draft"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "keyField": { "alias": "keyField"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; }, { "rows": "rowsChange"; "draft": "draftChange"; "removeRequested": "removeRequested"; "rowApplied": "rowApplied"; }, never, never, true, never>;
}

/** Shared presentation definitions. Applications must authorize execution again at their command boundary. */
interface AtlasCommand {
    id: string;
    label: string;
    icon?: string;
    primary?: boolean;
    disabled?: boolean;
    hidden?: boolean;
    permission?: string;
    group?: string;
}
declare function atlasVisibleCommands(commands: readonly AtlasCommand[], permissions: readonly string[]): AtlasCommand[];
declare function atlasCommandAllowed(commands: readonly AtlasCommand[], id: string, permissions: readonly string[], disabled?: boolean): boolean;
/** Reserve room for overflow only when all commands cannot fit. */
declare function atlasToolbarCapacity(widths: readonly number[], available: number, more?: number, gap?: number): number;

declare class AtlasCommandToolbar {
    readonly commands: _angular_core.InputSignal<readonly AtlasCommand[]>;
    readonly permissions: _angular_core.InputSignal<readonly string[]>;
    readonly label: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly command: _angular_core.OutputEmitterRef<string>;
    readonly focused: _angular_core.WritableSignal<string>;
    readonly capacity: _angular_core.WritableSignal<number>;
    readonly allowed: _angular_core.Signal<AtlasCommand[]>;
    readonly visible: _angular_core.Signal<AtlasCommand[]>;
    readonly overflow: _angular_core.Signal<AtlasCommand[]>;
    readonly tabstop: _angular_core.Signal<string>;
    private readonly bar;
    private readonly measure;
    private readonly status;
    constructor();
    resize(): void;
    execute(item: AtlasCommand): void;
    executeId(id: string): void;
    key(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasCommandToolbar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasCommandToolbar, "atlas-command-toolbar", never, { "commands": { "alias": "commands"; "required": false; "isSignal": true; }; "permissions": { "alias": "permissions"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "command": "command"; }, never, ["*"], true, never>;
}
declare class AtlasMasterDetail {
    readonly detailOpen: _angular_core.ModelSignal<boolean>;
    readonly masterLabel: _angular_core.InputSignal<string>;
    readonly detailLabel: _angular_core.InputSignal<string>;
    readonly breakpoint: _angular_core.InputSignal<number>;
    readonly width: _angular_core.WritableSignal<number>;
    readonly narrow: _angular_core.Signal<boolean>;
    private host;
    private origin?;
    rememberOrigin(event: FocusEvent): void;
    constructor();
    back(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasMasterDetail, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasMasterDetail, "atlas-master-detail", never, { "detailOpen": { "alias": "detailOpen"; "required": false; "isSignal": true; }; "masterLabel": { "alias": "masterLabel"; "required": false; "isSignal": true; }; "detailLabel": { "alias": "detailLabel"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; }, { "detailOpen": "detailOpenChange"; }, never, ["[atlasMaster]", "[atlasDetail]"], true, never>;
}
declare class AtlasDialog {
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly title: _angular_core.InputSignal<string>;
    readonly busy: _angular_core.InputSignal<boolean>;
    readonly dismissed: _angular_core.OutputEmitterRef<void>;
    readonly dialog: _angular_core.Signal<ElementRef<HTMLDialogElement> | undefined>;
    readonly titleId: string;
    private readonly host;
    position(): void;
    constructor();
    dismiss(): void;
    cancel(event: Event): void;
    closed(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDialog, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasDialog, "atlas-dialog", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "busy": { "alias": "busy"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "dismissed": "dismissed"; }, never, ["*", "[atlasDialogActions]"], true, never>;
}

/**
 * Reusable continuous-cell navigation for a native table; owns no data or save state.
 * Use one tbody, stable columns, and an immediate overflow:auto wrapper.
 * Mark one input/button or AtlasLookup host per editable td with data-sheet-editor.
 * For lookups use arrowNavigation="grid" and clearable=false.
 * Integration guide and complete example: docs/controls/DATASHEET-INTEGRATION.md.
 */
declare class AtlasDatasheet {
    private readonly element;
    navigate(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDatasheet, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasDatasheet, "table[atlasDatasheet]", never, {}, {}, never, never, true, never>;
}

interface AtlasRecordOption {
    id: string;
    label: string;
}
declare class AtlasRecordNavigator {
    readonly records: _angular_core.InputSignal<readonly AtlasRecordOption[]>;
    readonly currentId: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly navigate: _angular_core.OutputEmitterRef<string>;
    readonly create: _angular_core.OutputEmitterRef<void>;
    selectRecord(event: Event): void;
    index(): number;
    choose(index: number): void;
    request(id: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasRecordNavigator, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasRecordNavigator, "atlas-record-navigator", never, { "records": { "alias": "records"; "required": true; "isSignal": true; }; "currentId": { "alias": "currentId"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "navigate": "navigate"; "create": "create"; }, never, never, true, never>;
}
interface AtlasValidationTarget {
    id: string;
    message: string;
}
declare class AtlasValidationNavigator {
    readonly errors: _angular_core.InputSignal<readonly AtlasValidationTarget[]>;
    readonly activate: _angular_core.OutputEmitterRef<AtlasValidationTarget>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasValidationNavigator, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasValidationNavigator, "atlas-validation-navigator", never, { "errors": { "alias": "errors"; "required": true; "isSignal": true; }; }, { "activate": "activate"; }, never, never, true, never>;
}
/** Consumer chooses when to clear dependent state; this helper never mutates records. */
declare function dependentRecords<T, K>(rows: readonly T[], parent: K | null, parentKey: (row: T) => K): T[];

type AtlasPropertyValue = string | number | boolean | null;
interface AtlasProperty {
    key: string;
    label: string;
    group: string;
    type: "text" | "number" | "select" | "boolean";
    readonly?: boolean;
    min?: number;
    max?: number;
    step?: number;
    options?: readonly {
        value: string;
        label: string;
    }[];
    hint?: string;
}
declare class AtlasPropertySheet {
    readonly fields: _angular_core.InputSignal<readonly AtlasProperty[]>;
    readonly value: _angular_core.ModelSignal<Record<string, AtlasPropertyValue>>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly groups: _angular_core.Signal<string[]>;
    set(key: string, value: AtlasPropertyValue): void;
    edit(field: AtlasProperty, event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasPropertySheet, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasPropertySheet, "atlas-property-sheet", never, { "fields": { "alias": "fields"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
interface AtlasTotalLine {
    id: string;
    label: string;
    value: number;
    emphasis?: boolean;
}
declare class AtlasTotalsPanel {
    readonly lines: _angular_core.InputSignal<readonly AtlasTotalLine[]>;
    readonly currency: _angular_core.InputSignal<string>;
    readonly locale: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    format(value: number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTotalsPanel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTotalsPanel, "atlas-totals-panel", never, { "lines": { "alias": "lines"; "required": true; "isSignal": true; }; "currency": { "alias": "currency"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
interface AtlasActivity {
    id: string;
    title: string;
    detail: string;
    actor: string;
    timestamp: string;
    kind: string;
}
declare class AtlasActivityTimeline {
    readonly events: _angular_core.InputSignal<readonly AtlasActivity[]>;
    readonly label: _angular_core.InputSignal<string>;
    date(value: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasActivityTimeline, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasActivityTimeline, "atlas-activity-timeline", never, { "events": { "alias": "events"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
interface AtlasAttachment {
    id: string;
    name: string;
    size: number;
    status: "uploading" | "ready" | "error";
    progress: number;
    error?: string;
}
declare class AtlasAttachmentList {
    readonly files: _angular_core.InputSignal<readonly AtlasAttachment[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly accept: _angular_core.InputSignal<string>;
    readonly add: _angular_core.OutputEmitterRef<File[]>;
    readonly preview: _angular_core.OutputEmitterRef<string>;
    readonly retry: _angular_core.OutputEmitterRef<string>;
    readonly remove: _angular_core.OutputEmitterRef<string>;
    pick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasAttachmentList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasAttachmentList, "atlas-attachment-list", never, { "files": { "alias": "files"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; }, { "add": "add"; "preview": "preview"; "retry": "retry"; "remove": "remove"; }, never, never, true, never>;
}

type AtlasFilterOperator = "contains" | "equals" | "gte" | "lte";
interface AtlasFilterField {
    key: string;
    label: string;
    type: "text" | "number";
}
interface AtlasFilterRule {
    id: string;
    field: string;
    operator: AtlasFilterOperator;
    value: string;
}
interface AtlasSavedView {
    id: string;
    name: string;
    rules: AtlasFilterRule[];
}
declare function matchesFilterRules(row: Record<string, unknown>, rules: readonly AtlasFilterRule[]): boolean;
declare class AtlasFilterBuilder {
    readonly fields: _angular_core.InputSignal<readonly AtlasFilterField[]>;
    readonly rules: _angular_core.ModelSignal<AtlasFilterRule[]>;
    readonly views: _angular_core.InputSignal<readonly AtlasSavedView[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly saveRequested: _angular_core.OutputEmitterRef<string>;
    readonly deleteRequested: _angular_core.OutputEmitterRef<string>;
    readonly name: _angular_core.WritableSignal<string>;
    private sequence;
    operatorLabel(operator: AtlasFilterOperator): string;
    numeric(key: string): boolean;
    operators(key: string): AtlasFilterOperator[];
    patch(id: string, patch: Partial<AtlasFilterRule>): void;
    field(id: string, key: string): void;
    add(): void;
    remove(id: string): void;
    copy(rules: AtlasFilterRule[]): AtlasFilterRule[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasFilterBuilder, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasFilterBuilder, "atlas-filter-builder", never, { "fields": { "alias": "fields"; "required": true; "isSignal": true; }; "rules": { "alias": "rules"; "required": false; "isSignal": true; }; "views": { "alias": "views"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "rules": "rulesChange"; "saveRequested": "saveRequested"; "deleteRequested": "deleteRequested"; }, never, never, true, never>;
}

type AtlasUploadAdapter = (file: File, context: {
    signal: AbortSignal;
    progress: (percent: number) => void;
}) => Promise<void>;
/** Feature-owned upload state. Call destroy() on disposal. Adapter owns HTTP and remote file IDs. */
declare class AtlasUploadQueue {
    private adapter;
    private maxBytes;
    readonly files: _angular_core.WritableSignal<AtlasAttachment[]>;
    readonly error: _angular_core.WritableSignal<string>;
    private sources;
    private requests;
    private sequence;
    private disposed;
    constructor(adapter: AtlasUploadAdapter, maxBytes?: number);
    add(files: readonly File[]): void;
    file(id: string): File | null;
    upload(id: string): Promise<void>;
    remove(id: string): void;
    destroy(): void;
    private patch;
}

interface AtlasTabChoice {
    id: string;
    disabled?: boolean;
}
declare function nextAtlasTab(tabs: readonly AtlasTabChoice[], current: string, key: string): string | undefined;
declare function clampAtlasSplit(value: number, minimum?: number, maximum?: number): number;
declare class AtlasTab {
    readonly id: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTab, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasTab, "ng-template[atlasTab]", never, { "id": { "alias": "atlasTab"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasTabs {
    readonly uid: string;
    readonly label: _angular_core.InputSignal<string>;
    readonly selected: _angular_core.ModelSignal<string>;
    readonly tabs: _angular_core.Signal<readonly AtlasTab[]>;
    readonly visited: _angular_core.WritableSignal<Set<string>>;
    readonly active: _angular_core.Signal<string>;
    constructor();
    key(event: KeyboardEvent, id: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTabs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTabs, "atlas-tabs", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; }, ["tabs"], never, true, never>;
}
declare class AtlasFieldset {
    readonly uid: string;
    readonly label: _angular_core.InputSignal<string>;
    readonly collapsible: _angular_core.InputSignal<boolean>;
    readonly collapsed: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasFieldset, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasFieldset, "atlas-fieldset", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "collapsed": "collapsedChange"; }, never, ["*"], true, never>;
}
declare class AtlasAccordionSection {
    readonly uid: string;
    readonly label: _angular_core.InputSignal<string>;
    readonly expanded: _angular_core.ModelSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasAccordionSection, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasAccordionSection, "atlas-accordion-section", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; }, never, ["*"], true, never>;
}
declare class AtlasSplitPane {
    readonly uid: string;
    readonly primaryLabel: _angular_core.InputSignal<string>;
    readonly secondaryLabel: _angular_core.InputSignal<string>;
    readonly ratio: _angular_core.ModelSignal<number>;
    readonly minimum: _angular_core.InputSignal<number>;
    readonly maximum: _angular_core.InputSignal<number>;
    readonly breakpoint: _angular_core.InputSignal<number>;
    readonly collapsed: _angular_core.ModelSignal<boolean>;
    readonly width: _angular_core.WritableSignal<number>;
    readonly narrow: _angular_core.Signal<boolean>;
    readonly lower: _angular_core.Signal<number>;
    readonly upper: _angular_core.Signal<number>;
    readonly size: _angular_core.Signal<number>;
    private readonly host;
    dragging: boolean;
    constructor();
    key(event: KeyboardEvent): void;
    start(event: PointerEvent): void;
    move(event: PointerEvent): void;
    stop(event: PointerEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasSplitPane, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasSplitPane, "atlas-split-pane", never, { "primaryLabel": { "alias": "primaryLabel"; "required": false; "isSignal": true; }; "secondaryLabel": { "alias": "secondaryLabel"; "required": false; "isSignal": true; }; "ratio": { "alias": "ratio"; "required": false; "isSignal": true; }; "minimum": { "alias": "minimum"; "required": false; "isSignal": true; }; "maximum": { "alias": "maximum"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, { "ratio": "ratioChange"; "collapsed": "collapsedChange"; }, never, ["[atlasSplitPrimary]", "[atlasSplitSecondary]"], true, never>;
}

/** null means selection is incomplete because an enabled branch is still unloaded. Disabled subtrees are excluded. */
declare function atlasCheckLeaves(node: AtlasTreeNode): string[] | null;
declare function atlasCheckState(node: AtlasTreeNode, checked: readonly string[]): boolean | "mixed";
declare function atlasToggleChecks(node: AtlasTreeNode, checked: readonly string[]): string[];
interface AtlasTreeGridColumn {
    key: string;
    label: string;
    align?: "left" | "right";
}
declare class AtlasHierarchyBase {
    readonly nodes: _angular_core.InputSignal<readonly AtlasTreeNode[]>;
    readonly label: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly expandedIds: _angular_core.ModelSignal<string[]>;
    readonly selectedId: _angular_core.ModelSignal<string | null>;
    readonly checkedIds: _angular_core.ModelSignal<string[]>;
    /** Adapter inserts children immutably and owns node loading/error state. */
    readonly loadChildren: _angular_core.OutputEmitterRef<AtlasTreeNode>;
    readonly nodeSelected: _angular_core.OutputEmitterRef<AtlasTreeNode>;
    readonly focused: _angular_core.WritableSignal<string | null>;
    readonly visible: _angular_core.Signal<AtlasTreeRow[]>;
    readonly tabstop: _angular_core.Signal<string | null>;
    branch(node: AtlasTreeNode): boolean;
    blocked(row: AtlasTreeRow): boolean;
    checkBlocked(row: AtlasTreeRow): boolean;
    state(node: AtlasTreeNode): boolean | "mixed";
    check(row: AtlasTreeRow): void;
    toggle(row: AtlasTreeRow): void;
    retry(row: AtlasTreeRow): void;
    choose(row: AtlasTreeRow): void;
    key(event: KeyboardEvent, row: AtlasTreeRow, checks?: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasHierarchyBase, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasHierarchyBase, never, never, { "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "expandedIds": { "alias": "expandedIds"; "required": false; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; "checkedIds": { "alias": "checkedIds"; "required": false; "isSignal": true; }; }, { "expandedIds": "expandedIdsChange"; "selectedId": "selectedIdChange"; "checkedIds": "checkedIdsChange"; "loadChildren": "loadChildren"; "nodeSelected": "nodeSelected"; }, never, never, true, never>;
}
declare class AtlasCheckTree extends AtlasHierarchyBase {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasCheckTree, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasCheckTree, "atlas-check-tree", never, {}, {}, never, never, true, never>;
}
declare class AtlasTreeGrid extends AtlasHierarchyBase {
    readonly columns: _angular_core.InputSignal<readonly AtlasTreeGridColumn[]>;
    readonly hierarchyLabel: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTreeGrid, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTreeGrid, "atlas-tree-grid", never, { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "hierarchyLabel": { "alias": "hierarchyLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtlasPopupMenu {
    readonly commands: _angular_core.InputSignal<readonly AtlasCommand[]>;
    readonly permissions: _angular_core.InputSignal<readonly string[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly command: _angular_core.OutputEmitterRef<string>;
    readonly opened: _angular_core.WritableSignal<boolean>;
    readonly visible: _angular_core.Signal<AtlasCommand[]>;
    private readonly panel;
    private origin?;
    openAt(origin: HTMLElement, point?: {
        x: number;
        y: number;
    }, last?: boolean): void;
    close(restore?: boolean): void;
    viewportChanged(): void;
    toggled(event: Event): void;
    execute(id: string): void;
    key(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasPopupMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasPopupMenu, "atlas-popup-menu", never, { "commands": { "alias": "commands"; "required": false; "isSignal": true; }; "permissions": { "alias": "permissions"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "command": "command"; }, never, never, true, never>;
}
declare class AtlasContextMenu {
    readonly atlasContextMenu: _angular_core.InputSignal<AtlasPopupMenu>;
    private readonly host;
    open(event: MouseEvent): void;
    keyboard(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasContextMenu, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasContextMenu, "[atlasContextMenu]", never, { "atlasContextMenu": { "alias": "atlasContextMenu"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasMenuButton {
    readonly commands: _angular_core.InputSignal<readonly AtlasCommand[]>;
    readonly permissions: _angular_core.InputSignal<readonly string[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly command: _angular_core.OutputEmitterRef<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasMenuButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasMenuButton, "atlas-menu-button", never, { "commands": { "alias": "commands"; "required": false; "isSignal": true; }; "permissions": { "alias": "permissions"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "command": "command"; }, never, never, true, never>;
}
declare class AtlasSplitButton {
    readonly commands: _angular_core.InputSignal<readonly AtlasCommand[]>;
    readonly primaryId: _angular_core.InputSignal<string>;
    readonly permissions: _angular_core.InputSignal<readonly string[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly command: _angular_core.OutputEmitterRef<string>;
    readonly primary: _angular_core.Signal<AtlasCommand | undefined>;
    readonly alternatives: _angular_core.Signal<AtlasCommand[]>;
    execute(id: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasSplitButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasSplitButton, "atlas-split-button", never, { "commands": { "alias": "commands"; "required": false; "isSignal": true; }; "primaryId": { "alias": "primaryId"; "required": true; "isSignal": true; }; "permissions": { "alias": "permissions"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "command": "command"; }, never, never, true, never>;
}

declare function atlasTransferItems(value: readonly string[], selection: readonly string[], options: readonly AtlasOption[], add: boolean, limit?: number): string[];
declare function atlasMoveItems(value: readonly string[], selection: readonly string[], options: readonly AtlasOption[], direction: -1 | 1): string[];
declare class AtlasItemSelector extends AtlasChoiceState implements FormValueControl<string[]> {
    readonly value: _angular_core.ModelSignal<string[]>;
    readonly availableLabel: _angular_core.InputSignal<string>;
    readonly assignedLabel: _angular_core.InputSignal<string>;
    readonly limit: _angular_core.InputSignal<number>;
    readonly reorderable: _angular_core.InputSignal<boolean>;
    readonly search: _angular_core.WritableSignal<string>;
    readonly availableSelection: _angular_core.WritableSignal<string[]>;
    readonly assignedSelection: _angular_core.WritableSignal<string[]>;
    readonly message: _angular_core.WritableSignal<string>;
    readonly available: _angular_core.Signal<AtlasOption<string>[]>;
    readonly assigned: _angular_core.Signal<AtlasOption<string>[]>;
    private readonly element;
    focus(options?: FocusOptions): void;
    choose(event: Event, assigned: boolean): void;
    transfer(add: boolean): void;
    canMove(direction: -1 | 1): boolean;
    move(direction: -1 | 1): void;
    key(event: KeyboardEvent, assigned: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasItemSelector, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasItemSelector, "atlas-item-selector", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "availableLabel": { "alias": "availableLabel"; "required": false; "isSignal": true; }; "assignedLabel": { "alias": "assignedLabel"; "required": false; "isSignal": true; }; "limit": { "alias": "limit"; "required": false; "isSignal": true; }; "reorderable": { "alias": "reorderable"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

interface AtlasPivotResult {
    columns: string[];
    rows: {
        label: string;
        values: string[];
        total: string;
    }[];
    totals: string[];
    grandTotal: string;
}
declare function atlasPivot<T>(records: readonly T[], row: (record: T) => string, column: (record: T) => string, value: (record: T) => string, scale?: number): AtlasPivotResult;
declare class AtlasPivotTable<T> {
    readonly records: _angular_core.InputSignal<readonly T[]>;
    readonly row: _angular_core.InputSignal<(record: T) => string>;
    readonly column: _angular_core.InputSignal<(record: T) => string>;
    readonly measure: _angular_core.InputSignal<(record: T) => string>;
    readonly scale: _angular_core.InputSignal<number>;
    readonly label: _angular_core.InputSignal<string>;
    readonly rowLabel: _angular_core.InputSignal<string>;
    readonly cellSelected: _angular_core.OutputEmitterRef<{
        row: string;
        column: string;
    }>;
    readonly result: _angular_core.Signal<{
        data: AtlasPivotResult;
        error: string;
    } | {
        data: null;
        error: string;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasPivotTable<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasPivotTable<any>, "atlas-pivot-table", never, { "records": { "alias": "records"; "required": true; "isSignal": true; }; "row": { "alias": "row"; "required": true; "isSignal": true; }; "column": { "alias": "column"; "required": true; "isSignal": true; }; "measure": { "alias": "measure"; "required": true; "isSignal": true; }; "scale": { "alias": "scale"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "rowLabel": { "alias": "rowLabel"; "required": false; "isSignal": true; }; }, { "cellSelected": "cellSelected"; }, never, never, true, never>;
}
interface AtlasChartPoint {
    id: string;
    label: string;
    value: number;
}
declare function atlasChartDomain(points: readonly AtlasChartPoint[]): {
    min: number;
    max: number;
};
declare class AtlasChart {
    readonly points: _angular_core.InputSignal<readonly AtlasChartPoint[]>;
    readonly type: _angular_core.InputSignal<"line" | "bar">;
    readonly label: _angular_core.InputSignal<string>;
    readonly selected: _angular_core.ModelSignal<string | null>;
    readonly pointSelected: _angular_core.OutputEmitterRef<AtlasChartPoint>;
    readonly Math: Math;
    readonly visible: _angular_core.Signal<AtlasChartPoint[]>;
    readonly omitted: _angular_core.Signal<number>;
    readonly domain: _angular_core.Signal<{
        min: number;
        max: number;
    }>;
    readonly ticks: _angular_core.Signal<number[]>;
    readonly line: _angular_core.Signal<string>;
    x(index: number): number;
    y(value: number): number;
    barWidth(): number;
    tickLabel(value: number): string;
    choose(point: AtlasChartPoint): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasChart, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasChart, "atlas-chart", never, { "points": { "alias": "points"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; "pointSelected": "pointSelected"; }, never, never, true, never>;
}
declare function atlasDashboardOrder(ids: readonly string[], order: readonly string[]): string[];
declare function atlasMovePanel(ids: readonly string[], id: string, target: string): string[];
declare class AtlasDashboardPanel {
    readonly id: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly template: TemplateRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDashboardPanel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtlasDashboardPanel, "ng-template[atlasDashboardPanel]", never, { "id": { "alias": "atlasDashboardPanel"; "required": true; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasDashboard {
    readonly panels: _angular_core.Signal<readonly AtlasDashboardPanel[]>;
    readonly order: _angular_core.ModelSignal<string[]>;
    readonly dragged: _angular_core.WritableSignal<string | null>;
    readonly announcement: _angular_core.WritableSignal<string>;
    readonly ordered: _angular_core.Signal<AtlasDashboardPanel[]>;
    move(id: string, direction: number): void;
    reorder(id: string, target: string): void;
    start(event: DragEvent, id: string): void;
    allowDrop(event: DragEvent): void;
    drop(event: DragEvent, target: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDashboard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasDashboard, "atlas-dashboard", never, { "order": { "alias": "order"; "required": false; "isSignal": true; }; }, { "order": "orderChange"; }, ["panels"], never, true, never>;
}

declare function atlasDate(date: string): Date;
declare function atlasShiftDate(date: string, days: number): string;
declare function atlasShiftMonth(date: string, months: number): string;
declare function atlasCalendarDays(month: string, weekStartsOn?: 0 | 1): string[];
interface AtlasCalendarEvent {
    id: string;
    title: string;
    date: string;
    endDate?: string;
    description?: string;
}
declare function atlasEventsOn(events: readonly AtlasCalendarEvent[], date: string): AtlasCalendarEvent[];
declare class AtlasCalendar {
    private readonly today;
    private readonly initial;
    readonly month: _angular_core.ModelSignal<string>;
    readonly selectedDate: _angular_core.ModelSignal<string>;
    readonly events: _angular_core.InputSignal<readonly AtlasCalendarEvent[]>;
    readonly weekStartsOn: _angular_core.InputSignal<0 | 1>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly eventSelected: _angular_core.OutputEmitterRef<AtlasCalendarEvent>;
    private readonly host;
    readonly days: _angular_core.Signal<string[]>;
    readonly weekdays: _angular_core.Signal<string[]>;
    readonly tabstop: _angular_core.Signal<string>;
    readonly heading: _angular_core.Signal<string>;
    on(date: string): AtlasCalendarEvent[];
    dayLabel(date: string): string;
    canNavigate(delta: number): boolean;
    navigate(delta: number): void;
    choose(date: string): void;
    key(event: KeyboardEvent, date: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasCalendar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasCalendar, "atlas-calendar", never, { "month": { "alias": "month"; "required": false; "isSignal": true; }; "selectedDate": { "alias": "selectedDate"; "required": false; "isSignal": true; }; "events": { "alias": "events"; "required": false; "isSignal": true; }; "weekStartsOn": { "alias": "weekStartsOn"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "month": "monthChange"; "selectedDate": "selectedDateChange"; "eventSelected": "eventSelected"; }, never, never, true, never>;
}

interface AtlasRichBlock {
    id: string;
    kind: "paragraph" | "heading" | "bullet";
    text: string;
    bold?: boolean;
    italic?: boolean;
}
interface AtlasRichDocument {
    blocks: AtlasRichBlock[];
}
/** Plain structured content only: no HTML, scripts, style strings, URLs or embedded objects. */
declare function atlasRichText(document: AtlasRichDocument): string;
declare function atlasUpdateRichBlock(document: AtlasRichDocument, id: string, patch: Partial<Pick<AtlasRichBlock, "kind" | "text" | "bold" | "italic">>): AtlasRichDocument;
declare class AtlasRichText extends AtlasChoiceState implements FormValueControl<AtlasRichDocument> {
    readonly value: _angular_core.ModelSignal<AtlasRichDocument>;
    readonly message: _angular_core.WritableSignal<string>;
    readonly text: _angular_core.Signal<string>;
    private readonly element;
    private sequence;
    focus(options?: FocusOptions): void;
    edit(id: string, patch: Partial<Pick<AtlasRichBlock, "kind" | "text" | "bold" | "italic">>): void;
    add(): void;
    remove(id: string): void;
    move(id: string, direction: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasRichText, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasRichText, "atlas-rich-text", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

declare function atlasVirtualRange(total: number, scroll: number, height: number, rowHeight: number, overscan?: number): {
    start: number;
    end: number;
    top: number;
    bottom: number;
};
declare class AtlasVirtualGrid<T extends object> {
    readonly rows: _angular_core.InputSignal<readonly T[]>;
    readonly columns: _angular_core.InputSignal<readonly AtlasColumn<T>[]>;
    readonly keyField: _angular_core.InputSignal<keyof T>;
    readonly label: _angular_core.InputSignal<string>;
    readonly height: _angular_core.InputSignal<number>;
    readonly rowHeight: _angular_core.InputSignal<number>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly error: _angular_core.InputSignal<string>;
    readonly retry: _angular_core.OutputEmitterRef<void>;
    readonly selectedKey: _angular_core.ModelSignal<string | null>;
    readonly rowActivated: _angular_core.OutputEmitterRef<T>;
    readonly scroll: _angular_core.WritableSignal<number>;
    readonly viewport: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly id: string;
    readonly size: _angular_core.Signal<number>;
    readonly viewportHeight: _angular_core.Signal<number>;
    readonly range: _angular_core.Signal<{
        start: number;
        end: number;
        top: number;
        bottom: number;
    }>;
    readonly visible: _angular_core.Signal<T[]>;
    readonly activeIndex: _angular_core.Signal<number>;
    readonly activeDescendant: _angular_core.Signal<string | null>;
    readonly tableWidth: _angular_core.Signal<number>;
    constructor();
    rowId(index: number): string;
    rowKey(row: T): string;
    value(row: T, column: AtlasColumn<T>): string;
    select(index: number): void;
    key(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasVirtualGrid<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasVirtualGrid<any>, "atlas-virtual-grid", never, { "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "keyField": { "alias": "keyField"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "rowHeight": { "alias": "rowHeight"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "selectedKey": { "alias": "selectedKey"; "required": false; "isSignal": true; }; }, { "retry": "retry"; "selectedKey": "selectedKeyChange"; "rowActivated": "rowActivated"; }, never, never, true, never>;
}

type AtlasFeedbackTone = "info" | "success" | "warning" | "danger";
declare function atlasProgressValue(value: number | null, max?: number): number | null;
declare class AtlasProgress {
    readonly value: _angular_core.InputSignal<number | null>;
    readonly max: _angular_core.InputSignal<number>;
    readonly label: _angular_core.InputSignal<string>;
    readonly limit: _angular_core.Signal<number>;
    readonly amount: _angular_core.Signal<number | null>;
    readonly percent: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasProgress, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasProgress, "atlas-progress", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtlasNotice {
    readonly title: _angular_core.InputSignal<string>;
    readonly message: _angular_core.InputSignal<string>;
    readonly tone: _angular_core.InputSignal<AtlasFeedbackTone>;
    readonly urgent: _angular_core.InputSignal<boolean>;
    readonly dismissible: _angular_core.InputSignal<boolean>;
    readonly dismissed: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasNotice, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasNotice, "atlas-notice", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "urgent": { "alias": "urgent"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; }, { "dismissed": "dismissed"; }, never, never, true, never>;
}
declare class AtlasStatusBar {
    readonly message: _angular_core.InputSignal<string>;
    readonly tone: _angular_core.InputSignal<AtlasFeedbackTone>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasStatusBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasStatusBar, "atlas-status-bar", never, { "message": { "alias": "message"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class AtlasLoadingRegion {
    readonly busy: _angular_core.InputSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly message: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasLoadingRegion, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasLoadingRegion, "atlas-loading-region", never, { "busy": { "alias": "busy"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
interface AtlasMessageResult {
    action: "accept" | "cancel";
    value: string;
}
declare function atlasPromptError(value: string, required: boolean, maxLength: number): string;
declare class AtlasMessageBox {
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly value: _angular_core.ModelSignal<string>;
    readonly kind: _angular_core.InputSignal<"confirm" | "alert" | "prompt">;
    readonly title: _angular_core.InputSignal<string>;
    readonly message: _angular_core.InputSignal<string>;
    readonly promptLabel: _angular_core.InputSignal<string>;
    readonly required: _angular_core.InputSignal<boolean>;
    readonly maxLength: _angular_core.InputSignal<number>;
    readonly acceptLabel: _angular_core.InputSignal<string>;
    readonly cancelLabel: _angular_core.InputSignal<string>;
    readonly danger: _angular_core.InputSignal<boolean>;
    readonly result: _angular_core.OutputEmitterRef<AtlasMessageResult>;
    readonly error: _angular_core.WritableSignal<string>;
    readonly id: string;
    readonly dialog: _angular_core.Signal<AtlasDialog | undefined>;
    private completed;
    constructor();
    finish(action: "accept" | "cancel"): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasMessageBox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasMessageBox, "atlas-message-box", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "promptLabel": { "alias": "promptLabel"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "acceptLabel": { "alias": "acceptLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "danger": { "alias": "danger"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "value": "valueChange"; "result": "result"; }, never, never, true, never>;
}
/** Viewport-clamped placement, flipping above when the lower edge would overflow. */
declare function atlasFeedbackPosition(anchor: {
    left: number;
    top: number;
    bottom: number;
}, panel: {
    width: number;
    height: number;
}, viewport: {
    width: number;
    height: number;
}): {
    left: number;
    top: number;
};
declare class AtlasPopover {
    readonly label: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly opened: _angular_core.WritableSignal<boolean>;
    readonly id: string;
    readonly panel: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly trigger: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    constructor();
    toggle(): void;
    close(restore?: boolean): void;
    toggled(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasPopover, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasPopover, "atlas-popover", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
/** Text-only help. Focus or hover opens; Escape dismisses without moving focus. */
declare class AtlasTooltip {
    readonly label: _angular_core.InputSignal<string>;
    readonly text: _angular_core.InputSignal<string>;
    readonly id: string;
    readonly tip: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly trigger: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    private timer?;
    constructor();
    stay(): void;
    show(): void;
    deferHide(): void;
    hide(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasTooltip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasTooltip, "atlas-tooltip", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { ATLAS_TASK, AtlasAccordionSection, AtlasActivityTimeline, AtlasAttachmentList, AtlasAutocomplete, AtlasBadge, AtlasButton, AtlasCalendar, AtlasCell, AtlasChart, AtlasCheckTree, AtlasCheckboxGroup, AtlasChoiceOverlay, AtlasChoiceState, AtlasCommandToolbar, AtlasContextMenu, AtlasDashboard, AtlasDashboardPanel, AtlasDatasheet, AtlasDateInput, AtlasDateRangeInput, AtlasDecimalInput, AtlasDialog, AtlasEditableGrid, AtlasEntryState, AtlasField, AtlasFieldset, AtlasFilterBuilder, AtlasHierarchyBase, AtlasIcon, AtlasInput, AtlasItemSelector, AtlasLatestRequest, AtlasListTemplate, AtlasListView, AtlasLoadingRegion, AtlasLookup, AtlasMasterDetail, AtlasMenuButton, AtlasMessageBox, AtlasMultiSelect, AtlasNotice, AtlasNumberInput, AtlasPanel, AtlasPivotTable, AtlasPopover, AtlasPopupMenu, AtlasProgress, AtlasPropertySheet, AtlasRadioGroup, AtlasRecordNavigator, AtlasRichText, AtlasRowDetail, AtlasSelect, AtlasSplitButton, AtlasSplitPane, AtlasStartMenu, AtlasStatusBar, AtlasTab, AtlasTable, AtlasTabs, AtlasTextInput, AtlasTextarea, AtlasToggle, AtlasTooltip, AtlasTotalsPanel, AtlasTree, AtlasTreeGrid, AtlasTreeSelect, AtlasUploadQueue, AtlasValidationNavigator, AtlasValidationSummary, AtlasValueControl, AtlasVirtualGrid, AtlasWindow, AtlasWorkspace, WorkspaceService, atlasCalendarDays, atlasChartDomain, atlasCheckLeaves, atlasCheckState, atlasCommandAllowed, atlasDashboardOrder, atlasDate, atlasEventsOn, atlasFeedbackPosition, atlasGroupRows, atlasHeaderBands, atlasMoveItems, atlasMovePanel, atlasPivot, atlasProgressValue, atlasPromptError, atlasRichText, atlasShiftDate, atlasShiftMonth, atlasSumDecimal, atlasSummaryQueryKey, atlasToggleChecks, atlasToolbarCapacity, atlasTransferItems, atlasUpdateRichBlock, atlasVirtualRange, atlasVisibleCommands, clampAtlasSplit, dateRangeError, dependentRecords, filterCollection, filterLookup, findTreeNode, flattenTree, lookupCell, matchesColumnFilters, matchesFilterRules, nextAtlasTab, nextLookupIndex, pageCollection, parseLocaleNumber, replaceEditedRow, sortByColumns, sortCollection, toggleChoice, validCalendarDate, validateEditRow };
export type { AtlasActivity, AtlasAttachment, AtlasCalendarEvent, AtlasCellContext, AtlasChartPoint, AtlasColumn, AtlasCommand, AtlasDateRange, AtlasEditColumn, AtlasFeedbackTone, AtlasFilterField, AtlasFilterOperator, AtlasFilterRule, AtlasListItem, AtlasLookupColumn, AtlasMessageResult, AtlasOption, AtlasPivotResult, AtlasProperty, AtlasPropertyValue, AtlasRecordOption, AtlasRichBlock, AtlasRichDocument, AtlasSavedView, AtlasServerSummary, AtlasSort, AtlasStartItem, AtlasSummary, AtlasTabChoice, AtlasTableQuery, AtlasTotalLine, AtlasTreeGridColumn, AtlasTreeNode, AtlasTreeRow, AtlasUploadAdapter, AtlasValidationIssue, AtlasValidationTarget, OpenTask, ScreenDefinition, WindowBounds, WorkspaceTask };
//# sourceMappingURL=bqatlas-ui.d.ts.map
