import * as pdfjs_dist_types_src_display_api from 'pdfjs-dist/types/src/display/api';
import * as _angular_core from '@angular/core';

declare class AtlasPdfViewer {
    readonly file: _angular_core.InputSignal<File>;
    readonly workerSrc: _angular_core.InputSignal<string>;
    readonly document: _angular_core.WritableSignal<pdfjs_dist_types_src_display_api.PDFDocumentProxy | null>;
    readonly page: _angular_core.WritableSignal<number>;
    readonly scale: _angular_core.WritableSignal<number>;
    readonly error: _angular_core.WritableSignal<string>;
    readonly loading: _angular_core.WritableSignal<boolean>;
    readonly pageText: _angular_core.WritableSignal<string>;
    private canvas;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasPdfViewer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasPdfViewer, "atlas-pdf-viewer", never, { "file": { "alias": "file"; "required": true; "isSignal": true; }; "workerSrc": { "alias": "workerSrc"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare function documentKind(file: Pick<File, "name" | "type">): "image" | "pdf" | "text" | "unsupported";
declare class AtlasDocumentViewer {
    readonly file: _angular_core.InputSignal<File | null>;
    readonly kind: _angular_core.WritableSignal<"text" | "image" | "pdf" | "unsupported">;
    readonly url: _angular_core.WritableSignal<string>;
    readonly pdfWorkerSrc: _angular_core.InputSignal<string>;
    readonly text: _angular_core.WritableSignal<string>;
    readonly error: _angular_core.WritableSignal<string>;
    readonly zoom: _angular_core.WritableSignal<number>;
    readonly rotation: _angular_core.WritableSignal<number>;
    readonly Math: Math;
    private stage;
    readonly stageWidth: _angular_core.WritableSignal<number>;
    readonly ratio: _angular_core.WritableSignal<number>;
    readonly imageWidth: _angular_core.Signal<number>;
    readonly imageHeight: _angular_core.Signal<number>;
    imageLoaded(event: Event): void;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDocumentViewer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasDocumentViewer, "atlas-document-viewer", never, { "file": { "alias": "file"; "required": false; "isSignal": true; }; "pdfWorkerSrc": { "alias": "pdfWorkerSrc"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { AtlasDocumentViewer, AtlasPdfViewer, documentKind };
//# sourceMappingURL=bqatlas-ui-documents.d.ts.map
