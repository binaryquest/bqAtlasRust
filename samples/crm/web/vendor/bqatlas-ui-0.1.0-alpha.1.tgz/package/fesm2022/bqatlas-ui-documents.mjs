import * as i0 from '@angular/core';
import { input, signal, viewChild, effect, ChangeDetectionStrategy, Component, computed } from '@angular/core';
import { AtlasButton } from '@bqatlas/ui';

class AtlasPdfViewer {
    file = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "file" }] : /* istanbul ignore next */ []));
    workerSrc = input("assets/pdfjs/pdf.worker.min.mjs", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "workerSrc" }] : /* istanbul ignore next */ []));
    document = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "document" }] : /* istanbul ignore next */ []));
    page = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []));
    scale = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scale" }] : /* istanbul ignore next */ []));
    error = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    loading = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    pageText = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageText" }] : /* istanbul ignore next */ []));
    canvas = viewChild("canvas", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canvas" }] : /* istanbul ignore next */ []));
    constructor() {
        effect((onCleanup) => {
            const file = this.file(), worker = this.workerSrc();
            let active = true;
            let task;
            this.document.set(null);
            this.page.set(1);
            this.scale.set(1);
            this.error.set("");
            this.loading.set(true);
            void (async () => {
                try {
                    const pdf = await import('pdfjs-dist');
                    if (!active)
                        return;
                    pdf.GlobalWorkerOptions.workerSrc = new URL(worker, globalThis.location.href).href;
                    const data = await file.arrayBuffer();
                    if (!active)
                        return;
                    task = pdf.getDocument({ data, standardFontDataUrl: worker.slice(0, worker.lastIndexOf("/") + 1) + "standard_fonts/" });
                    const doc = await task.promise;
                    if (active)
                        this.document.set(doc);
                }
                catch {
                    if (active) {
                        this.loading.set(false);
                        this.error.set("Unable to open PDF. It may be corrupt or password-protected. You can download the original.");
                    }
                }
            })();
            onCleanup(() => {
                active = false;
                void task?.destroy();
            });
        });
        effect((onCleanup) => {
            const doc = this.document(), page = this.page(), scale = this.scale(), canvas = this.canvas()?.nativeElement;
            if (!doc || !canvas)
                return;
            let active = true;
            let render;
            this.loading.set(true);
            this.error.set("");
            this.pageText.set("");
            void (async () => {
                try {
                    const pdfPage = await doc.getPage(page);
                    if (!active)
                        return;
                    let viewport = pdfPage.getViewport({ scale });
                    if (Math.max(viewport.width, viewport.height) > 4096)
                        viewport = pdfPage.getViewport({
                            scale: (scale * 4096) / Math.max(viewport.width, viewport.height),
                        });
                    const scratch = canvas.ownerDocument.createElement("canvas");
                    scratch.width = viewport.width;
                    scratch.height = viewport.height;
                    render = pdfPage.render({ canvas: scratch, viewport });
                    await render.promise;
                    if (!active)
                        return;
                    canvas.width = scratch.width;
                    canvas.height = scratch.height;
                    canvas.getContext("2d").drawImage(scratch, 0, 0);
                    const text = await pdfPage.getTextContent();
                    if (active)
                        this.pageText.set(text.items
                            .map((item) => ("str" in item ? item.str : ""))
                            .join(" "));
                }
                catch {
                    if (active)
                        this.error.set("Unable to render this page. Try another page or download the original.");
                }
                finally {
                    if (active)
                        this.loading.set(false);
                }
            })();
            onCleanup(() => {
                active = false;
                render?.cancel();
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPdfViewer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasPdfViewer, isStandalone: true, selector: "atlas-pdf-viewer", inputs: { file: { classPropertyName: "file", publicName: "file", isSignal: true, isRequired: true, transformFunction: null }, workerSrc: { classPropertyName: "workerSrc", publicName: "workerSrc", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "canvas", first: true, predicate: ["canvas"], descendants: true, isSignal: true }], ngImport: i0, template: `<div class="atlas-pdf-toolbar">
      <button
        atlasButton
        [disabled]="page() <= 1"
        (click)="page.update(p=>p-1)"
      >
        Previous page</button
      ><span>Page {{ page() }} of {{ document()?.numPages || 0 }}</span
      ><button
        atlasButton
        [disabled]="page() >= (document()?.numPages || 0)"
        (click)="page.update(p=>p+1)"
      >
        Next page</button
      ><button
        atlasButton
        [disabled]="scale() <= 0.5"
        (click)="scale.update(s=>s-0.25)"
      >
        PDF zoom out</button
      ><span>{{ scale() * 100 }}%</span
      ><button
        atlasButton
        [disabled]="scale() >= 2"
        (click)="scale.update(s=>s+0.25)"
      >
        PDF zoom in
      </button>
    </div>
    @if (error()) {
      <p role="alert">{{ error() }}</p>
    }
    @if (loading()) {
      <p role="status">Rendering PDF…</p>
    }
    <div class="atlas-pdf-canvas-stage">
      <canvas
        #canvas
        role="img"
        [attr.aria-label]="'PDF page ' + page()"
      ></canvas>
    </div>
    <details>
      <summary>Page text</summary>
      <pre class="atlas-text-stage">{{ pageText() }}</pre>
    </details>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPdfViewer, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-pdf-viewer",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<div class="atlas-pdf-toolbar">
      <button
        atlasButton
        [disabled]="page() <= 1"
        (click)="page.update(p=>p-1)"
      >
        Previous page</button
      ><span>Page {{ page() }} of {{ document()?.numPages || 0 }}</span
      ><button
        atlasButton
        [disabled]="page() >= (document()?.numPages || 0)"
        (click)="page.update(p=>p+1)"
      >
        Next page</button
      ><button
        atlasButton
        [disabled]="scale() <= 0.5"
        (click)="scale.update(s=>s-0.25)"
      >
        PDF zoom out</button
      ><span>{{ scale() * 100 }}%</span
      ><button
        atlasButton
        [disabled]="scale() >= 2"
        (click)="scale.update(s=>s+0.25)"
      >
        PDF zoom in
      </button>
    </div>
    @if (error()) {
      <p role="alert">{{ error() }}</p>
    }
    @if (loading()) {
      <p role="status">Rendering PDF…</p>
    }
    <div class="atlas-pdf-canvas-stage">
      <canvas
        #canvas
        role="img"
        [attr.aria-label]="'PDF page ' + page()"
      ></canvas>
    </div>
    <details>
      <summary>Page text</summary>
      <pre class="atlas-text-stage">{{ pageText() }}</pre>
    </details>`,
                }]
        }], ctorParameters: () => [], propDecorators: { file: [{ type: i0.Input, args: [{ isSignal: true, alias: "file", required: true }] }], workerSrc: [{ type: i0.Input, args: [{ isSignal: true, alias: "workerSrc", required: false }] }], canvas: [{ type: i0.ViewChild, args: ["canvas", { isSignal: true }] }] } });

function documentKind(file) {
    if ([
        "image/png",
        "image/jpeg",
        "image/webp",
        "image/gif",
        "image/avif",
    ].includes(file.type))
        return "image";
    if (file.type === "application/pdf" ||
        (!file.type && /\.pdf$/i.test(file.name)))
        return "pdf";
    if (file.type.startsWith("text/") || /\.(txt|csv|md|json)$/i.test(file.name))
        return "text";
    return "unsupported";
}
class AtlasDocumentViewer {
    file = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "file" }] : /* istanbul ignore next */ []));
    kind = signal("unsupported", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "kind" }] : /* istanbul ignore next */ []));
    url = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "url" }] : /* istanbul ignore next */ []));
    pdfWorkerSrc = input("assets/pdfjs/pdf.worker.min.mjs", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pdfWorkerSrc" }] : /* istanbul ignore next */ []));
    text = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    error = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    zoom = signal(100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "zoom" }] : /* istanbul ignore next */ []));
    rotation = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rotation" }] : /* istanbul ignore next */ []));
    Math = Math;
    stage = viewChild("stage", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stage" }] : /* istanbul ignore next */ []));
    stageWidth = signal(600, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stageWidth" }] : /* istanbul ignore next */ []));
    ratio = signal(0.65, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ratio" }] : /* istanbul ignore next */ []));
    imageWidth = computed(() => (this.stageWidth() * this.zoom()) / 100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageWidth" }] : /* istanbul ignore next */ []));
    imageHeight = computed(() => this.imageWidth() * this.ratio(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageHeight" }] : /* istanbul ignore next */ []));
    imageLoaded(event) {
        const img = event.target;
        this.ratio.set(img.naturalHeight / img.naturalWidth);
    }
    constructor() {
        effect((onCleanup) => {
            const stage = this.stage()?.nativeElement;
            if (!stage)
                return;
            const observer = new ResizeObserver(() => this.stageWidth.set(Math.max(80, stage.clientWidth - 40)));
            observer.observe(stage);
            onCleanup(() => observer.disconnect());
        });
        effect((onCleanup) => {
            const file = this.file();
            this.error.set("");
            this.text.set("Loading text…");
            this.zoom.set(100);
            this.rotation.set(0);
            if (!file) {
                this.url.set("");
                return;
            }
            const url = URL.createObjectURL(file);
            let active = true;
            this.url.set(url);
            const kind = documentKind(file);
            this.kind.set(kind);
            if (kind === "text")
                void file
                    .slice(0, 100000)
                    .text()
                    .then((text) => {
                    if (active)
                        this.text.set(text +
                            (file.size > 100000
                                ? "\n\n[Preview truncated to 100 KB]"
                                : ""));
                })
                    .catch(() => {
                    if (active)
                        this.error.set("Unable to read this file.");
                });
            onCleanup(() => {
                active = false;
                URL.revokeObjectURL(url);
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDocumentViewer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasDocumentViewer, isStandalone: true, selector: "atlas-document-viewer", inputs: { file: { classPropertyName: "file", publicName: "file", isSignal: true, isRequired: false, transformFunction: null }, pdfWorkerSrc: { classPropertyName: "pdfWorkerSrc", publicName: "pdfWorkerSrc", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "stage", first: true, predicate: ["stage"], descendants: true, isSignal: true }], ngImport: i0, template: `<section
    class="atlas-document-viewer"
    aria-label="Document viewer"
  >
    @if (file(); as file) {
      <header>
        <strong>{{ file.name }}</strong
        ><span>{{ (file.size / 1024).toFixed(1) }} KB</span
        ><a atlasButton [href]="url()" [download]="file.name"
          >Download original</a
        >
        @if (kind() === "image") {
          <button
            atlasButton
            (click)="zoom.set(Math.max(25, zoom() - 25))"
            [disabled]="zoom() <= 25"
          >
            Zoom out</button
          ><span>{{ zoom() }}%</span
          ><button
            atlasButton
            (click)="zoom.set(Math.min(300, zoom() + 25))"
            [disabled]="zoom() >= 300"
          >
            Zoom in</button
          ><button atlasButton (click)="rotation.set((rotation() + 90) % 360)">
            Rotate</button
          ><button atlasButton (click)="zoom.set(100); rotation.set(0)">
            Reset view
          </button>
        }
      </header>
      @if (error()) {
        <p role="alert">{{ error() }}</p>
      }
      @switch (kind()) {
        @case ("image") {
          <div #stage class="atlas-image-stage">
            <div
              class="atlas-image-layout"
              [style.width.px]="rotation() % 180 ? imageHeight() : imageWidth()"
              [style.height.px]="
                rotation() % 180 ? imageWidth() : imageHeight()
              "
            >
              <img
                (load)="imageLoaded($event)"
                [src]="url()"
                [alt]="file.name"
                [style.width.px]="imageWidth()"
                [style.transform]="
                  'translate(-50%, -50%) rotate(' + rotation() + 'deg)'
                "
                (error)="
                  error.set(
                    'This image could not be decoded. Download the original to inspect it.'
                  )
                "
              />
            </div>
          </div>
        }
        @case ("pdf") {
          <atlas-pdf-viewer [file]="file" [workerSrc]="pdfWorkerSrc()" />
        }
        @case ("text") {
          <pre class="atlas-text-stage">{{ text() }}</pre>
        }
        @default {
          <p>
            Preview is unavailable for this file type. Download the original to
            open it in a suitable application.
          </p>
        }
      }
    } @else {
      <p>Select a ready attachment to preview it.</p>
    }
  </section>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "component", type: AtlasPdfViewer, selector: "atlas-pdf-viewer", inputs: ["file", "workerSrc"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDocumentViewer, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-document-viewer",
                    imports: [AtlasButton, AtlasPdfViewer],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<section
    class="atlas-document-viewer"
    aria-label="Document viewer"
  >
    @if (file(); as file) {
      <header>
        <strong>{{ file.name }}</strong
        ><span>{{ (file.size / 1024).toFixed(1) }} KB</span
        ><a atlasButton [href]="url()" [download]="file.name"
          >Download original</a
        >
        @if (kind() === "image") {
          <button
            atlasButton
            (click)="zoom.set(Math.max(25, zoom() - 25))"
            [disabled]="zoom() <= 25"
          >
            Zoom out</button
          ><span>{{ zoom() }}%</span
          ><button
            atlasButton
            (click)="zoom.set(Math.min(300, zoom() + 25))"
            [disabled]="zoom() >= 300"
          >
            Zoom in</button
          ><button atlasButton (click)="rotation.set((rotation() + 90) % 360)">
            Rotate</button
          ><button atlasButton (click)="zoom.set(100); rotation.set(0)">
            Reset view
          </button>
        }
      </header>
      @if (error()) {
        <p role="alert">{{ error() }}</p>
      }
      @switch (kind()) {
        @case ("image") {
          <div #stage class="atlas-image-stage">
            <div
              class="atlas-image-layout"
              [style.width.px]="rotation() % 180 ? imageHeight() : imageWidth()"
              [style.height.px]="
                rotation() % 180 ? imageWidth() : imageHeight()
              "
            >
              <img
                (load)="imageLoaded($event)"
                [src]="url()"
                [alt]="file.name"
                [style.width.px]="imageWidth()"
                [style.transform]="
                  'translate(-50%, -50%) rotate(' + rotation() + 'deg)'
                "
                (error)="
                  error.set(
                    'This image could not be decoded. Download the original to inspect it.'
                  )
                "
              />
            </div>
          </div>
        }
        @case ("pdf") {
          <atlas-pdf-viewer [file]="file" [workerSrc]="pdfWorkerSrc()" />
        }
        @case ("text") {
          <pre class="atlas-text-stage">{{ text() }}</pre>
        }
        @default {
          <p>
            Preview is unavailable for this file type. Download the original to
            open it in a suitable application.
          </p>
        }
      }
    } @else {
      <p>Select a ready attachment to preview it.</p>
    }
  </section>`,
                }]
        }], ctorParameters: () => [], propDecorators: { file: [{ type: i0.Input, args: [{ isSignal: true, alias: "file", required: false }] }], pdfWorkerSrc: [{ type: i0.Input, args: [{ isSignal: true, alias: "pdfWorkerSrc", required: false }] }], stage: [{ type: i0.ViewChild, args: ["stage", { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { AtlasDocumentViewer, AtlasPdfViewer, documentKind };
//# sourceMappingURL=bqatlas-ui-documents.mjs.map
