import * as i0 from '@angular/core';
import { input, ChangeDetectionStrategy, Component, Directive, InjectionToken, signal, computed, Injectable, inject, Injector, ElementRef, output, viewChild, DestroyRef, afterNextRender, effect, model, TemplateRef, contentChildren, linkedSignal, contentChild, untracked, forwardRef } from '@angular/core';
import { NgComponentOutlet, NgTemplateOutlet } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class AtlasIcon {
    name = input("grid", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    paths = {
        grid: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
        layers: "m12 3 10 5-10 5L2 8z M2 12l10 5 10-5 M2 16l10 5 10-5",
        window: "M3 4h18v16H3z M3 9h18 M6 6.5h.1 M9 6.5h.1",
        orders: "M7 3h10v3h3v15H4V6h3z M7 3v5h10V3 M8 12h8 M8 16h5",
        users: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M13 3a4 4 0 0 1 0 8 M22 21v-2a4 4 0 0 0-3-3.87 M9 3a4 4 0 1 1 0 8 4 4 0 0 1 0-8",
        box: "m12 3 9 5v9l-9 5-9-5V8z M3 8l9 5 9-5 M12 13v9 M7 5l10 5",
        plus: "M12 5v14 M5 12h14",
        close: "M6 6l12 12 M18 6 6 18",
        minimize: "M5 17h14",
        maximize: "M4 9V4h5 M15 4h5v5 M20 15v5h-5 M9 20H4v-5",
        restore: "M8 8h12v12H8z M4 16V4h12",
        search: "M21 21l-5-5 M10.5 3a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15",
        chevron: "m9 5 7 7-7 7",
        down: "m6 9 6 6 6-6",
        back: "m14 5-7 7 7 7 M7 12h14",
        check: "m5 12 4 4L19 6",
        settings: "M4 7h16 M4 17h16 M8 4v6 M16 14v6",
        code: "m8 6-6 6 6 6 M16 6l6 6-6 6 M14 3l-4 18",
        monitor: "M3 3h18v13H3z M8 21h8 M12 16v5",
        phone: "M7 2h10v20H7z M11 18h2",
        moon: "M21 13A9 9 0 0 1 11 3a9 9 0 1 0 10 10",
        sun: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v2 M12 20v2 M2 12h2 M20 12h2 M5 5l1 1 M18 18l1 1 M5 19l1-1 M18 6l1-1",
        arrow: "M5 12h14 m-5-5 5 5-5 5",
        refresh: "M20 7v5h-5 M4 17v-5h5 M6 6a8 8 0 0 1 14 6 M18 18A8 8 0 0 1 4 12",
        save: "M4 3h13l4 4v14H3V3z M7 3v6h9V3 M7 21v-8h10v8",
        mail: "M3 5h18v14H3z m0 0 9 7 9-7",
        activity: "M2 12h5l3-8 4 16 3-8h5",
        book: "M12 5C8 2 3 3 3 3v17s5-1 9 2c4-3 9-2 9-2V3s-5-1-9 2z M12 5v17",
        bolt: "m13 2-9 12h7l-1 8 10-12h-7z",
        filter: "M3 5h18l-7 8v7l-4-2v-5z",
        left: "M3 4h18v16H3z M12 4v16 M6 8h3 M6 12h3",
        right: "M3 4h18v16H3z M12 4v16 M15 8h3 M15 12h3",
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasIcon, isStandalone: true, selector: "atlas-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1.7"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path [attr.d]="paths[name()] || paths['grid']" />
  </svg>`, isInline: true, styles: [":host{display:inline-flex;width:18px;height:18px;flex-shrink:0}svg{width:100%;height:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasIcon, decorators: [{
            type: Component,
            args: [{ selector: "atlas-icon", changeDetection: ChangeDetectionStrategy.OnPush, template: `<svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1.7"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path [attr.d]="paths[name()] || paths['grid']" />
  </svg>`, styles: [":host{display:inline-flex;width:18px;height:18px;flex-shrink:0}svg{width:100%;height:100%}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }] } });
class AtlasButton {
    variant = input("secondary", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasButton, isStandalone: true, selector: "button[atlasButton], a[atlasButton]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-variant": "variant()" }, classAttribute: "atlas-button" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasButton, decorators: [{
            type: Directive,
            args: [{
                    selector: "button[atlasButton], a[atlasButton]",
                    host: { class: "atlas-button", "[attr.data-variant]": "variant()" },
                }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }] } });
class AtlasInput {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.7", type: AtlasInput, isStandalone: true, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]", host: { classAttribute: "atlas-input" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasInput, decorators: [{
            type: Directive,
            args: [{
                    selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]",
                    host: { class: "atlas-input" },
                }]
        }] });
class AtlasBadge {
    tone = input("neutral", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasBadge, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasBadge, isStandalone: true, selector: "atlas-badge", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-tone": "tone()" }, classAttribute: "atlas-badge" }, ngImport: i0, template: "<ng-content />", isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasBadge, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-badge",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-badge", "[attr.data-tone]": "tone()" },
                    template: "<ng-content />",
                }]
        }], propDecorators: { tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }] } });
class AtlasPanel {
    title = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPanel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasPanel, isStandalone: true, selector: "atlas-panel", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "atlas-panel" }, ngImport: i0, template: `@if (title()) {
      <header class="atlas-panel-header">
        <h3>{{ title() }}</h3>
        <ng-content select="[panelActions]" />
      </header>
    }
    <div class="atlas-panel-toolbar"><ng-content select="[panelToolbar]" /></div>
    <div class="atlas-panel-body"><ng-content /></div>
    <footer class="atlas-panel-footer"><ng-content select="[panelFooter]" /></footer>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPanel, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-panel",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-panel" },
                    template: `@if (title()) {
      <header class="atlas-panel-header">
        <h3>{{ title() }}</h3>
        <ng-content select="[panelActions]" />
      </header>
    }
    <div class="atlas-panel-toolbar"><ng-content select="[panelToolbar]" /></div>
    <div class="atlas-panel-body"><ng-content /></div>
    <footer class="atlas-panel-footer"><ng-content select="[panelFooter]" /></footer>`,
                }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }] } });
class AtlasField {
    label = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    required = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []));
    hint = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []));
    error = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasField, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasField, isStandalone: true, selector: "atlas-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "atlas-field" }, ngImport: i0, template: `<label [attr.for]="controlId()"
      >{{ label() }}
      @if (required()) {
        <span aria-hidden="true">*</span>
      }</label
    ><ng-content />
    @if (error()) {
      <small
        class="atlas-field-error"
        [id]="controlId() + '-error'"
        role="alert"
        >{{ error() }}</small
      >
    } @else if (hint()) {
      <small [id]="controlId() + '-hint'">{{ hint() }}</small>
    }`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasField, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-field",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-field" },
                    template: `<label [attr.for]="controlId()"
      >{{ label() }}
      @if (required()) {
        <span aria-hidden="true">*</span>
      }</label
    ><ng-content />
    @if (error()) {
      <small
        class="atlas-field-error"
        [id]="controlId() + '-error'"
        role="alert"
        >{{ error() }}</small
      >
    } @else if (hint()) {
      <small [id]="controlId() + '-hint'">{{ hint() }}</small>
    }`,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }] } });

const ATLAS_TASK = new InjectionToken("ATLAS_TASK");
/** Presentation-independent task identity and lifecycle. No ERP or HTTP dependencies. */
class WorkspaceService {
    definitions = new Map();
    sequence = 0;
    tasks = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tasks" }] : /* istanbul ignore next */ []));
    activeId = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []));
    stackOrder = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stackOrder" }] : /* istanbul ignore next */ []));
    pendingClose = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pendingClose" }] : /* istanbul ignore next */ []));
    closeQueue = [];
    closingAll = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closingAll" }] : /* istanbul ignore next */ []));
    hasPendingWork = computed(() => this.tasks().some(task => task.dirty() || task.saving()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasPendingWork" }] : /* istanbul ignore next */ []));
    active = computed(() => this.tasks().find((t) => t.id === this.activeId()) ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    closing = computed(() => this.tasks().find((t) => t.id === this.pendingClose()) ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closing" }] : /* istanbul ignore next */ []));
    viewport = signal({ width: 1100, height: 690 }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewport" }] : /* istanbul ignore next */ []));
    mobile = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobile" }] : /* istanbul ignore next */ []));
    history = [];
    register(...definitions) {
        for (const def of definitions) {
            if (this.definitions.has(def.id))
                throw new Error(`Screen already registered: ${def.id}`);
            this.definitions.set(def.id, def);
        }
    }
    open(request) {
        const def = this.definitions.get(request.screen);
        if (!def)
            throw new Error(`Unknown screen: ${request.screen}`);
        if (def.instance === "keyed" && !request.key)
            throw new Error(`Screen ${def.id} requires a key`);
        const existing = this.tasks().find((t) => t.screen === def.id &&
            (def.instance === "singleton" ||
                (def.instance === "keyed" && t.key === request.key)));
        if (existing) {
            this.activate(existing.id);
            return this.tasks().find((t) => t.id === existing.id);
        }
        const offset = (this.tasks().length % 6) * 28;
        const task = {
            id: `task-${++this.sequence}`,
            screen: def.id,
            key: request.key,
            title: request.title ?? def.title,
            icon: def.icon,
            component: def.component,
            data: signal(request.data),
            dirty: signal(false),
            saving: signal(false),
            error: signal(""),
            bounds: this.clamp({
                x: 32 + offset,
                y: 30 + offset,
                width: def.width ?? 780,
                height: def.height ?? 530,
            }),
            mode: "floating",
            minimized: false,
            origin: request.origin,
            lifecycle: {},
        };
        this.tasks.update((tasks) => [...tasks, task]);
        this.activate(task.id);
        return this.tasks().find((t) => t.id === task.id);
    }
    activate(id) {
        const task = this.tasks().find((t) => t.id === id);
        if (!task)
            return;
        const previous = this.activeId();
        if (previous && previous !== id) {
            this.history.push(previous);
            if (this.history.length > 100)
                this.history.shift();
        }
        this.patch(id, { minimized: false });
        this.stackOrder.update((ids) => [...ids.filter((item) => item !== id), id]);
        this.activeId.set(id);
    }
    minimize(id) {
        this.patch(id, { minimized: true });
        if (this.activeId() === id)
            this.activeId.set(this.topVisible());
    }
    toggleMaximize(id) {
        const task = this.tasks().find((t) => t.id === id);
        if (task) {
            this.patch(id, {
                mode: task.mode === "floating" ? "maximized" : "floating",
            });
            this.activate(id);
        }
    }
    move(id, bounds) {
        this.patch(id, { bounds: this.clamp(bounds), mode: "floating" });
    }
    snap(id, side) {
        const { width, height } = this.viewport();
        this.move(id, {
            x: side === "left" ? 8 : width / 2 + 4,
            y: 8,
            width: width / 2 - 12,
            height: height - 16,
        });
    }
    setViewport(width, height, mobile) {
        this.mobile.set(mobile);
        if (mobile)
            return;
        this.viewport.set({ width, height });
        this.tasks.update((tasks) => tasks.map((task) => ({ ...task, bounds: this.clamp(task.bounds) })));
    }
    clamp(bounds) {
        const viewport = this.viewport();
        const width = Math.min(Math.max(340, bounds.width), Math.max(100, viewport.width - 16));
        const height = Math.min(Math.max(250, bounds.height), Math.max(100, viewport.height - 16));
        return {
            width,
            height,
            x: Math.max(8, Math.min(bounds.x, viewport.width - width - 8)),
            y: Math.max(8, Math.min(bounds.y, viewport.height - height - 8)),
        };
    }
    /** Close a snapshot sequentially through the existing save/discard/cancel dialog. */
    requestCloseAll() {
        if (this.pendingClose() || this.tasks().some(task => task.saving()))
            return false;
        this.closeQueue = this.tasks().map(task => task.id).reverse();
        this.closingAll.set(true);
        this.advanceCloseAll();
        return true;
    }
    advanceCloseAll() {
        while (this.closeQueue.length) {
            const id = this.closeQueue.shift();
            const task = this.tasks().find(task => task.id === id);
            if (!task)
                continue;
            if (task.dirty() || task.saving()) {
                this.activate(id);
                this.pendingClose.set(id);
                return;
            }
            this.remove(id);
        }
        this.closingAll.set(false);
    }
    async requestClose(id) {
        if (this.closingAll())
            return;
        const task = this.tasks().find((t) => t.id === id);
        if (!task || task.saving())
            return;
        if (task.dirty()) {
            this.activate(id);
            this.pendingClose.set(id);
        }
        else
            this.remove(id);
    }
    cancelClose() {
        if (!this.closing()?.saving()) {
            this.pendingClose.set(null);
            this.closeQueue = [];
            this.closingAll.set(false);
        }
    }
    discardClose() {
        const task = this.closing();
        if (task && !task.saving()) {
            this.pendingClose.set(null);
            this.remove(task.id);
            if (this.closingAll())
                this.advanceCloseAll();
        }
    }
    async save(id) {
        const task = this.tasks().find((t) => t.id === id);
        if (!task || !task.lifecycle.save || task.saving())
            return false;
        task.saving.set(true);
        task.error.set("");
        try {
            await task.lifecycle.save();
            // A sign-out may dispose this task while its provider is still resolving.
            // Presentation updates copy task objects but preserve lifecycle identity.
            if (!this.tasks().some(current => current.id === id && current.lifecycle === task.lifecycle))
                return false;
            task.dirty.set(false);
            return true;
        }
        catch (error) {
            task.error.set(error instanceof Error
                ? error.message
                : "Unable to save. Please try again.");
            return false;
        }
        finally {
            task.saving.set(false);
        }
    }
    async saveAndClose() {
        const task = this.closing();
        if (task && (await this.save(task.id)) && this.pendingClose() === task.id) {
            this.pendingClose.set(null);
            this.remove(task.id);
            if (this.closingAll())
                this.advanceCloseAll();
        }
    }
    back() {
        const origin = this.active()?.origin;
        if (origin && this.tasks().some((t) => t.id === origin)) {
            this.activate(origin);
            return;
        }
        // Activation history is for task switching, not navigation. A root task
        // returns home, avoiding an endless Back loop between independent tasks.
        this.activeId.set(null);
    }
    showDesktop() {
        this.activeId.set(null);
    }
    cascade() {
        this.tasks.update((tasks) => tasks.map((task, index) => ({
            ...task,
            mode: "floating",
            minimized: false,
            bounds: this.clamp({
                x: 20 + (index % 7) * 30,
                y: 20 + (index % 7) * 28,
                width: 760,
                height: 510,
            }),
        })));
    }
    /** Discard all retained task state when the authenticated session ends. */
    disposeAll() {
        const tasks = this.tasks();
        this.tasks.set([]);
        this.stackOrder.set([]);
        this.activeId.set(null);
        this.pendingClose.set(null);
        this.history.length = 0;
        this.closeQueue = [];
        this.closingAll.set(false);
        for (const task of tasks) {
            try {
                task.lifecycle.dispose?.();
            }
            catch { /* One cleanup failure must not retain other tasks. */ }
        }
    }
    rekey(id, key) {
        const task = this.tasks().find(t => t.id === id);
        if (!task)
            return;
        if (this.tasks().some(t => t.id !== id && t.screen === task.screen && t.key === key))
            throw new Error(`Task already open: ${key}`);
        this.patch(id, { key });
    }
    topVisible() {
        return ([...this.stackOrder()]
            .reverse()
            .find((id) => this.tasks().some((t) => t.id === id && !t.minimized)) ??
            null);
    }
    patch(id, patch) {
        this.tasks.update((tasks) => tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)));
    }
    remove(id) {
        const task = this.tasks().find((t) => t.id === id);
        task?.lifecycle.dispose?.();
        this.tasks.update((tasks) => tasks.filter((t) => t.id !== id));
        this.stackOrder.update((ids) => ids.filter((item) => item !== id));
        for (let i = this.history.length - 1; i >= 0; i--)
            if (this.history[i] === id)
                this.history.splice(i, 1);
        if (this.activeId() === id) {
            const origin = this.tasks().find((t) => t.id === task?.origin);
            if (origin)
                this.activate(origin.id);
            else
                this.activeId.set(this.topVisible());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: WorkspaceService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: WorkspaceService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: WorkspaceService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

class AtlasWindow {
    task = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "task" }] : /* istanbul ignore next */ []));
    layer = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "layer" }] : /* istanbul ignore next */ []));
    ws = inject(WorkspaceService);
    parent = inject(Injector);
    element = inject((ElementRef));
    taskInjector;
    edges = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];
    drag = null;
    ngOnInit() {
        this.taskInjector = Injector.create({
            providers: [{ provide: ATLAS_TASK, useValue: this.task() }],
            parent: this.parent,
        });
    }
    activate() {
        if (this.ws.activeId() !== this.task().id)
            this.ws.activate(this.task().id);
    }
    saveShortcut(event) {
        // Editors can handle their own validation/permissions first. The fallback
        // also covers initial window focus and title-bar controls.
        const task = this.task();
        if (event.defaultPrevented || this.ws.pendingClose() || this.ws.activeId() !== task.id || !task.lifecycle.save)
            return;
        event.preventDefault();
        void this.ws.save(task.id);
    }
    maximize(event) {
        if (!this.ws.mobile() && !event.target.closest("button"))
            this.ws.toggleMaximize(this.task().id);
    }
    start(event, edge) {
        if (this.ws.mobile() ||
            this.task().mode === "maximized" ||
            event.button !== 0 ||
            (edge === "move" && event.target.closest("button")))
            return;
        event.preventDefault();
        this.activate();
        this.drag = {
            x: event.clientX,
            y: event.clientY,
            bounds: { ...this.task().bounds },
            edge,
        };
        event.currentTarget.setPointerCapture(event.pointerId);
    }
    move(event) {
        if (!this.drag)
            return;
        const { x, y, bounds: b, edge } = this.drag;
        const dx = event.clientX - x, dy = event.clientY - y;
        const next = { ...b };
        if (edge === "move") {
            next.x += dx;
            next.y += dy;
        }
        else {
            if (edge.includes("e"))
                next.width += dx;
            if (edge.includes("s"))
                next.height += dy;
            if (edge.includes("w")) {
                const delta = Math.min(dx, b.width - 340);
                next.x += delta;
                next.width -= delta;
            }
            if (edge.includes("n")) {
                const delta = Math.min(dy, b.height - 250);
                next.y += delta;
                next.height -= delta;
            }
        }
        this.ws.move(this.task().id, next);
    }
    end(event) {
        this.drag = null;
        const target = event.currentTarget;
        if (target.hasPointerCapture(event.pointerId))
            target.releasePointerCapture(event.pointerId);
    }
    resizeKey(event) {
        const changes = {
            ArrowRight: [20, 0],
            ArrowLeft: [-20, 0],
            ArrowDown: [0, 20],
            ArrowUp: [0, -20],
        };
        const change = changes[event.key];
        if (change) {
            event.preventDefault();
            this.ws.move(this.task().id, {
                ...this.task().bounds,
                width: this.task().bounds.width + change[0],
                height: this.task().bounds.height + change[1],
            });
        }
    }
    moveKey(event) {
        if (event.target !== event.currentTarget ||
            this.ws.mobile() ||
            this.task().mode !== "floating")
            return;
        const changes = {
            ArrowRight: [20, 0],
            ArrowLeft: [-20, 0],
            ArrowDown: [0, 20],
            ArrowUp: [0, -20],
        };
        const change = changes[event.key];
        if (change) {
            event.preventDefault();
            this.ws.move(this.task().id, {
                ...this.task().bounds,
                x: this.task().bounds.x + change[0],
                y: this.task().bounds.y + change[1],
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasWindow, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasWindow, isStandalone: true, selector: "atlas-window", inputs: { task: { classPropertyName: "task", publicName: "task", isSignal: true, isRequired: true, transformFunction: null }, layer: { classPropertyName: "layer", publicName: "layer", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "region", "tabindex": "-1" }, listeners: { "pointerdown": "activate()", "focusin": "activate()", "keydown.control.s": "saveShortcut($event)", "keydown.meta.s": "saveShortcut($event)" }, properties: { "class.is-active": "ws.activeId()===task().id", "class.is-maximized": "task().mode===\"maximized\"", "class.is-mobile": "ws.mobile()", "class.is-hidden": "task().minimized || (ws.mobile() && ws.activeId()!==task().id)", "style.left.px": "task().bounds.x", "style.top.px": "task().bounds.y", "style.width.px": "task().bounds.width", "style.height.px": "task().bounds.height", "style.z-index": "layer()", "attr.aria-labelledby": "task().id+\"-title\"", "attr.data-task-id": "task().id" }, classAttribute: "atlas-window" }, ngImport: i0, template: `
    <header
      class="atlas-window-titlebar"
      tabindex="0"
      aria-label="Window title bar. Use arrow keys to move."
      (keydown)="moveKey($event)"
      (pointerdown)="start($event, 'move')"
      (pointermove)="move($event)"
      (pointerup)="end($event)"
      (pointercancel)="end($event)"
      (dblclick)="maximize($event)"
    >
      @if (ws.mobile()) {
        <button
          class="atlas-window-control"
          aria-label="Back to previous task"
          (click)="ws.back()"
        >
          <atlas-icon name="back" />
        </button>
      }
      <span class="atlas-window-symbol"
        ><atlas-icon [name]="task().icon"
      /></span>
      <h2 [id]="task().id + '-title'">{{ task().title }}</h2>
      @if (task().dirty()) {
        <span
          class="atlas-dirty-dot"
          title="Unsaved changes"
          aria-label="Unsaved changes"
        ></span>
      }
      <span class="atlas-window-title-spacer"></span>
      @if (!ws.mobile()) {
        <button
          class="atlas-window-control snap-control"
          aria-label="Snap window left"
          title="Snap left"
          (click)="ws.snap(task().id, 'left')"
        >
          <atlas-icon name="left" />
        </button>
        <button
          class="atlas-window-control snap-control"
          aria-label="Snap window right"
          title="Snap right"
          (click)="ws.snap(task().id, 'right')"
        >
          <atlas-icon name="right" />
        </button>
        <span class="atlas-title-divider"></span>
        <button
          class="atlas-window-control"
          aria-label="Minimize window"
          title="Minimize"
          (click)="ws.minimize(task().id)"
        >
          <atlas-icon name="minimize" />
        </button>
        <button
          class="atlas-window-control"
          [attr.aria-label]="
            task().mode === 'maximized' ? 'Restore window' : 'Maximize window'
          "
          (click)="ws.toggleMaximize(task().id)"
        >
          <atlas-icon
            [name]="task().mode === 'maximized' ? 'restore' : 'maximize'"
          />
        </button>
      }
      <button
        class="atlas-window-control close-control"
        aria-label="Close window"
        [disabled]="task().saving()"
        (click)="ws.requestClose(task().id)"
      >
        <atlas-icon name="close" />
      </button>
    </header>
    <div class="atlas-window-content">
      <ng-container
        *ngComponentOutlet="task().component; injector: taskInjector"
      />
    </div>
    @if (!ws.mobile() && task().mode === "floating") {
      @for (edge of edges; track edge) {
        <div
          class="atlas-resize-handle"
          [attr.data-edge]="edge"
          (pointerdown)="start($event, edge)"
          (pointermove)="move($event)"
          (pointerup)="end($event)"
          (pointercancel)="end($event)"
        ></div>
      }
      <button
        class="atlas-resize-keyboard"
        aria-label="Resize window: use arrow keys"
        title="Use arrow keys to resize"
        (keydown)="resizeKey($event)"
      >
        ⌟
      </button>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletEnvironmentInjector", "ngComponentOutletContent", "ngComponentOutletNgModule"], exportAs: ["ngComponentOutlet"] }, { kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasWindow, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-window",
                    imports: [NgComponentOutlet, AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        class: "atlas-window",
                        "[class.is-active]": "ws.activeId()===task().id",
                        "[class.is-maximized]": 'task().mode==="maximized"',
                        "[class.is-mobile]": "ws.mobile()",
                        "[class.is-hidden]": "task().minimized || (ws.mobile() && ws.activeId()!==task().id)",
                        "[style.left.px]": "task().bounds.x",
                        "[style.top.px]": "task().bounds.y",
                        "[style.width.px]": "task().bounds.width",
                        "[style.height.px]": "task().bounds.height",
                        "[style.z-index]": "layer()",
                        "[attr.aria-labelledby]": 'task().id+"-title"',
                        "[attr.data-task-id]": "task().id",
                        role: "region",
                        tabindex: "-1",
                        "(pointerdown)": "activate()",
                        "(focusin)": "activate()",
                        "(keydown.control.s)": "saveShortcut($event)",
                        "(keydown.meta.s)": "saveShortcut($event)",
                    },
                    template: `
    <header
      class="atlas-window-titlebar"
      tabindex="0"
      aria-label="Window title bar. Use arrow keys to move."
      (keydown)="moveKey($event)"
      (pointerdown)="start($event, 'move')"
      (pointermove)="move($event)"
      (pointerup)="end($event)"
      (pointercancel)="end($event)"
      (dblclick)="maximize($event)"
    >
      @if (ws.mobile()) {
        <button
          class="atlas-window-control"
          aria-label="Back to previous task"
          (click)="ws.back()"
        >
          <atlas-icon name="back" />
        </button>
      }
      <span class="atlas-window-symbol"
        ><atlas-icon [name]="task().icon"
      /></span>
      <h2 [id]="task().id + '-title'">{{ task().title }}</h2>
      @if (task().dirty()) {
        <span
          class="atlas-dirty-dot"
          title="Unsaved changes"
          aria-label="Unsaved changes"
        ></span>
      }
      <span class="atlas-window-title-spacer"></span>
      @if (!ws.mobile()) {
        <button
          class="atlas-window-control snap-control"
          aria-label="Snap window left"
          title="Snap left"
          (click)="ws.snap(task().id, 'left')"
        >
          <atlas-icon name="left" />
        </button>
        <button
          class="atlas-window-control snap-control"
          aria-label="Snap window right"
          title="Snap right"
          (click)="ws.snap(task().id, 'right')"
        >
          <atlas-icon name="right" />
        </button>
        <span class="atlas-title-divider"></span>
        <button
          class="atlas-window-control"
          aria-label="Minimize window"
          title="Minimize"
          (click)="ws.minimize(task().id)"
        >
          <atlas-icon name="minimize" />
        </button>
        <button
          class="atlas-window-control"
          [attr.aria-label]="
            task().mode === 'maximized' ? 'Restore window' : 'Maximize window'
          "
          (click)="ws.toggleMaximize(task().id)"
        >
          <atlas-icon
            [name]="task().mode === 'maximized' ? 'restore' : 'maximize'"
          />
        </button>
      }
      <button
        class="atlas-window-control close-control"
        aria-label="Close window"
        [disabled]="task().saving()"
        (click)="ws.requestClose(task().id)"
      >
        <atlas-icon name="close" />
      </button>
    </header>
    <div class="atlas-window-content">
      <ng-container
        *ngComponentOutlet="task().component; injector: taskInjector"
      />
    </div>
    @if (!ws.mobile() && task().mode === "floating") {
      @for (edge of edges; track edge) {
        <div
          class="atlas-resize-handle"
          [attr.data-edge]="edge"
          (pointerdown)="start($event, edge)"
          (pointermove)="move($event)"
          (pointerup)="end($event)"
          (pointercancel)="end($event)"
        ></div>
      }
      <button
        class="atlas-resize-keyboard"
        aria-label="Resize window: use arrow keys"
        title="Use arrow keys to resize"
        (keydown)="resizeKey($event)"
      >
        ⌟
      </button>
    }
  `,
                }]
        }], propDecorators: { task: [{ type: i0.Input, args: [{ isSignal: true, alias: "task", required: true }] }], layer: [{ type: i0.Input, args: [{ isSignal: true, alias: "layer", required: false }] }] } });

function atlasVisibleCommands(commands, permissions) {
    return commands.filter((command) => !command.hidden &&
        (!command.permission || permissions.includes(command.permission)));
}
function atlasCommandAllowed(commands, id, permissions, disabled = false) {
    return (!disabled &&
        atlasVisibleCommands(commands, permissions).some((command) => command.id === id && !command.disabled));
}
/** Reserve room for overflow only when all commands cannot fit. */
function atlasToolbarCapacity(widths, available, more = 84, gap = 8) {
    const total = widths.reduce((sum, width) => sum + width, 0) +
        Math.max(0, widths.length - 1) * gap;
    if (total <= available)
        return widths.length;
    let used = more;
    let count = 0;
    for (const width of widths) {
        if (used + width + gap > available)
            break;
        used += width + gap;
        count++;
    }
    return count;
}

class AtlasPopupMenu {
    commands = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "commands" }] : /* istanbul ignore next */ []));
    permissions = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "permissions" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    label = input("Actions", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    command = output();
    opened = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    visible = computed(() => atlasVisibleCommands(this.commands(), this.permissions()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    panel = viewChild.required("panel", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []));
    origin;
    openAt(origin, point, last = false) {
        if (this.disabled() || !this.visible().length)
            return;
        this.origin = origin;
        const panel = this.panel().nativeElement;
        panel.showPopover();
        this.opened.set(true);
        const rect = origin.getBoundingClientRect();
        const menu = panel.getBoundingClientRect();
        const x = point?.x ?? rect.left;
        const y = point?.y ?? rect.bottom + 4;
        panel.style.left = `${Math.max(8, Math.min(x, innerWidth - menu.width - 8))}px`;
        panel.style.top = `${Math.max(8, Math.min(y, innerHeight - menu.height - 8))}px`;
        const items = panel.querySelectorAll('[role="menuitem"]');
        (items[last ? items.length - 1 : 0] ?? panel).focus();
    }
    close(restore = true) {
        this.panel().nativeElement.hidePopover();
        this.opened.set(false);
        if (restore && this.origin?.isConnected)
            this.origin.focus();
    }
    viewportChanged() {
        if (this.opened())
            this.close();
    }
    toggled(event) {
        this.opened.set(event.newState === "open");
    }
    execute(id) {
        if (!atlasCommandAllowed(this.commands(), id, this.permissions(), this.disabled()))
            return;
        this.close();
        this.command.emit(id);
    }
    key(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            this.close();
            return;
        }
        if (event.key === "Tab") {
            this.close();
            return;
        }
        const items = [
            ...this.panel().nativeElement.querySelectorAll('[role="menuitem"]'),
        ];
        const index = items.indexOf(document.activeElement);
        let next;
        switch (event.key) {
            case "ArrowDown":
                next = (index + 1) % items.length;
                break;
            case "ArrowUp":
                next = (index - 1 + items.length) % items.length;
                break;
            case "Home":
                next = 0;
                break;
            case "End":
                next = items.length - 1;
                break;
            default:
                if (event.key.length !== 1 ||
                    event.ctrlKey ||
                    event.metaKey ||
                    event.altKey ||
                    event.key === " ")
                    return;
                next = items.findIndex((_, offset) => items[(index + offset + 1) % items.length]?.textContent
                    ?.trim()
                    .toLocaleLowerCase()
                    .startsWith(event.key.toLocaleLowerCase()));
                if (next < 0)
                    return;
                next = (index + next + 1) % items.length;
        }
        event.preventDefault();
        items[next]?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPopupMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasPopupMenu, isStandalone: true, selector: "atlas-popup-menu", inputs: { commands: { classPropertyName: "commands", publicName: "commands", isSignal: true, isRequired: false, transformFunction: null }, permissions: { classPropertyName: "permissions", publicName: "permissions", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { command: "command" }, host: { listeners: { "window:resize": "viewportChanged()" } }, viewQueries: [{ propertyName: "panel", first: true, predicate: ["panel"], descendants: true, isSignal: true }], ngImport: i0, template: `<div
    #panel
    popover="auto"
    class="atlas-popup-menu"
    role="menu"
    tabindex="-1"
    [attr.aria-label]="label()"
    (toggle)="toggled($event)"
    (keydown)="key($event)"
  >
    @for (item of visible(); track item.id) {
      @if ($index > 0 && item.group !== visible()[$index - 1].group) {
        <div role="separator" class="atlas-menu-separator"></div>
      }
      <button
        type="button"
        role="menuitem"
        tabindex="-1"
        [attr.aria-disabled]="disabled() || item.disabled || false"
        (click)="execute(item.id)"
      >
        @if (item.icon) {
          <atlas-icon [name]="item.icon" />
        }
        <span>{{ item.label }}</span>
      </button>
    } @empty {
      <p role="status">No available actions.</p>
    }
  </div>`, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPopupMenu, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-popup-menu",
                    host: { "(window:resize)": "viewportChanged()" },
                    imports: [AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<div
    #panel
    popover="auto"
    class="atlas-popup-menu"
    role="menu"
    tabindex="-1"
    [attr.aria-label]="label()"
    (toggle)="toggled($event)"
    (keydown)="key($event)"
  >
    @for (item of visible(); track item.id) {
      @if ($index > 0 && item.group !== visible()[$index - 1].group) {
        <div role="separator" class="atlas-menu-separator"></div>
      }
      <button
        type="button"
        role="menuitem"
        tabindex="-1"
        [attr.aria-disabled]="disabled() || item.disabled || false"
        (click)="execute(item.id)"
      >
        @if (item.icon) {
          <atlas-icon [name]="item.icon" />
        }
        <span>{{ item.label }}</span>
      </button>
    } @empty {
      <p role="status">No available actions.</p>
    }
  </div>`,
                }]
        }], propDecorators: { commands: [{ type: i0.Input, args: [{ isSignal: true, alias: "commands", required: false }] }], permissions: [{ type: i0.Input, args: [{ isSignal: true, alias: "permissions", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], command: [{ type: i0.Output, args: ["command"] }], panel: [{ type: i0.ViewChild, args: ["panel", { isSignal: true }] }] } });
class AtlasContextMenu {
    atlasContextMenu = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "atlasContextMenu" }] : /* istanbul ignore next */ []));
    host = inject(ElementRef);
    open(event) {
        if (event.target.closest('input,textarea,[contenteditable="true"]'))
            return;
        if (this.atlasContextMenu().disabled() ||
            !this.atlasContextMenu().visible().length)
            return;
        event.preventDefault();
        event.stopPropagation();
        this.atlasContextMenu().openAt(this.host.nativeElement, {
            x: event.clientX,
            y: event.clientY,
        });
    }
    keyboard(event) {
        if (event.key !== "ContextMenu" && !(event.shiftKey && event.key === "F10"))
            return;
        event.preventDefault();
        event.stopPropagation();
        this.atlasContextMenu().openAt(this.host.nativeElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasContextMenu, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasContextMenu, isStandalone: true, selector: "[atlasContextMenu]", inputs: { atlasContextMenu: { classPropertyName: "atlasContextMenu", publicName: "atlasContextMenu", isSignal: true, isRequired: true, transformFunction: null } }, host: { listeners: { "contextmenu": "open($event)", "keydown": "keyboard($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasContextMenu, decorators: [{
            type: Directive,
            args: [{
                    selector: "[atlasContextMenu]",
                    host: { "(contextmenu)": "open($event)", "(keydown)": "keyboard($event)" },
                }]
        }], propDecorators: { atlasContextMenu: [{ type: i0.Input, args: [{ isSignal: true, alias: "atlasContextMenu", required: true }] }] } });
class AtlasMenuButton {
    commands = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "commands" }] : /* istanbul ignore next */ []));
    permissions = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "permissions" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    label = input("Actions", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    command = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMenuButton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasMenuButton, isStandalone: true, selector: "atlas-menu-button", inputs: { commands: { classPropertyName: "commands", publicName: "commands", isSignal: true, isRequired: false, transformFunction: null }, permissions: { classPropertyName: "permissions", publicName: "permissions", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { command: "command" }, ngImport: i0, template: `<button
      #trigger
      atlasButton
      type="button"
      aria-haspopup="menu"
      [attr.aria-expanded]="menu.opened()"
      [disabled]="disabled() || !menu.visible().length"
      (click)="menu.opened() ? menu.close() : menu.openAt(trigger)"
      (keydown.arrowdown)="$event.preventDefault(); menu.openAt(trigger)"
      (keydown.arrowup)="
        $event.preventDefault(); menu.openAt(trigger, undefined, true)
      "
    >
      {{ label() }} ▾
    </button>
    <atlas-popup-menu
      #menu
      [commands]="commands()"
      [permissions]="permissions()"
      [disabled]="disabled()"
      [label]="label()"
      (command)="command.emit($event)"
    />`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "component", type: AtlasPopupMenu, selector: "atlas-popup-menu", inputs: ["commands", "permissions", "disabled", "label"], outputs: ["command"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMenuButton, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-menu-button",
                    imports: [AtlasButton, AtlasPopupMenu],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<button
      #trigger
      atlasButton
      type="button"
      aria-haspopup="menu"
      [attr.aria-expanded]="menu.opened()"
      [disabled]="disabled() || !menu.visible().length"
      (click)="menu.opened() ? menu.close() : menu.openAt(trigger)"
      (keydown.arrowdown)="$event.preventDefault(); menu.openAt(trigger)"
      (keydown.arrowup)="
        $event.preventDefault(); menu.openAt(trigger, undefined, true)
      "
    >
      {{ label() }} ▾
    </button>
    <atlas-popup-menu
      #menu
      [commands]="commands()"
      [permissions]="permissions()"
      [disabled]="disabled()"
      [label]="label()"
      (command)="command.emit($event)"
    />`,
                }]
        }], propDecorators: { commands: [{ type: i0.Input, args: [{ isSignal: true, alias: "commands", required: false }] }], permissions: [{ type: i0.Input, args: [{ isSignal: true, alias: "permissions", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], command: [{ type: i0.Output, args: ["command"] }] } });
class AtlasSplitButton {
    commands = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "commands" }] : /* istanbul ignore next */ []));
    primaryId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "primaryId" }] : /* istanbul ignore next */ []));
    permissions = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "permissions" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    label = input("Save options", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    command = output();
    primary = computed(() => atlasVisibleCommands(this.commands(), this.permissions()).find((command) => command.id === this.primaryId()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "primary" }] : /* istanbul ignore next */ []));
    alternatives = computed(() => atlasVisibleCommands(this.commands(), this.permissions()).filter((command) => command.id !== this.primaryId()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "alternatives" }] : /* istanbul ignore next */ []));
    execute(id) {
        if (atlasCommandAllowed(this.commands(), id, this.permissions(), this.disabled()))
            this.command.emit(id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSplitButton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasSplitButton, isStandalone: true, selector: "atlas-split-button", inputs: { commands: { classPropertyName: "commands", publicName: "commands", isSignal: true, isRequired: false, transformFunction: null }, primaryId: { classPropertyName: "primaryId", publicName: "primaryId", isSignal: true, isRequired: true, transformFunction: null }, permissions: { classPropertyName: "permissions", publicName: "permissions", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { command: "command" }, ngImport: i0, template: `<div
    class="atlas-split-button"
    role="group"
    [attr.aria-label]="label()"
  >
    @if (primary(); as action) {
      <button
        #main
        atlasButton
        type="button"
        [variant]="action.primary ? 'primary' : 'secondary'"
        [disabled]="disabled() || action.disabled"
        (click)="execute(action.id)"
        (keydown.arrowdown)="$event.preventDefault(); menu.openAt(main)"
      >
        {{ action.label }}
      </button>
    }
    <button
      #trigger
      atlasButton
      type="button"
      aria-haspopup="menu"
      [attr.aria-label]="label() + ' alternatives'"
      [attr.aria-expanded]="menu.opened()"
      [disabled]="disabled() || !alternatives().length"
      (click)="menu.opened() ? menu.close() : menu.openAt(trigger)"
      (keydown.arrowdown)="$event.preventDefault(); menu.openAt(trigger)"
    >
      ▾
    </button>
    <atlas-popup-menu
      #menu
      [commands]="alternatives()"
      [permissions]="permissions()"
      [disabled]="disabled()"
      [label]="label()"
      (command)="execute($event)"
    />
  </div>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "component", type: AtlasPopupMenu, selector: "atlas-popup-menu", inputs: ["commands", "permissions", "disabled", "label"], outputs: ["command"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSplitButton, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-split-button",
                    imports: [AtlasButton, AtlasPopupMenu],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<div
    class="atlas-split-button"
    role="group"
    [attr.aria-label]="label()"
  >
    @if (primary(); as action) {
      <button
        #main
        atlasButton
        type="button"
        [variant]="action.primary ? 'primary' : 'secondary'"
        [disabled]="disabled() || action.disabled"
        (click)="execute(action.id)"
        (keydown.arrowdown)="$event.preventDefault(); menu.openAt(main)"
      >
        {{ action.label }}
      </button>
    }
    <button
      #trigger
      atlasButton
      type="button"
      aria-haspopup="menu"
      [attr.aria-label]="label() + ' alternatives'"
      [attr.aria-expanded]="menu.opened()"
      [disabled]="disabled() || !alternatives().length"
      (click)="menu.opened() ? menu.close() : menu.openAt(trigger)"
      (keydown.arrowdown)="$event.preventDefault(); menu.openAt(trigger)"
    >
      ▾
    </button>
    <atlas-popup-menu
      #menu
      [commands]="alternatives()"
      [permissions]="permissions()"
      [disabled]="disabled()"
      [label]="label()"
      (command)="execute($event)"
    />
  </div>`,
                }]
        }], propDecorators: { commands: [{ type: i0.Input, args: [{ isSignal: true, alias: "commands", required: false }] }], primaryId: [{ type: i0.Input, args: [{ isSignal: true, alias: "primaryId", required: true }] }], permissions: [{ type: i0.Input, args: [{ isSignal: true, alias: "permissions", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], command: [{ type: i0.Output, args: ["command"] }] } });

class AtlasCommandToolbar {
    commands = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "commands" }] : /* istanbul ignore next */ []));
    permissions = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "permissions" }] : /* istanbul ignore next */ []));
    label = input("Record actions", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    command = output();
    focused = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []));
    capacity = signal(Infinity, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "capacity" }] : /* istanbul ignore next */ []));
    allowed = computed(() => atlasVisibleCommands(this.commands(), this.permissions()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "allowed" }] : /* istanbul ignore next */ []));
    visible = computed(() => this.allowed().slice(0, this.capacity()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    overflow = computed(() => this.allowed().slice(this.capacity()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overflow" }] : /* istanbul ignore next */ []));
    tabstop = computed(() => {
        const ids = this.visible()
            .filter((item) => !item.disabled)
            .map((item) => item.id);
        if (this.overflow().length)
            ids.push("__more");
        return ids.includes(this.focused()) ? this.focused() : ids[0];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabstop" }] : /* istanbul ignore next */ []));
    bar = viewChild.required("bar", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "bar" }] : /* istanbul ignore next */ []));
    measure = viewChild.required("measure", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "measure" }] : /* istanbul ignore next */ []));
    status = viewChild.required("status", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    constructor() {
        const destroy = inject(DestroyRef);
        afterNextRender(() => {
            const observer = new ResizeObserver(() => this.resize());
            observer.observe(this.bar().nativeElement);
            observer.observe(this.measure().nativeElement);
            observer.observe(this.status().nativeElement);
            destroy.onDestroy(() => observer.disconnect());
            this.resize();
        });
        effect((onCleanup) => {
            this.allowed();
            const frame = requestAnimationFrame(() => this.resize());
            onCleanup(() => cancelAnimationFrame(frame));
        });
    }
    resize() {
        const buttons = [
            ...this.measure().nativeElement.querySelectorAll("button"),
        ];
        const more = buttons.pop()?.getBoundingClientRect().width ?? 84;
        const widths = buttons.map((button) => button.getBoundingClientRect().width +
            parseFloat(getComputedStyle(button).marginLeft) +
            parseFloat(getComputedStyle(button).marginRight));
        const status = this.status().nativeElement;
        const style = getComputedStyle(this.bar().nativeElement);
        const padding = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight) + 8;
        const available = this.bar().nativeElement.clientWidth -
            padding -
            (status.textContent?.trim()
                ? status.getBoundingClientRect().width + 8
                : 0);
        const capacity = atlasToolbarCapacity(widths, available, more);
        const active = document.activeElement;
        const moveFocus = this.bar().nativeElement.contains(active) && capacity !== this.capacity();
        this.capacity.set(capacity);
        if (moveFocus) {
            const bar = this.bar().nativeElement;
            requestAnimationFrame(() => {
                if (bar.isConnected &&
                    (document.activeElement === active ||
                        document.activeElement === document.body))
                    bar.querySelector('button[tabindex="0"]')?.focus();
            });
        }
    }
    execute(item) {
        this.executeId(item.id);
    }
    executeId(id) {
        if (atlasCommandAllowed(this.commands(), id, this.permissions(), this.disabled()))
            this.command.emit(id);
    }
    key(event) {
        if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key))
            return;
        event.preventDefault();
        const buttons = [
            ...this.bar().nativeElement.querySelectorAll(":scope > button:not(:disabled)"),
        ];
        const at = buttons.indexOf(event.currentTarget);
        const next = event.key === "Home"
            ? 0
            : event.key === "End"
                ? buttons.length - 1
                : (at + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) %
                    buttons.length;
        buttons[next]?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCommandToolbar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasCommandToolbar, isStandalone: true, selector: "atlas-command-toolbar", inputs: { commands: { classPropertyName: "commands", publicName: "commands", isSignal: true, isRequired: false, transformFunction: null }, permissions: { classPropertyName: "permissions", publicName: "permissions", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { command: "command" }, viewQueries: [{ propertyName: "bar", first: true, predicate: ["bar"], descendants: true, isSignal: true }, { propertyName: "measure", first: true, predicate: ["measure"], descendants: true, isSignal: true }, { propertyName: "status", first: true, predicate: ["status"], descendants: true, isSignal: true }], ngImport: i0, template: `<div
      #bar
      class="atlas-command-toolbar"
      role="toolbar"
      [attr.aria-label]="label()"
    >
      @for (item of visible(); track item.id) {
        <button
          atlasButton
          type="button"
          [variant]="item.primary ? 'primary' : 'secondary'"
          [disabled]="disabled() || item.disabled"
          [class.atlas-command-group-start]="
            $index > 0 && item.group !== visible()[$index - 1].group
          "
          [attr.tabindex]="tabstop() === item.id ? 0 : -1"
          (focus)="focused.set(item.id)"
          (keydown)="key($event)"
          (click)="execute(item)"
        >
          @if (item.icon) {
            <atlas-icon [name]="item.icon" />
          }
          {{ item.label }}
        </button>
      }
      @if (overflow().length) {
        <button
          #more
          atlasButton
          type="button"
          aria-haspopup="menu"
          [attr.aria-expanded]="menu.opened()"
          [disabled]="disabled()"
          [attr.tabindex]="tabstop() === '__more' ? 0 : -1"
          (focus)="focused.set('__more')"
          (keydown)="key($event)"
          (keydown.arrowdown)="$event.preventDefault(); menu.openAt(more)"
          (click)="menu.openAt(more)"
        >
          More ▾
        </button>
      }
      <span #status class="atlas-command-status" role="status"
        ><ng-content
      /></span>
      <atlas-popup-menu
        #menu
        [commands]="overflow()"
        [permissions]="permissions()"
        [disabled]="disabled()"
        [label]="label() + ' overflow'"
        (command)="executeId($event)"
      />
    </div>
    <div #measure class="atlas-toolbar-measure" aria-hidden="true" inert>
      @for (item of allowed(); track item.id) {
        <button
          atlasButton
          tabindex="-1"
          [class.atlas-command-group-start]="
            $index > 0 && item.group !== allowed()[$index - 1].group
          "
          [variant]="item.primary ? 'primary' : 'secondary'"
        >
          @if (item.icon) {
            <atlas-icon [name]="item.icon" />
          }
          {{ item.label }}
        </button>
      }
      <button atlasButton tabindex="-1">More ▾</button>
    </div>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }, { kind: "component", type: AtlasPopupMenu, selector: "atlas-popup-menu", inputs: ["commands", "permissions", "disabled", "label"], outputs: ["command"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCommandToolbar, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-command-toolbar",
                    imports: [AtlasButton, AtlasIcon, AtlasPopupMenu],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<div
      #bar
      class="atlas-command-toolbar"
      role="toolbar"
      [attr.aria-label]="label()"
    >
      @for (item of visible(); track item.id) {
        <button
          atlasButton
          type="button"
          [variant]="item.primary ? 'primary' : 'secondary'"
          [disabled]="disabled() || item.disabled"
          [class.atlas-command-group-start]="
            $index > 0 && item.group !== visible()[$index - 1].group
          "
          [attr.tabindex]="tabstop() === item.id ? 0 : -1"
          (focus)="focused.set(item.id)"
          (keydown)="key($event)"
          (click)="execute(item)"
        >
          @if (item.icon) {
            <atlas-icon [name]="item.icon" />
          }
          {{ item.label }}
        </button>
      }
      @if (overflow().length) {
        <button
          #more
          atlasButton
          type="button"
          aria-haspopup="menu"
          [attr.aria-expanded]="menu.opened()"
          [disabled]="disabled()"
          [attr.tabindex]="tabstop() === '__more' ? 0 : -1"
          (focus)="focused.set('__more')"
          (keydown)="key($event)"
          (keydown.arrowdown)="$event.preventDefault(); menu.openAt(more)"
          (click)="menu.openAt(more)"
        >
          More ▾
        </button>
      }
      <span #status class="atlas-command-status" role="status"
        ><ng-content
      /></span>
      <atlas-popup-menu
        #menu
        [commands]="overflow()"
        [permissions]="permissions()"
        [disabled]="disabled()"
        [label]="label() + ' overflow'"
        (command)="executeId($event)"
      />
    </div>
    <div #measure class="atlas-toolbar-measure" aria-hidden="true" inert>
      @for (item of allowed(); track item.id) {
        <button
          atlasButton
          tabindex="-1"
          [class.atlas-command-group-start]="
            $index > 0 && item.group !== allowed()[$index - 1].group
          "
          [variant]="item.primary ? 'primary' : 'secondary'"
        >
          @if (item.icon) {
            <atlas-icon [name]="item.icon" />
          }
          {{ item.label }}
        </button>
      }
      <button atlasButton tabindex="-1">More ▾</button>
    </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { commands: [{ type: i0.Input, args: [{ isSignal: true, alias: "commands", required: false }] }], permissions: [{ type: i0.Input, args: [{ isSignal: true, alias: "permissions", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], command: [{ type: i0.Output, args: ["command"] }], bar: [{ type: i0.ViewChild, args: ["bar", { isSignal: true }] }], measure: [{ type: i0.ViewChild, args: ["measure", { isSignal: true }] }], status: [{ type: i0.ViewChild, args: ["status", { isSignal: true }] }] } });
class AtlasMasterDetail {
    detailOpen = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "detailOpen" }] : /* istanbul ignore next */ []));
    masterLabel = input("Records", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "masterLabel" }] : /* istanbul ignore next */ []));
    detailLabel = input("Record details", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "detailLabel" }] : /* istanbul ignore next */ []));
    breakpoint = input(680, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    width = signal(1000, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    narrow = computed(() => this.width() < this.breakpoint(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "narrow" }] : /* istanbul ignore next */ []));
    host = inject(ElementRef);
    origin;
    rememberOrigin(event) {
        const target = event.target;
        if (target instanceof HTMLElement &&
            this.host.nativeElement
                .querySelector(".atlas-master-pane")
                ?.contains(target))
            this.origin = target;
    }
    constructor() {
        const destroy = inject(DestroyRef);
        afterNextRender(() => {
            const observer = new ResizeObserver((entries) => this.width.set(entries[0].contentRect.width));
            observer.observe(this.host.nativeElement);
            destroy.onDestroy(() => observer.disconnect());
        });
        effect(() => {
            const narrow = this.narrow();
            if (this.detailOpen()) {
                if (narrow)
                    requestAnimationFrame(() => this.host.nativeElement
                        .querySelector(".atlas-detail-pane")
                        ?.focus());
                const active = this.host.nativeElement.ownerDocument.activeElement;
                if (active instanceof HTMLElement &&
                    this.host.nativeElement
                        .querySelector(".atlas-master-pane")
                        ?.contains(active))
                    this.origin = active;
            }
        });
    }
    back() {
        this.detailOpen.set(false);
        requestAnimationFrame(() => {
            if (this.origin?.isConnected)
                this.origin.focus();
            else
                this.host.nativeElement
                    .querySelector(".atlas-master-pane button")
                    ?.focus();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMasterDetail, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasMasterDetail, isStandalone: true, selector: "atlas-master-detail", inputs: { detailOpen: { classPropertyName: "detailOpen", publicName: "detailOpen", isSignal: true, isRequired: false, transformFunction: null }, masterLabel: { classPropertyName: "masterLabel", publicName: "masterLabel", isSignal: true, isRequired: false, transformFunction: null }, detailLabel: { classPropertyName: "detailLabel", publicName: "detailLabel", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { detailOpen: "detailOpenChange" }, host: { listeners: { "focusin": "rememberOrigin($event)" }, properties: { "class.is-narrow": "narrow()" }, classAttribute: "atlas-master-detail" }, ngImport: i0, template: `<section
      class="atlas-master-pane"
      [hidden]="narrow() && detailOpen()"
      [attr.aria-label]="masterLabel()"
    >
      <ng-content select="[atlasMaster]" />
    </section>
    <section
      class="atlas-detail-pane"
      tabindex="-1"
      [hidden]="narrow() && !detailOpen()"
      [attr.aria-label]="detailLabel()"
    >
      @if (narrow()) {
        <button atlasButton type="button" (click)="back()">
          ← {{ masterLabel() }}
        </button>
      }
      <ng-content select="[atlasDetail]" />
    </section>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMasterDetail, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-master-detail",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        class: "atlas-master-detail",
                        "[class.is-narrow]": "narrow()",
                        "(focusin)": "rememberOrigin($event)",
                    },
                    template: `<section
      class="atlas-master-pane"
      [hidden]="narrow() && detailOpen()"
      [attr.aria-label]="masterLabel()"
    >
      <ng-content select="[atlasMaster]" />
    </section>
    <section
      class="atlas-detail-pane"
      tabindex="-1"
      [hidden]="narrow() && !detailOpen()"
      [attr.aria-label]="detailLabel()"
    >
      @if (narrow()) {
        <button atlasButton type="button" (click)="back()">
          ← {{ masterLabel() }}
        </button>
      }
      <ng-content select="[atlasDetail]" />
    </section>`,
                }]
        }], ctorParameters: () => [], propDecorators: { detailOpen: [{ type: i0.Input, args: [{ isSignal: true, alias: "detailOpen", required: false }] }, { type: i0.Output, args: ["detailOpenChange"] }], masterLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "masterLabel", required: false }] }], detailLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "detailLabel", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }] } });
let dialogSequence = 0;
class AtlasDialog {
    open = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    busy = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []));
    dismissed = output();
    dialog = viewChild("dialog", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dialog" }] : /* istanbul ignore next */ []));
    titleId = `atlas-dialog-${++dialogSequence}`;
    host = inject(ElementRef);
    position() {
        const dialog = this.dialog()?.nativeElement;
        if (!dialog?.open)
            return;
        const scope = this.host.nativeElement.closest(".atlas-window");
        if (!scope)
            return;
        const bounds = scope.getBoundingClientRect();
        const viewportWidth = document.documentElement.clientWidth;
        const viewportHeight = document.documentElement.clientHeight;
        const width = Math.max(160, Math.min(520, bounds.width - 24, viewportWidth - 24));
        dialog.style.width = `${width}px`;
        dialog.style.maxHeight = `${Math.max(100, Math.min(bounds.height, viewportHeight) - 24)}px`;
        dialog.style.margin = "0";
        dialog.style.left = `${Math.max(12, Math.min(bounds.left + (bounds.width - width) / 2, viewportWidth - width - 12))}px`;
        const height = dialog.getBoundingClientRect().height;
        dialog.style.top = `${Math.max(12, Math.min(bounds.top + (bounds.height - height) / 2, viewportHeight - height - 12))}px`;
    }
    constructor() {
        effect(() => {
            const dialog = this.dialog()?.nativeElement;
            if (!dialog)
                return;
            if (this.open() && !dialog.open) {
                dialog.showModal();
                this.position();
            }
            else if (!this.open() && dialog.open)
                dialog.close();
        });
    }
    dismiss() {
        if (this.busy())
            return;
        this.open.set(false);
        this.dismissed.emit();
    }
    cancel(event) {
        event.preventDefault();
        this.dismiss();
    }
    closed() {
        this.open.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.7", type: AtlasDialog, isStandalone: true, selector: "atlas-dialog", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, busy: { classPropertyName: "busy", publicName: "busy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange", dismissed: "dismissed" }, host: { listeners: { "window:resize": "position()" } }, viewQueries: [{ propertyName: "dialog", first: true, predicate: ["dialog"], descendants: true, isSignal: true }], ngImport: i0, template: `<dialog
    #dialog
    class="atlas-dialog"
    [attr.aria-labelledby]="titleId"
    (cancel)="cancel($event)"
    (close)="closed()"
  >
    <header>
      <h2 [id]="titleId">{{ title() }}</h2>
      <button
        atlasButton
        type="button"
        aria-label="Close dialog"
        [disabled]="busy()"
        (click)="dismiss()"
      >
        ×
      </button>
    </header>
    <div class="atlas-dialog-body"><ng-content /></div>
    <footer><ng-content select="[atlasDialogActions]" /></footer>
  </dialog>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDialog, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-dialog",
                    host: { "(window:resize)": "position()" },
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<dialog
    #dialog
    class="atlas-dialog"
    [attr.aria-labelledby]="titleId"
    (cancel)="cancel($event)"
    (close)="closed()"
  >
    <header>
      <h2 [id]="titleId">{{ title() }}</h2>
      <button
        atlasButton
        type="button"
        aria-label="Close dialog"
        [disabled]="busy()"
        (click)="dismiss()"
      >
        ×
      </button>
    </header>
    <div class="atlas-dialog-body"><ng-content /></div>
    <footer><ng-content select="[atlasDialogActions]" /></footer>
  </dialog>`,
                }]
        }], ctorParameters: () => [], propDecorators: { open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }, { type: i0.Output, args: ["openChange"] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], busy: [{ type: i0.Input, args: [{ isSignal: true, alias: "busy", required: false }] }], dismissed: [{ type: i0.Output, args: ["dismissed"] }], dialog: [{ type: i0.ViewChild, args: ["dialog", { isSignal: true }] }] } });

class AtlasWorkspace {
    ws = inject(WorkspaceService);
    positions = ["top", "left", "right", "bottom"];
    settingsOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "settingsOpen" }] : /* istanbul ignore next */ []));
    pendingDock = signal("bottom", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pendingDock" }] : /* istanbul ignore next */ []));
    taskbarMenu = viewChild.required("taskbarMenu", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "taskbarMenu" }] : /* istanbul ignore next */ []));
    settingsButton = viewChild.required("settingsButton", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "settingsButton" }] : /* istanbul ignore next */ []));
    openSettings() {
        this.taskbarMenu().nativeElement.hidePopover();
        this.settingsButton().nativeElement.focus({ preventScroll: true });
        this.pendingDock.set(this.dock());
        this.settingsOpen.set(true);
    }
    applySettings() {
        this.setDock(this.pendingDock());
        this.settingsOpen.set(false);
    }
    chooseDock(position) {
        this.taskbarMenu().nativeElement.hidePopover();
        this.setDock(position);
        this.settingsButton().nativeElement.focus({ preventScroll: true });
    }
    dismissTaskbarMenu(event) {
        const menu = this.taskbarMenu()?.nativeElement;
        if (menu?.matches(':popover-open') && !menu.contains(event.target))
            menu.hidePopover();
    }
    openTaskbarMenu(event) {
        event.preventDefault();
        this.showTaskbarMenu(event.clientX, event.clientY);
    }
    showTaskbarMenu(x, y) {
        const menu = this.taskbarMenu().nativeElement;
        // A contextmenu event can precede pointerup. Native auto-popover light
        // dismissal can treat that same opening gesture as an outside click.
        // Manual mode dismisses on the next outside pointerdown instead.
        menu.showPopover();
        const win = menu.ownerDocument.defaultView;
        const box = menu.getBoundingClientRect();
        menu.style.left = `${Math.max(8, Math.min(x, win.innerWidth - box.width - 8))}px`;
        menu.style.top = `${Math.max(8, Math.min(y, win.innerHeight - box.height - 8))}px`;
        menu
            .querySelector("button")
            ?.focus({ preventScroll: true });
    }
    taskbarKey(event) {
        if (event.key === "ContextMenu" ||
            (event.shiftKey && event.key === "F10")) {
            event.preventDefault();
            const box = event.target.getBoundingClientRect();
            this.showTaskbarMenu(box.left, box.bottom);
        }
    }
    menuKey(event) {
        const menu = this.taskbarMenu().nativeElement;
        if (event.key === "Escape" || event.key === "Tab") {
            menu.hidePopover();
            this.settingsButton().nativeElement.focus({ preventScroll: true });
            if (event.key === "Escape") {
                event.preventDefault();
                event.stopPropagation();
            }
            return;
        }
        const buttons = Array.from(menu.querySelectorAll("button"));
        const index = buttons.indexOf(menu.ownerDocument.activeElement);
        if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
            event.preventDefault();
            buttons[event.key === "Home"
                ? 0
                : event.key === "End"
                    ? buttons.length - 1
                    : (index + (event.key === "ArrowDown" ? 1 : -1) + buttons.length) %
                        buttons.length]?.focus();
        }
    }
    forceMobile = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "forceMobile" }] : /* istanbul ignore next */ []));
    dock = signal("bottom", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dock" }] : /* istanbul ignore next */ []));
    setDock(value) {
        if (value !== "top" &&
            value !== "bottom" &&
            value !== "left" &&
            value !== "right")
            return;
        this.dock.set(value);
        try {
            this.element.nativeElement.ownerDocument.defaultView?.localStorage.setItem("atlas.taskbar.dock", value);
        }
        catch {
            /* Storage may be unavailable; keep the in-memory preference. */
        }
    }
    canvas = viewChild.required("canvas", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canvas" }] : /* istanbul ignore next */ []));
    confirm = viewChild("confirm", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "confirm" }] : /* istanbul ignore next */ []));
    observer;
    element = inject(ElementRef);
    focusTargets = new Map();
    destroyed = false;
    guardPageExit(event) {
        if (!this.ws.hasPendingWork())
            return;
        event.preventDefault();
        // Browsers provide their own confirmation text and may require prior user interaction.
        event.returnValue = '';
    }
    constructor() {
        effect(() => {
            const tasks = this.ws.tasks();
            for (const id of this.focusTargets.keys()) {
                if (!tasks.some((task) => task.id === id))
                    this.focusTargets.delete(id);
            }
        });
        effect(() => {
            const activeId = this.ws.activeId();
            queueMicrotask(() => {
                if (this.destroyed || !activeId || this.ws.pendingClose())
                    return;
                const host = this.element.nativeElement;
                const frame = host.querySelector(`[data-task-id="${activeId}"]`);
                if (!frame || frame.contains(host.ownerDocument.activeElement))
                    return;
                const previous = this.focusTargets.get(activeId);
                (previous?.isConnected && !previous.hasAttribute("disabled")
                    ? previous
                    : frame).focus({ preventScroll: true });
            });
        });
        effect(() => {
            const dialog = this.confirm()?.nativeElement;
            const pending = this.ws.pendingClose();
            if (!dialog)
                return;
            if (pending && !dialog.open)
                dialog.showModal();
            else if (!pending && dialog.open)
                dialog.close();
        });
        effect(() => {
            this.forceMobile();
            if (this.observer)
                this.measure();
        });
    }
    ngAfterViewInit() {
        try {
            const stored = this.element.nativeElement.ownerDocument.defaultView?.localStorage.getItem("atlas.taskbar.dock");
            if (stored === "top" ||
                stored === "bottom" ||
                stored === "left" ||
                stored === "right")
                this.dock.set(stored);
        }
        catch {
            /* Use default docking when storage is unavailable. */
        }
        this.observer = new ResizeObserver(() => this.measure());
        this.observer.observe(this.canvas().nativeElement);
        this.measure();
    }
    ngOnDestroy() {
        this.destroyed = true;
        this.observer?.disconnect();
        this.focusTargets.clear();
    }
    rememberFocus(event) {
        const target = event.target;
        const id = target.closest("[data-task-id]")?.dataset["taskId"];
        if (id)
            this.focusTargets.set(id, target);
    }
    measure() {
        const rect = this.canvas().nativeElement.getBoundingClientRect();
        this.ws.setViewport(rect.width, rect.height, this.forceMobile() ||
            this.element.nativeElement.getBoundingClientRect().width < 700);
    }
    home() {
        for (const task of this.ws.tasks())
            this.ws.minimize(task.id);
        this.ws.showDesktop();
    }
    cancel(event) {
        event.preventDefault();
        this.ws.cancelClose();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasWorkspace, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasWorkspace, isStandalone: true, selector: "atlas-workspace", inputs: { forceMobile: { classPropertyName: "forceMobile", publicName: "forceMobile", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "focusin": "rememberFocus($event)", "window:beforeunload": "guardPageExit($event)", "document:pointerdown": "dismissTaskbarMenu($event)" }, properties: { "attr.data-taskbar-dock": "dock()", "class.mobile-workspace": "ws.mobile()" }, classAttribute: "atlas-workspace" }, viewQueries: [{ propertyName: "taskbarMenu", first: true, predicate: ["taskbarMenu"], descendants: true, isSignal: true }, { propertyName: "settingsButton", first: true, predicate: ["settingsButton"], descendants: true, isSignal: true }, { propertyName: "canvas", first: true, predicate: ["canvas"], descendants: true, isSignal: true }, { propertyName: "confirm", first: true, predicate: ["confirm"], descendants: true, isSignal: true }], ngImport: i0, template: `<div class="atlas-workspace-canvas" #canvas>
      <div
        class="atlas-workspace-background"
        [inert]="ws.mobile() && !!ws.activeId()"
      >
        <ng-content />
      </div>
      @for (task of ws.tasks(); track task.id; let i = $index) {
        <atlas-window
          [task]="task"
          [layer]="ws.stackOrder().indexOf(task.id) + 1"
        />
      }
    </div>
    <div
      class="atlas-task-strip"
      aria-label="Open tasks"
      (contextmenu)="openTaskbarMenu($event)"
      (keydown)="taskbarKey($event)"
    >
      <ng-content select="[atlasWorkspaceLauncher]" />
      <button
        #settingsButton
        class="atlas-desktop-button atlas-taskbar-settings-button"
        type="button"
        aria-label="Taskbar settings"
        title="Taskbar settings"
        (click)="openSettings()"
      >
        <atlas-icon name="settings" />
      </button>
      <div class="atlas-task-scroll">
        <button
          class="atlas-desktop-button"
          aria-label="Show workspace home"
          (click)="home()"
        >
          <atlas-icon name="grid" />
        </button>
        <span class="atlas-task-divider"></span>
        @for (task of ws.tasks(); track task.id) {
          <button
            class="atlas-task-button"
            [class.active]="ws.activeId() === task.id"
            [class.minimized]="task.minimized"
            [attr.aria-pressed]="ws.activeId() === task.id"
            (click)="ws.activate(task.id)"
          >
            <atlas-icon [name]="task.icon" /><span>{{ task.title }}</span>
            @if (task.dirty()) {
              <span class="atlas-dirty-dot"></span>
            }
          </button>
        }
        @if (!ws.tasks().length) {
          <span class="atlas-no-tasks">Your open tasks will appear here</span>
        }
        <span class="atlas-task-count">{{ ws.tasks().length }} open</span>
      </div>
    </div>
    <div
      #taskbarMenu
      popover="manual"
      class="atlas-taskbar-menu"
      role="menu"
      (contextmenu)="$event.preventDefault()"
      aria-label="Taskbar customization"
      (keydown)="menuKey($event)"
    >
      <div class="atlas-taskbar-menu-heading">Dock taskbar</div>
      @for (position of positions; track position) {
        <button
          type="button"
          role="menuitemradio"
          [attr.aria-checked]="dock() === position"
          (click)="chooseDock(position)"
        >
          {{ position }}
        </button>
      }
      <button type="button" role="menuitem" (click)="openSettings()">
        Taskbar settings…
      </button>
    </div>
    <atlas-dialog
      class="atlas-taskbar-settings-dialog"
      title="Taskbar settings"
      [(open)]="settingsOpen"
    >
      <p class="atlas-muted">Personalize your workspace</p>
      <fieldset class="atlas-dock-options">
        <legend>Taskbar location</legend>
        @for (position of positions; track position) {
          <label
            ><input
              type="radio"
              name="taskbar-dock"
              [value]="position"
              [checked]="pendingDock() === position"
              (change)="pendingDock.set(position)"
            /><span>{{ position }}</span></label
          >
        }
      </fieldset>
      <p>
        The taskbar stays inside this workspace. Your location preference is
        remembered in this browser.
      </p>
      <div atlasDialogActions class="atlas-taskbar-settings-actions">
        <button atlasButton type="button" (click)="settingsOpen.set(false)">
          Cancel</button
        ><button
          atlasButton
          type="button"
          variant="primary"
          (click)="applySettings()"
        >
          Apply
        </button>
      </div>
    </atlas-dialog>
    <dialog
      #confirm
      class="atlas-dialog"
      aria-label="Unsaved changes"
      (cancel)="cancel($event)"
    >
      @if (ws.closing(); as task) {
        <div class="atlas-dialog-icon"><atlas-icon name="save" /></div>
        <h2>Save your changes?</h2>
        <p>
          You have unsaved changes in <strong>{{ task.title }}</strong
          >. Save them before closing this task.
        </p>
        @if (task.error()) {
          <div class="atlas-alert error" role="alert">{{ task.error() }}</div>
        }
        <div class="atlas-dialog-actions">
          <button
            atlasButton
            [disabled]="task.saving()"
            (click)="ws.cancelClose()"
          >
            Keep editing</button
          ><button
            atlasButton
            variant="danger"
            [disabled]="task.saving()"
            (click)="ws.discardClose()"
          >
            Discard</button
          ><button
            atlasButton
            variant="primary"
            [disabled]="task.saving() || !task.lifecycle.save"
            (click)="ws.saveAndClose()"
          >
            {{ task.saving() ? "Saving…" : "Save & close" }}
          </button>
        </div>
      }
    </dialog>`, isInline: true, dependencies: [{ kind: "component", type: AtlasDialog, selector: "atlas-dialog", inputs: ["open", "title", "busy"], outputs: ["openChange", "dismissed"] }, { kind: "component", type: AtlasWindow, selector: "atlas-window", inputs: ["task", "layer"] }, { kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasWorkspace, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-workspace",
                    imports: [AtlasDialog, AtlasWindow, AtlasButton, AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        class: "atlas-workspace",
                        "[attr.data-taskbar-dock]": "dock()",
                        "[class.mobile-workspace]": "ws.mobile()",
                        "(focusin)": "rememberFocus($event)",
                        "(window:beforeunload)": "guardPageExit($event)",
                        "(document:pointerdown)": "dismissTaskbarMenu($event)",
                    },
                    template: `<div class="atlas-workspace-canvas" #canvas>
      <div
        class="atlas-workspace-background"
        [inert]="ws.mobile() && !!ws.activeId()"
      >
        <ng-content />
      </div>
      @for (task of ws.tasks(); track task.id; let i = $index) {
        <atlas-window
          [task]="task"
          [layer]="ws.stackOrder().indexOf(task.id) + 1"
        />
      }
    </div>
    <div
      class="atlas-task-strip"
      aria-label="Open tasks"
      (contextmenu)="openTaskbarMenu($event)"
      (keydown)="taskbarKey($event)"
    >
      <ng-content select="[atlasWorkspaceLauncher]" />
      <button
        #settingsButton
        class="atlas-desktop-button atlas-taskbar-settings-button"
        type="button"
        aria-label="Taskbar settings"
        title="Taskbar settings"
        (click)="openSettings()"
      >
        <atlas-icon name="settings" />
      </button>
      <div class="atlas-task-scroll">
        <button
          class="atlas-desktop-button"
          aria-label="Show workspace home"
          (click)="home()"
        >
          <atlas-icon name="grid" />
        </button>
        <span class="atlas-task-divider"></span>
        @for (task of ws.tasks(); track task.id) {
          <button
            class="atlas-task-button"
            [class.active]="ws.activeId() === task.id"
            [class.minimized]="task.minimized"
            [attr.aria-pressed]="ws.activeId() === task.id"
            (click)="ws.activate(task.id)"
          >
            <atlas-icon [name]="task.icon" /><span>{{ task.title }}</span>
            @if (task.dirty()) {
              <span class="atlas-dirty-dot"></span>
            }
          </button>
        }
        @if (!ws.tasks().length) {
          <span class="atlas-no-tasks">Your open tasks will appear here</span>
        }
        <span class="atlas-task-count">{{ ws.tasks().length }} open</span>
      </div>
    </div>
    <div
      #taskbarMenu
      popover="manual"
      class="atlas-taskbar-menu"
      role="menu"
      (contextmenu)="$event.preventDefault()"
      aria-label="Taskbar customization"
      (keydown)="menuKey($event)"
    >
      <div class="atlas-taskbar-menu-heading">Dock taskbar</div>
      @for (position of positions; track position) {
        <button
          type="button"
          role="menuitemradio"
          [attr.aria-checked]="dock() === position"
          (click)="chooseDock(position)"
        >
          {{ position }}
        </button>
      }
      <button type="button" role="menuitem" (click)="openSettings()">
        Taskbar settings…
      </button>
    </div>
    <atlas-dialog
      class="atlas-taskbar-settings-dialog"
      title="Taskbar settings"
      [(open)]="settingsOpen"
    >
      <p class="atlas-muted">Personalize your workspace</p>
      <fieldset class="atlas-dock-options">
        <legend>Taskbar location</legend>
        @for (position of positions; track position) {
          <label
            ><input
              type="radio"
              name="taskbar-dock"
              [value]="position"
              [checked]="pendingDock() === position"
              (change)="pendingDock.set(position)"
            /><span>{{ position }}</span></label
          >
        }
      </fieldset>
      <p>
        The taskbar stays inside this workspace. Your location preference is
        remembered in this browser.
      </p>
      <div atlasDialogActions class="atlas-taskbar-settings-actions">
        <button atlasButton type="button" (click)="settingsOpen.set(false)">
          Cancel</button
        ><button
          atlasButton
          type="button"
          variant="primary"
          (click)="applySettings()"
        >
          Apply
        </button>
      </div>
    </atlas-dialog>
    <dialog
      #confirm
      class="atlas-dialog"
      aria-label="Unsaved changes"
      (cancel)="cancel($event)"
    >
      @if (ws.closing(); as task) {
        <div class="atlas-dialog-icon"><atlas-icon name="save" /></div>
        <h2>Save your changes?</h2>
        <p>
          You have unsaved changes in <strong>{{ task.title }}</strong
          >. Save them before closing this task.
        </p>
        @if (task.error()) {
          <div class="atlas-alert error" role="alert">{{ task.error() }}</div>
        }
        <div class="atlas-dialog-actions">
          <button
            atlasButton
            [disabled]="task.saving()"
            (click)="ws.cancelClose()"
          >
            Keep editing</button
          ><button
            atlasButton
            variant="danger"
            [disabled]="task.saving()"
            (click)="ws.discardClose()"
          >
            Discard</button
          ><button
            atlasButton
            variant="primary"
            [disabled]="task.saving() || !task.lifecycle.save"
            (click)="ws.saveAndClose()"
          >
            {{ task.saving() ? "Saving…" : "Save & close" }}
          </button>
        </div>
      }
    </dialog>`,
                }]
        }], ctorParameters: () => [], propDecorators: { taskbarMenu: [{ type: i0.ViewChild, args: ["taskbarMenu", { isSignal: true }] }], settingsButton: [{ type: i0.ViewChild, args: ["settingsButton", { isSignal: true }] }], forceMobile: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceMobile", required: false }] }], canvas: [{ type: i0.ViewChild, args: ["canvas", { isSignal: true }] }], confirm: [{ type: i0.ViewChild, args: ["confirm", { isSignal: true }] }] } });

/** Shared collection behavior for list and table presentations. Never mutates consumer data. */
function filterCollection(rows, query, text) {
    const terms = query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
    return rows.filter((row) => {
        const haystack = text(row).toLocaleLowerCase();
        return terms.every((term) => haystack.includes(term));
    });
}
function sortCollection(rows, value, direction = "asc") {
    const multiplier = direction === "asc" ? 1 : -1;
    return [...rows].sort((a, b) => {
        const left = value(a), right = value(b);
        // Empty values stay at the end in either direction.
        if (left == null)
            return right == null ? 0 : 1;
        if (right == null)
            return -1;
        const result = typeof left === "number" && typeof right === "number"
            ? left - right
            : String(left).localeCompare(String(right), undefined, {
                numeric: true,
                sensitivity: "base",
            });
        return result * multiplier;
    });
}
function pageCollection(rows, page, pageSize) {
    const size = Number.isFinite(pageSize)
        ? Math.max(1, Math.floor(pageSize))
        : 10;
    const pages = Math.max(1, Math.ceil(rows.length / size));
    const current = Number.isFinite(page)
        ? Math.max(0, Math.min(Math.floor(page), pages - 1))
        : 0;
    return {
        items: rows.slice(current * size, (current + 1) * size),
        page: current,
        pages,
        total: rows.length,
        size,
    };
}

function sortByColumns(rows, sorts, value) {
    return [...rows].sort((a, b) => {
        for (const sort of sorts) {
            const left = value(a, sort.key), right = value(b, sort.key);
            if (left == null || right == null) {
                if (left == null && right == null)
                    continue;
                return left == null ? 1 : -1;
            }
            const comparison = typeof left === "number" && typeof right === "number"
                ? left - right
                : String(left).localeCompare(String(right), undefined, {
                    numeric: true,
                    sensitivity: "base",
                });
            if (comparison)
                return comparison * (sort.direction === "asc" ? 1 : -1);
        }
        return 0;
    });
}
function matchesColumnFilters(row, filters, value) {
    return Object.entries(filters).every(([key, term]) => value(row, key)
        .toLocaleLowerCase()
        .includes(term.trim().toLocaleLowerCase()));
}
/** Cancels previous work and rejects stale completions even when an adapter ignores AbortSignal. */
class AtlasLatestRequest {
    controller;
    async run(request, accept, reject) {
        this.cancel();
        const controller = (this.controller = new AbortController());
        try {
            const result = await request(controller.signal);
            if (!controller.signal.aborted)
                accept(result);
        }
        catch (error) {
            if (!controller.signal.aborted)
                reject(error);
        }
    }
    cancel() {
        this.controller?.abort();
    }
}

function atlasSummaryQueryKey(query) {
    return JSON.stringify({
        ...query,
        filters: Object.fromEntries(Object.entries(query.filters).sort(([a], [b]) => a.localeCompare(b))),
    });
}
function atlasHeaderBands(columns) {
    const bands = [];
    for (const column of columns) {
        const label = column.group ?? "";
        const last = bands.at(-1);
        if (last && last.label === label)
            last.span++;
        else
            bands.push({ label, span: 1 });
    }
    return bands;
}
function atlasGroupRows(rows, key) {
    const groups = new Map();
    for (const row of rows) {
        const id = key(row);
        const group = groups.get(id);
        if (group)
            group.push(row);
        else
            groups.set(id, [row]);
    }
    return [...groups].map(([key, rows]) => ({ key, rows }));
}
/** Exact fixed-scale signed decimal sum. Invalid precision is rejected, never rounded. */
function atlasSumDecimal(values, scale = 2) {
    if (!Number.isInteger(scale) || scale < 0 || scale > 28)
        throw new Error("Invalid decimal scale.");
    let total = 0n;
    for (const value of values) {
        const match = /^(-?)(0|[1-9]\d*)(?:\.(\d+))?$/.exec(value);
        if (!match || value.length > 100 || (match[3]?.length ?? 0) > scale)
            throw new Error("Invalid decimal value or precision.");
        const units = BigInt(match[2]) * 10n ** BigInt(scale) +
            BigInt((match[3] ?? "").padEnd(scale, "0") || "0");
        total += match[1] ? -units : units;
    }
    const digits = (total < 0n ? -total : total)
        .toString()
        .padStart(scale + 1, "0");
    return ((total < 0n ? "-" : "") +
        (scale ? digits.slice(0, -scale) + "." + digits.slice(-scale) : digits));
}

class AtlasCell {
    key = input.required({ ...(ngDevMode ? { debugName: "key" } : /* istanbul ignore next */ {}), alias: "atlasCell" });
    /** Supplies the row type to Angular's template checker. */
    rows = input.required({ ...(ngDevMode ? { debugName: "rows" } : /* istanbul ignore next */ {}), alias: "atlasCellOf" });
    template = inject(TemplateRef);
    static ngTemplateContextGuard(_directive, context) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCell, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasCell, isStandalone: true, selector: "ng-template[atlasCell]", inputs: { key: { classPropertyName: "key", publicName: "atlasCell", isSignal: true, isRequired: true, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "atlasCellOf", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCell, decorators: [{
            type: Directive,
            args: [{ selector: "ng-template[atlasCell]" }]
        }], propDecorators: { key: [{ type: i0.Input, args: [{ isSignal: true, alias: "atlasCell", required: true }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "atlasCellOf", required: true }] }] } });
class AtlasRowDetail {
    rows = input.required({ ...(ngDevMode ? { debugName: "rows" } : /* istanbul ignore next */ {}), alias: "atlasRowDetailOf" });
    template = inject(TemplateRef);
    static ngTemplateContextGuard(_directive, context) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRowDetail, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasRowDetail, isStandalone: true, selector: "ng-template[atlasRowDetail]", inputs: { rows: { classPropertyName: "rows", publicName: "atlasRowDetailOf", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRowDetail, decorators: [{
            type: Directive,
            args: [{ selector: "ng-template[atlasRowDetail]" }]
        }], propDecorators: { rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "atlasRowDetailOf", required: true }] }] } });
class AtlasTable {
    groupBy = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "groupBy" }] : /* istanbul ignore next */ []));
    summaries = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "summaries" }] : /* istanbul ignore next */ []));
    serverSummary = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "serverSummary" }] : /* istanbul ignore next */ []));
    collapsedGroups = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsedGroups" }] : /* istanbul ignore next */ []));
    hasHeaderGroups = computed(() => this.visibleColumns().some((column) => !!column.group), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasHeaderGroups" }] : /* istanbul ignore next */ []));
    headerBands = computed(() => atlasHeaderBands(this.visibleColumns()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerBands" }] : /* istanbul ignore next */ []));
    pageGroups = computed(() => {
        const key = this.groupBy();
        return key
            ? atlasGroupRows(this.paged(), (row) => String(row[key] ?? ""))
            : this.paged().length
                ? [{ key: "", rows: this.paged() }]
                : [];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageGroups" }] : /* istanbul ignore next */ []));
    acceptedServerSummary = computed(() => {
        const summary = this.serverSummary();
        return summary?.scope === "query" &&
            summary.queryKey === atlasSummaryQueryKey(this.request())
            ? summary
            : null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "acceptedServerSummary" }] : /* istanbul ignore next */ []));
    toggleGroup(key) {
        this.collapsedGroups.update((keys) => keys.includes(key)
            ? keys.filter((value) => value !== key)
            : [...keys, key]);
    }
    rows = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    columns = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    keyField = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "keyField" }] : /* istanbul ignore next */ []));
    pageSize = input(6, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
    rowActivated = output();
    cells = contentChildren(AtlasCell, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cells" }] : /* istanbul ignore next */ []));
    templates = computed(() => new Map(this.cells().map((cell) => [cell.key(), cell.template])), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    sorts = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []));
    addSort = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "addSort" }] : /* istanbul ignore next */ []));
    page = linkedSignal({ ...(ngDevMode ? { debugName: "page" } : /* istanbul ignore next */ {}), source: () => this.pageSize(),
        computation: () => 0 });
    columnFilters = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnFilters" }] : /* istanbul ignore next */ []));
    multiSort = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "multiSort" }] : /* istanbul ignore next */ []));
    columnManage = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnManage" }] : /* istanbul ignore next */ []));
    server = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "server" }] : /* istanbul ignore next */ []));
    total = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []));
    error = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    retry = output();
    queryChange = output();
    filters = signal({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []));
    order = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "order" }] : /* istanbul ignore next */ []));
    widths = signal({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "widths" }] : /* istanbul ignore next */ []));
    pinned = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pinned" }] : /* istanbul ignore next */ []));
    expanded = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []));
    detail = contentChild(AtlasRowDetail, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "detail" }] : /* istanbul ignore next */ []));
    orderedColumns = computed(() => {
        const keys = this.order();
        return [...this.columns()].sort((a, b) => {
            const index = (key) => keys.includes(key)
                ? keys.indexOf(key)
                : keys.length + this.columns().findIndex((c) => c.key === key);
            return index(a.key) - index(b.key);
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orderedColumns" }] : /* istanbul ignore next */ []));
    request = computed(() => ({
        page: this.page(),
        pageSize: Math.max(1, Math.floor(this.pageSize()) || 6),
        search: this.query(),
        filters: this.filters(),
        sort: this.sorts(),
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "request" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const request = this.request();
            untracked(() => this.queryChange.emit(request));
        });
        effect(() => {
            if (this.server() && !this.loading() && !this.error()) {
                const last = Math.max(0, Math.ceil(this.total() / this.request().pageSize) - 1);
                if (this.page() > last)
                    this.page.set(last);
            }
        });
    }
    tableWidth = computed(() => this.visibleColumns().reduce((n, c) => n + this.width(c), this.selectable() ? 134 : 90), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableWidth" }] : /* istanbul ignore next */ []));
    selected = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    label = input("Records", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    filterable = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterable" }] : /* istanbul ignore next */ []));
    selectable = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectable" }] : /* istanbul ignore next */ []));
    columnToggle = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnToggle" }] : /* istanbul ignore next */ []));
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    selectedKeys = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedKeys" }] : /* istanbul ignore next */ []));
    query = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    hiddenColumns = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hiddenColumns" }] : /* istanbul ignore next */ []));
    visibleColumns = computed(() => [
        ...this.orderedColumns().filter((c) => this.pinned().includes(c.key)),
        ...this.orderedColumns().filter((c) => !this.pinned().includes(c.key)),
    ].filter((column) => !this.hiddenColumns().includes(column.key)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleColumns" }] : /* istanbul ignore next */ []));
    filtered = computed(() => filterCollection(this.rows().filter((row) => matchesColumnFilters(row, this.filters(), (r, key) => {
        const c = this.columns().find((c) => c.key === key);
        return c ? this.value(r, c) : "";
    })), this.query(), (row) => this.columns()
        .map((column) => this.value(row, column))
        .join(" ")), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []));
    sorted = computed(() => sortByColumns(this.filtered(), this.sorts(), (row, key) => {
        const column = this.columns().find((c) => c.key === key);
        return column?.sortValue ? column.sortValue(row) : row[key];
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sorted" }] : /* istanbul ignore next */ []));
    totalRecords = computed(() => this.server() ? this.total() : this.filtered().length, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalRecords" }] : /* istanbul ignore next */ []));
    pagination = computed(() => pageCollection(this.sorted(), this.page(), this.pageSize()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pagination" }] : /* istanbul ignore next */ []));
    pageCount = computed(() => this.server()
        ? Math.max(1, Math.ceil(this.total() / this.request().pageSize))
        : this.pagination().pages, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageCount" }] : /* istanbul ignore next */ []));
    safePage = computed(() => this.server() ? this.page() : this.pagination().page, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "safePage" }] : /* istanbul ignore next */ []));
    paged = computed(() => this.server() ? this.rows() : this.pagination().items, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paged" }] : /* istanbul ignore next */ []));
    allPageSelected = computed(() => this.paged().length > 0 &&
        this.paged().every((row) => this.selectedKeys().includes(this.rowKey(row))), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "allPageSelected" }] : /* istanbul ignore next */ []));
    somePageSelected = computed(() => this.paged().some((row) => this.selectedKeys().includes(this.rowKey(row))), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "somePageSelected" }] : /* istanbul ignore next */ []));
    search(query) {
        this.query.set(query);
        this.page.set(0);
    }
    toggleColumn(key) {
        this.hiddenColumns.update((keys) => keys.includes(key)
            ? keys.filter((value) => value !== key)
            : this.visibleColumns().length > 1
                ? [...keys, key]
                : keys);
    }
    toggleRow(row) {
        const key = this.rowKey(row);
        this.selectedKeys.update((keys) => keys.includes(key)
            ? keys.filter((value) => value !== key)
            : [...keys, key]);
    }
    togglePage() {
        const pageKeys = this.paged().map((row) => this.rowKey(row));
        const all = this.allPageSelected();
        this.selectedKeys.update((keys) => all
            ? keys.filter((key) => !pageKeys.includes(key))
            : [...new Set([...keys, ...pageKeys])]);
    }
    sort(key, append = false) {
        const old = this.sorts().find((s) => s.key === key);
        const next = {
            key,
            direction: old?.direction === "asc" ? "desc" : "asc",
        };
        this.sorts.set(this.multiSort() && (append || this.addSort())
            ? old
                ? this.sorts().map((s) => (s.key === key ? next : s))
                : [...this.sorts(), next]
            : [next]);
        this.page.set(0);
    }
    clearSort() {
        this.sorts.set([]);
        this.page.set(0);
    }
    sortIndex(key) {
        return this.sorts().findIndex((s) => s.key === key);
    }
    sortDirection(key) {
        const index = this.sortIndex(key);
        return index < 0
            ? "none"
            : this.sorts().length > 1
                ? "other"
                : this.sorts()[index].direction === "asc"
                    ? "ascending"
                    : "descending";
    }
    filterColumn(key, value) {
        this.filters.update((f) => ({ ...f, [key]: value }));
        this.page.set(0);
    }
    width(column) {
        return this.widths()[column.key] ?? column.width ?? 180;
    }
    setWidth(key, value) {
        if (Number.isFinite(value))
            this.widths.update((w) => ({
                ...w,
                [key]: Math.max(100, Math.min(600, value)),
            }));
    }
    moveColumn(key, delta) {
        const keys = this.orderedColumns().map((c) => c.key);
        const from = keys.indexOf(key), to = from + delta;
        if (to < 0 || to >= keys.length)
            return;
        [keys[from], keys[to]] = [keys[to], keys[from]];
        this.order.set(keys);
    }
    pin(key) {
        this.pinned.update((keys) => keys.includes(key) ? keys.filter((k) => k !== key) : [...keys, key]);
    }
    pinOffset(key) {
        if (!this.pinned().includes(key))
            return null;
        const columns = this.visibleColumns();
        return columns
            .slice(0, columns.findIndex((c) => c.key === key))
            .filter((c) => this.pinned().includes(c.key))
            .reduce((n, c) => n + this.width(c), 0);
    }
    toggleDetail(row) {
        const key = this.rowKey(row);
        this.expanded.update((keys) => keys.includes(key) ? keys.filter((k) => k !== key) : [...keys, key]);
    }
    resizing;
    resizeStart(event, column) {
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        this.resizing = {
            key: column.key,
            x: event.clientX,
            width: this.width(column),
        };
    }
    resizeMove(event) {
        if (this.resizing)
            this.setWidth(this.resizing.key, this.resizing.width + event.clientX - this.resizing.x);
    }
    resizeEnd(event) {
        this.resizing = undefined;
        const target = event.currentTarget;
        if (target.hasPointerCapture(event.pointerId))
            target.releasePointerCapture(event.pointerId);
    }
    rowKey(row) {
        return String(row[this.keyField()]);
    }
    value(row, column) {
        return column.format ? column.format(row) : String(row[column.key] ?? "");
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTable, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTable, isStandalone: true, selector: "atlas-table", inputs: { groupBy: { classPropertyName: "groupBy", publicName: "groupBy", isSignal: true, isRequired: false, transformFunction: null }, summaries: { classPropertyName: "summaries", publicName: "summaries", isSignal: true, isRequired: false, transformFunction: null }, serverSummary: { classPropertyName: "serverSummary", publicName: "serverSummary", isSignal: true, isRequired: false, transformFunction: null }, collapsedGroups: { classPropertyName: "collapsedGroups", publicName: "collapsedGroups", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: true, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, keyField: { classPropertyName: "keyField", publicName: "keyField", isSignal: true, isRequired: true, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, columnFilters: { classPropertyName: "columnFilters", publicName: "columnFilters", isSignal: true, isRequired: false, transformFunction: null }, multiSort: { classPropertyName: "multiSort", publicName: "multiSort", isSignal: true, isRequired: false, transformFunction: null }, columnManage: { classPropertyName: "columnManage", publicName: "columnManage", isSignal: true, isRequired: false, transformFunction: null }, server: { classPropertyName: "server", publicName: "server", isSignal: true, isRequired: false, transformFunction: null }, total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, columnToggle: { classPropertyName: "columnToggle", publicName: "columnToggle", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, selectedKeys: { classPropertyName: "selectedKeys", publicName: "selectedKeys", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { collapsedGroups: "collapsedGroupsChange", rowActivated: "rowActivated", retry: "retry", queryChange: "queryChange", selectedKeys: "selectedKeysChange" }, queries: [{ propertyName: "cells", predicate: AtlasCell, isSignal: true }, { propertyName: "detail", first: true, predicate: AtlasRowDetail, descendants: true, isSignal: true }], ngImport: i0, template: `<div class="atlas-data-table">
    @if (filterable() || columnToggle() || selectable()) {
      <div class="atlas-collection-toolbar">
        @if (filterable()) {
          <div class="atlas-collection-search">
            <atlas-icon name="search" /><input
              atlasInput
              [attr.aria-label]="'Search ' + label()"
              placeholder="Search all columns…"
              [value]="query()"
              (input)="search($any($event.target).value)"
            />
          </div>
        }
        <div class="atlas-collection-actions">
          @if (multiSort()) {
            <label class="atlas-sort-mode"
              ><input
                type="checkbox"
                [checked]="addSort()"
                (change)="addSort.set($any($event.target).checked)"
              />Add sort levels</label
            >
          }
          @if (sorts().length) {
            <button
              type="button"
              class="atlas-control-action"
              (click)="clearSort()"
            >
              Clear sort
            </button>
          }
          @if (selectedKeys().length) {
            <span class="atlas-selection-count"
              >{{ selectedKeys().length }} selected</span
            ><button
              type="button"
              class="atlas-control-action"
              aria-label="Clear row selection"
              (click)="selectedKeys.set([])"
            >
              <atlas-icon name="close" />
            </button>
          }
          @if (columnToggle()) {
            <details class="atlas-column-picker">
              <summary><atlas-icon name="settings" />Columns</summary>
              <fieldset>
                <legend class="atlas-sr-only">Visible columns</legend>
                @for (column of orderedColumns(); track column.key) {
                  <label
                    ><input
                      type="checkbox"
                      [checked]="!hiddenColumns().includes(column.key)"
                      [disabled]="
                        visibleColumns().length === 1 &&
                        !hiddenColumns().includes(column.key)
                      "
                      (change)="toggleColumn(column.key)"
                    />{{ column.label }}</label
                  >
                  @if (columnManage()) {
                    <div class="atlas-column-settings">
                      <button
                        type="button"
                        [attr.aria-label]="'Move ' + column.label + ' left'"
                        [disabled]="$first"
                        (click)="moveColumn(column.key, -1)"
                      >
                        ←
                      </button>
                      <button
                        type="button"
                        [attr.aria-label]="'Move ' + column.label + ' right'"
                        [disabled]="$last"
                        (click)="moveColumn(column.key, 1)"
                      >
                        →
                      </button>
                      <button
                        type="button"
                        [attr.aria-label]="'Pin ' + column.label"
                        [attr.aria-pressed]="pinned().includes(column.key)"
                        (click)="pin(column.key)"
                      >
                        {{ pinned().includes(column.key) ? "Unpin" : "Pin" }}
                      </button>
                      <input
                        type="number"
                        min="100"
                        max="600"
                        step="20"
                        [attr.aria-label]="column.label + ' width'"
                        [value]="width(column)"
                        (change)="
                          setWidth(
                            column.key,
                            $any($event.target).valueAsNumber
                          )
                        "
                      />
                    </div>
                  }
                }
              </fieldset>
            </details>
          }
        </div>
      </div>
    }
    <div class="atlas-table-scroll" [attr.aria-busy]="loading()">
      <table
        class="atlas-table"
        [class.atlas-managed-table]="columnManage()"
        [style.width.px]="columnManage() ? tableWidth() : null"
        [attr.aria-label]="label()"
      >
        @if (columnManage()) {
          <colgroup>
            @if (selectable()) {
              <col style="width:44px" />
            }
            @for (column of visibleColumns(); track column.key) {
              <col [style.width.px]="width(column)" />
            }
            <col style="width:90px" />
          </colgroup>
        }
        <thead>
          @if (hasHeaderGroups()) {
            <tr class="atlas-header-bands">
              @if (selectable()) {
                <th></th>
              }
              @for (band of headerBands(); track $index) {
                <th scope="colgroup" [attr.colspan]="band.span">
                  {{ band.label }}
                </th>
              }
              <th></th>
            </tr>
          }
          <tr>
            @if (selectable()) {
              <th class="atlas-checkbox-cell">
                <input
                  type="checkbox"
                  aria-label="Select all rows on this page"
                  [checked]="allPageSelected()"
                  [indeterminate]="somePageSelected() && !allPageSelected()"
                  [disabled]="!paged().length || loading() || !!error()"
                  (change)="togglePage()"
                />
              </th>
            }
            @for (column of visibleColumns(); track column.key) {
              <th
                [style.text-align]="column.align || 'left'"
                [style.min-width.px]="columnManage() ? width(column) : null"
                [style.width.px]="columnManage() ? width(column) : null"
                [class.atlas-pinned]="pinned().includes(column.key)"
                [style.left.px]="pinOffset(column.key)"
                [attr.aria-sort]="sortDirection(column.key)"
              >
                <button
                  type="button"
                  [disabled]="column.sortable === false"
                  (click)="sort(column.key, $event.shiftKey)"
                >
                  {{ column.label }}
                  @if (sortIndex(column.key) >= 0) {
                    <span
                      >{{
                        sorts()[sortIndex(column.key)].direction === "desc"
                          ? "↓"
                          : "↑"
                      }}
                      {{ sortIndex(column.key) + 1 }}</span
                    >
                  }
                </button>
                @if (columnManage()) {
                  <span
                    class="atlas-column-resizer"
                    aria-hidden="true"
                    (pointerdown)="resizeStart($event, column)"
                    (pointermove)="resizeMove($event)"
                    (pointerup)="resizeEnd($event)"
                    (pointercancel)="resizeEnd($event)"
                  ></span>
                }
              </th>
            }
            <th><span class="atlas-sr-only">Open record</span></th>
          </tr>
          @if (columnFilters()) {
            <tr>
              @if (selectable()) {
                <th></th>
              }
              @for (column of visibleColumns(); track column.key) {
                <th
                  [class.atlas-pinned]="pinned().includes(column.key)"
                  [style.left.px]="pinOffset(column.key)"
                >
                  @if (column.filterable !== false) {
                    <input
                      atlasInput
                      class="atlas-column-filter"
                      [attr.aria-label]="'Filter ' + column.label"
                      placeholder="Contains…"
                      [value]="filters()[column.key] || ''"
                      (input)="
                        filterColumn(column.key, $any($event.target).value)
                      "
                    />
                  }
                </th>
              }
              <th></th>
            </tr>
          }
        </thead>
        <tbody>
          @if (error() && !loading()) {
            <tr>
              <td
                [attr.colspan]="
                  visibleColumns().length + (selectable() ? 2 : 1)
                "
                class="atlas-table-empty"
              >
                <p role="alert">{{ error() }}</p>
                <button type="button" (click)="retry.emit()">Retry</button>
              </td>
            </tr>
          } @else if (loading()) {
            <tr>
              <td
                [attr.colspan]="
                  visibleColumns().length + (selectable() ? 2 : 1)
                "
                class="atlas-table-empty"
              >
                <span role="status">Loading records…</span>
              </td>
            </tr>
          } @else {
            @for (group of pageGroups(); track group.key) {
              @if (groupBy()) {
                <tr class="atlas-group-heading">
                  <th
                    [attr.colspan]="
                      visibleColumns().length + (selectable() ? 2 : 1)
                    "
                  >
                    <button
                      type="button"
                      [attr.aria-expanded]="
                        !collapsedGroups().includes(group.key)
                      "
                      (click)="toggleGroup(group.key)"
                    >
                      <span aria-hidden="true">{{
                        collapsedGroups().includes(group.key) ? "▸" : "▾"
                      }}</span>
                      {{ group.key || "Unassigned" }}
                      <span class="atlas-muted"
                        >· {{ group.rows.length }} on this page</span
                      >
                    </button>
                  </th>
                </tr>
              }
              @if (!groupBy() || !collapsedGroups().includes(group.key)) {
                @for (row of group.rows; track rowKey(row)) {
                  <tr
                    [class.selected]="
                      selectedKeys().includes(rowKey(row)) ||
                      selected() === rowKey(row)
                    "
                  >
                    @if (selectable()) {
                      <td class="atlas-checkbox-cell">
                        <input
                          type="checkbox"
                          [attr.aria-label]="'Select ' + rowKey(row)"
                          [checked]="selectedKeys().includes(rowKey(row))"
                          (change)="toggleRow(row)"
                        />
                      </td>
                    }
                    @for (column of visibleColumns(); track column.key) {
                      <td
                        [style.text-align]="column.align || 'left'"
                        [class.atlas-pinned]="pinned().includes(column.key)"
                        [style.left.px]="pinOffset(column.key)"
                      >
                        @if (templates().get(column.key); as template) {
                          <ng-container
                            [ngTemplateOutlet]="template"
                            [ngTemplateOutletContext]="{
                              $implicit: row,
                              value: row[column.key],
                            }"
                          />
                        } @else if (column.badge) {
                          <span
                            class="atlas-badge"
                            [attr.data-tone]="
                              column.tone ? column.tone(row) : 'neutral'
                            "
                            >{{ value(row, column) }}</span
                          >
                        } @else {
                          {{ value(row, column) }}
                        }
                      </td>
                    }
                    <td>
                      @if (detail(); as detailTemplate) {
                        <button
                          type="button"
                          class="atlas-row-open"
                          [attr.aria-label]="'Details ' + rowKey(row)"
                          [attr.aria-expanded]="
                            expanded().includes(rowKey(row))
                          "
                          (click)="toggleDetail(row)"
                        >
                          {{ expanded().includes(rowKey(row)) ? "−" : "+" }}
                        </button>
                      }
                      <button
                        type="button"
                        class="atlas-row-open"
                        [attr.aria-label]="'Open ' + rowKey(row)"
                        (click)="
                          selected.set(rowKey(row)); rowActivated.emit(row)
                        "
                      >
                        <atlas-icon name="arrow" />
                      </button>
                    </td>
                  </tr>
                  @if (
                    expanded().includes(rowKey(row)) && detail();
                    as detailTemplate
                  ) {
                    <tr>
                      <td
                        class="atlas-row-detail"
                        [attr.colspan]="
                          visibleColumns().length + (selectable() ? 2 : 1)
                        "
                      >
                        <ng-container
                          [ngTemplateOutlet]="detailTemplate.template"
                          [ngTemplateOutletContext]="{ $implicit: row }"
                        />
                      </td>
                    </tr>
                  }
                }
              }
              @if (groupBy() && summaries().length) {
                <tr class="atlas-summary-row">
                  <td
                    [attr.colspan]="
                      visibleColumns().length + (selectable() ? 2 : 1)
                    "
                  >
                    <div class="atlas-summary-values">
                      <strong
                        >{{ group.key || "Unassigned" }} · page subtotal</strong
                      >
                      @for (summary of summaries(); track summary.key) {
                        <span
                          >{{ summary.label }}
                          <b>{{ summary.aggregate(group.rows) }}</b></span
                        >
                      }
                    </div>
                  </td>
                </tr>
              }
            } @empty {
              <tr>
                <td
                  [attr.colspan]="
                    visibleColumns().length + (selectable() ? 2 : 1)
                  "
                  class="atlas-table-empty"
                >
                  No records match your filters.
                </td>
              </tr>
            }
          }
        </tbody>
        @if (summaries().length && !loading() && !error()) {
          <tfoot>
            <tr class="atlas-summary-row">
              <td
                [attr.colspan]="
                  visibleColumns().length + (selectable() ? 2 : 1)
                "
              >
                <div class="atlas-summary-values">
                  <strong>Page total · {{ paged().length }} records</strong>
                  @for (summary of summaries(); track summary.key) {
                    <span
                      >{{ summary.label }}
                      <b>{{ summary.aggregate(paged()) }}</b></span
                    >
                  }
                </div>
                <div class="atlas-summary-values">
                  <strong>{{
                    server()
                      ? "Whole query total · server"
                      : "Filtered total · all matching records"
                  }}</strong>
                  @if (!server()) {
                    @for (summary of summaries(); track summary.key) {
                      <span
                        >{{ summary.label }}
                        <b>{{ summary.aggregate(filtered()) }}</b></span
                      >
                    }
                  } @else if (acceptedServerSummary(); as remote) {
                    @for (summary of summaries(); track summary.key) {
                      <span
                        >{{ summary.label }}
                        <b>{{
                          remote.values[summary.key] ?? "Unavailable"
                        }}</b></span
                      >
                    }
                  } @else {
                    <span>Not supplied for this request</span>
                  }
                </div>
              </td>
            </tr>
          </tfoot>
        }
      </table>
    </div>
    <footer class="atlas-table-footer">
      <span
        >{{ totalRecords() }}
        {{ totalRecords() === 1 ? "record" : "records" }}
        <span class="atlas-muted"
          >· Page {{ safePage() + 1 }} of {{ pageCount() }}</span
        ></span
      >
      <div>
        <button
          class="atlas-window-control"
          aria-label="Previous page"
          [disabled]="loading() || safePage() === 0"
          (click)="page.set(safePage() - 1)"
        >
          <atlas-icon name="back" /></button
        ><button
          class="atlas-window-control"
          aria-label="Next page"
          [disabled]="loading() || safePage() + 1 >= pageCount()"
          (click)="page.set(safePage() + 1)"
        >
          <atlas-icon name="arrow" />
        </button>
      </div>
    </footer>
  </div>`, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTable, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-table",
                    imports: [AtlasIcon, AtlasInput, NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<div class="atlas-data-table">
    @if (filterable() || columnToggle() || selectable()) {
      <div class="atlas-collection-toolbar">
        @if (filterable()) {
          <div class="atlas-collection-search">
            <atlas-icon name="search" /><input
              atlasInput
              [attr.aria-label]="'Search ' + label()"
              placeholder="Search all columns…"
              [value]="query()"
              (input)="search($any($event.target).value)"
            />
          </div>
        }
        <div class="atlas-collection-actions">
          @if (multiSort()) {
            <label class="atlas-sort-mode"
              ><input
                type="checkbox"
                [checked]="addSort()"
                (change)="addSort.set($any($event.target).checked)"
              />Add sort levels</label
            >
          }
          @if (sorts().length) {
            <button
              type="button"
              class="atlas-control-action"
              (click)="clearSort()"
            >
              Clear sort
            </button>
          }
          @if (selectedKeys().length) {
            <span class="atlas-selection-count"
              >{{ selectedKeys().length }} selected</span
            ><button
              type="button"
              class="atlas-control-action"
              aria-label="Clear row selection"
              (click)="selectedKeys.set([])"
            >
              <atlas-icon name="close" />
            </button>
          }
          @if (columnToggle()) {
            <details class="atlas-column-picker">
              <summary><atlas-icon name="settings" />Columns</summary>
              <fieldset>
                <legend class="atlas-sr-only">Visible columns</legend>
                @for (column of orderedColumns(); track column.key) {
                  <label
                    ><input
                      type="checkbox"
                      [checked]="!hiddenColumns().includes(column.key)"
                      [disabled]="
                        visibleColumns().length === 1 &&
                        !hiddenColumns().includes(column.key)
                      "
                      (change)="toggleColumn(column.key)"
                    />{{ column.label }}</label
                  >
                  @if (columnManage()) {
                    <div class="atlas-column-settings">
                      <button
                        type="button"
                        [attr.aria-label]="'Move ' + column.label + ' left'"
                        [disabled]="$first"
                        (click)="moveColumn(column.key, -1)"
                      >
                        ←
                      </button>
                      <button
                        type="button"
                        [attr.aria-label]="'Move ' + column.label + ' right'"
                        [disabled]="$last"
                        (click)="moveColumn(column.key, 1)"
                      >
                        →
                      </button>
                      <button
                        type="button"
                        [attr.aria-label]="'Pin ' + column.label"
                        [attr.aria-pressed]="pinned().includes(column.key)"
                        (click)="pin(column.key)"
                      >
                        {{ pinned().includes(column.key) ? "Unpin" : "Pin" }}
                      </button>
                      <input
                        type="number"
                        min="100"
                        max="600"
                        step="20"
                        [attr.aria-label]="column.label + ' width'"
                        [value]="width(column)"
                        (change)="
                          setWidth(
                            column.key,
                            $any($event.target).valueAsNumber
                          )
                        "
                      />
                    </div>
                  }
                }
              </fieldset>
            </details>
          }
        </div>
      </div>
    }
    <div class="atlas-table-scroll" [attr.aria-busy]="loading()">
      <table
        class="atlas-table"
        [class.atlas-managed-table]="columnManage()"
        [style.width.px]="columnManage() ? tableWidth() : null"
        [attr.aria-label]="label()"
      >
        @if (columnManage()) {
          <colgroup>
            @if (selectable()) {
              <col style="width:44px" />
            }
            @for (column of visibleColumns(); track column.key) {
              <col [style.width.px]="width(column)" />
            }
            <col style="width:90px" />
          </colgroup>
        }
        <thead>
          @if (hasHeaderGroups()) {
            <tr class="atlas-header-bands">
              @if (selectable()) {
                <th></th>
              }
              @for (band of headerBands(); track $index) {
                <th scope="colgroup" [attr.colspan]="band.span">
                  {{ band.label }}
                </th>
              }
              <th></th>
            </tr>
          }
          <tr>
            @if (selectable()) {
              <th class="atlas-checkbox-cell">
                <input
                  type="checkbox"
                  aria-label="Select all rows on this page"
                  [checked]="allPageSelected()"
                  [indeterminate]="somePageSelected() && !allPageSelected()"
                  [disabled]="!paged().length || loading() || !!error()"
                  (change)="togglePage()"
                />
              </th>
            }
            @for (column of visibleColumns(); track column.key) {
              <th
                [style.text-align]="column.align || 'left'"
                [style.min-width.px]="columnManage() ? width(column) : null"
                [style.width.px]="columnManage() ? width(column) : null"
                [class.atlas-pinned]="pinned().includes(column.key)"
                [style.left.px]="pinOffset(column.key)"
                [attr.aria-sort]="sortDirection(column.key)"
              >
                <button
                  type="button"
                  [disabled]="column.sortable === false"
                  (click)="sort(column.key, $event.shiftKey)"
                >
                  {{ column.label }}
                  @if (sortIndex(column.key) >= 0) {
                    <span
                      >{{
                        sorts()[sortIndex(column.key)].direction === "desc"
                          ? "↓"
                          : "↑"
                      }}
                      {{ sortIndex(column.key) + 1 }}</span
                    >
                  }
                </button>
                @if (columnManage()) {
                  <span
                    class="atlas-column-resizer"
                    aria-hidden="true"
                    (pointerdown)="resizeStart($event, column)"
                    (pointermove)="resizeMove($event)"
                    (pointerup)="resizeEnd($event)"
                    (pointercancel)="resizeEnd($event)"
                  ></span>
                }
              </th>
            }
            <th><span class="atlas-sr-only">Open record</span></th>
          </tr>
          @if (columnFilters()) {
            <tr>
              @if (selectable()) {
                <th></th>
              }
              @for (column of visibleColumns(); track column.key) {
                <th
                  [class.atlas-pinned]="pinned().includes(column.key)"
                  [style.left.px]="pinOffset(column.key)"
                >
                  @if (column.filterable !== false) {
                    <input
                      atlasInput
                      class="atlas-column-filter"
                      [attr.aria-label]="'Filter ' + column.label"
                      placeholder="Contains…"
                      [value]="filters()[column.key] || ''"
                      (input)="
                        filterColumn(column.key, $any($event.target).value)
                      "
                    />
                  }
                </th>
              }
              <th></th>
            </tr>
          }
        </thead>
        <tbody>
          @if (error() && !loading()) {
            <tr>
              <td
                [attr.colspan]="
                  visibleColumns().length + (selectable() ? 2 : 1)
                "
                class="atlas-table-empty"
              >
                <p role="alert">{{ error() }}</p>
                <button type="button" (click)="retry.emit()">Retry</button>
              </td>
            </tr>
          } @else if (loading()) {
            <tr>
              <td
                [attr.colspan]="
                  visibleColumns().length + (selectable() ? 2 : 1)
                "
                class="atlas-table-empty"
              >
                <span role="status">Loading records…</span>
              </td>
            </tr>
          } @else {
            @for (group of pageGroups(); track group.key) {
              @if (groupBy()) {
                <tr class="atlas-group-heading">
                  <th
                    [attr.colspan]="
                      visibleColumns().length + (selectable() ? 2 : 1)
                    "
                  >
                    <button
                      type="button"
                      [attr.aria-expanded]="
                        !collapsedGroups().includes(group.key)
                      "
                      (click)="toggleGroup(group.key)"
                    >
                      <span aria-hidden="true">{{
                        collapsedGroups().includes(group.key) ? "▸" : "▾"
                      }}</span>
                      {{ group.key || "Unassigned" }}
                      <span class="atlas-muted"
                        >· {{ group.rows.length }} on this page</span
                      >
                    </button>
                  </th>
                </tr>
              }
              @if (!groupBy() || !collapsedGroups().includes(group.key)) {
                @for (row of group.rows; track rowKey(row)) {
                  <tr
                    [class.selected]="
                      selectedKeys().includes(rowKey(row)) ||
                      selected() === rowKey(row)
                    "
                  >
                    @if (selectable()) {
                      <td class="atlas-checkbox-cell">
                        <input
                          type="checkbox"
                          [attr.aria-label]="'Select ' + rowKey(row)"
                          [checked]="selectedKeys().includes(rowKey(row))"
                          (change)="toggleRow(row)"
                        />
                      </td>
                    }
                    @for (column of visibleColumns(); track column.key) {
                      <td
                        [style.text-align]="column.align || 'left'"
                        [class.atlas-pinned]="pinned().includes(column.key)"
                        [style.left.px]="pinOffset(column.key)"
                      >
                        @if (templates().get(column.key); as template) {
                          <ng-container
                            [ngTemplateOutlet]="template"
                            [ngTemplateOutletContext]="{
                              $implicit: row,
                              value: row[column.key],
                            }"
                          />
                        } @else if (column.badge) {
                          <span
                            class="atlas-badge"
                            [attr.data-tone]="
                              column.tone ? column.tone(row) : 'neutral'
                            "
                            >{{ value(row, column) }}</span
                          >
                        } @else {
                          {{ value(row, column) }}
                        }
                      </td>
                    }
                    <td>
                      @if (detail(); as detailTemplate) {
                        <button
                          type="button"
                          class="atlas-row-open"
                          [attr.aria-label]="'Details ' + rowKey(row)"
                          [attr.aria-expanded]="
                            expanded().includes(rowKey(row))
                          "
                          (click)="toggleDetail(row)"
                        >
                          {{ expanded().includes(rowKey(row)) ? "−" : "+" }}
                        </button>
                      }
                      <button
                        type="button"
                        class="atlas-row-open"
                        [attr.aria-label]="'Open ' + rowKey(row)"
                        (click)="
                          selected.set(rowKey(row)); rowActivated.emit(row)
                        "
                      >
                        <atlas-icon name="arrow" />
                      </button>
                    </td>
                  </tr>
                  @if (
                    expanded().includes(rowKey(row)) && detail();
                    as detailTemplate
                  ) {
                    <tr>
                      <td
                        class="atlas-row-detail"
                        [attr.colspan]="
                          visibleColumns().length + (selectable() ? 2 : 1)
                        "
                      >
                        <ng-container
                          [ngTemplateOutlet]="detailTemplate.template"
                          [ngTemplateOutletContext]="{ $implicit: row }"
                        />
                      </td>
                    </tr>
                  }
                }
              }
              @if (groupBy() && summaries().length) {
                <tr class="atlas-summary-row">
                  <td
                    [attr.colspan]="
                      visibleColumns().length + (selectable() ? 2 : 1)
                    "
                  >
                    <div class="atlas-summary-values">
                      <strong
                        >{{ group.key || "Unassigned" }} · page subtotal</strong
                      >
                      @for (summary of summaries(); track summary.key) {
                        <span
                          >{{ summary.label }}
                          <b>{{ summary.aggregate(group.rows) }}</b></span
                        >
                      }
                    </div>
                  </td>
                </tr>
              }
            } @empty {
              <tr>
                <td
                  [attr.colspan]="
                    visibleColumns().length + (selectable() ? 2 : 1)
                  "
                  class="atlas-table-empty"
                >
                  No records match your filters.
                </td>
              </tr>
            }
          }
        </tbody>
        @if (summaries().length && !loading() && !error()) {
          <tfoot>
            <tr class="atlas-summary-row">
              <td
                [attr.colspan]="
                  visibleColumns().length + (selectable() ? 2 : 1)
                "
              >
                <div class="atlas-summary-values">
                  <strong>Page total · {{ paged().length }} records</strong>
                  @for (summary of summaries(); track summary.key) {
                    <span
                      >{{ summary.label }}
                      <b>{{ summary.aggregate(paged()) }}</b></span
                    >
                  }
                </div>
                <div class="atlas-summary-values">
                  <strong>{{
                    server()
                      ? "Whole query total · server"
                      : "Filtered total · all matching records"
                  }}</strong>
                  @if (!server()) {
                    @for (summary of summaries(); track summary.key) {
                      <span
                        >{{ summary.label }}
                        <b>{{ summary.aggregate(filtered()) }}</b></span
                      >
                    }
                  } @else if (acceptedServerSummary(); as remote) {
                    @for (summary of summaries(); track summary.key) {
                      <span
                        >{{ summary.label }}
                        <b>{{
                          remote.values[summary.key] ?? "Unavailable"
                        }}</b></span
                      >
                    }
                  } @else {
                    <span>Not supplied for this request</span>
                  }
                </div>
              </td>
            </tr>
          </tfoot>
        }
      </table>
    </div>
    <footer class="atlas-table-footer">
      <span
        >{{ totalRecords() }}
        {{ totalRecords() === 1 ? "record" : "records" }}
        <span class="atlas-muted"
          >· Page {{ safePage() + 1 }} of {{ pageCount() }}</span
        ></span
      >
      <div>
        <button
          class="atlas-window-control"
          aria-label="Previous page"
          [disabled]="loading() || safePage() === 0"
          (click)="page.set(safePage() - 1)"
        >
          <atlas-icon name="back" /></button
        ><button
          class="atlas-window-control"
          aria-label="Next page"
          [disabled]="loading() || safePage() + 1 >= pageCount()"
          (click)="page.set(safePage() + 1)"
        >
          <atlas-icon name="arrow" />
        </button>
      </div>
    </footer>
  </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { groupBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupBy", required: false }] }], summaries: [{ type: i0.Input, args: [{ isSignal: true, alias: "summaries", required: false }] }], serverSummary: [{ type: i0.Input, args: [{ isSignal: true, alias: "serverSummary", required: false }] }], collapsedGroups: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsedGroups", required: false }] }, { type: i0.Output, args: ["collapsedGroupsChange"] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: true }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], keyField: [{ type: i0.Input, args: [{ isSignal: true, alias: "keyField", required: true }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], rowActivated: [{ type: i0.Output, args: ["rowActivated"] }], cells: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => AtlasCell), { isSignal: true }] }], columnFilters: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnFilters", required: false }] }], multiSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiSort", required: false }] }], columnManage: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnManage", required: false }] }], server: [{ type: i0.Input, args: [{ isSignal: true, alias: "server", required: false }] }], total: [{ type: i0.Input, args: [{ isSignal: true, alias: "total", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], retry: [{ type: i0.Output, args: ["retry"] }], queryChange: [{ type: i0.Output, args: ["queryChange"] }], detail: [{ type: i0.ContentChild, args: [i0.forwardRef(() => AtlasRowDetail), { isSignal: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: false }] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }], columnToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnToggle", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], selectedKeys: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedKeys", required: false }] }, { type: i0.Output, args: ["selectedKeysChange"] }] } });

/** Shared forms contract; presentation can be native, Atlas, or an adapter. */
class AtlasValueControl {
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    placeholder = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    value = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    change = () => { };
    touch = () => { };
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(callback) {
        this.change = callback;
    }
    registerOnTouched(callback) {
        this.touch = callback;
    }
    setDisabledState(disabled) {
        this.disabled.set(disabled);
    }
    commit(value) {
        if (this.disabled() || this.readonly())
            return;
        this.value.set(value);
        this.change(value);
    }
    markTouched() {
        this.touch();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasValueControl, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasValueControl, isStandalone: true, inputs: { controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasValueControl, decorators: [{
            type: Directive
        }], propDecorators: { controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }] } });

class AtlasTextInput extends AtlasValueControl {
    type = input("text", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    icon = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    prefix = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefix" }] : /* istanbul ignore next */ []));
    suffix = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suffix" }] : /* istanbul ignore next */ []));
    clearable = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearable" }] : /* istanbul ignore next */ []));
    autocomplete = input("off", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "autocomplete" }] : /* istanbul ignore next */ []));
    maxLength = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []));
    revealed = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "revealed" }] : /* istanbul ignore next */ []));
    edit(value) {
        this.commit(value);
    }
    clear() {
        this.commit("");
        this.markTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTextInput, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTextInput, isStandalone: true, selector: "atlas-text-input", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, maxLength: { classPropertyName: "maxLength", publicName: "maxLength", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-disabled": "disabled()" }, classAttribute: "atlas-control" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => AtlasTextInput),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: `<div
    class="atlas-input-shell"
    [class.is-invalid]="invalid()"
    [class.is-readonly]="readonly()"
  >
    @if (icon()) {
      <atlas-icon [name]="icon()" />
    }
    @if (prefix()) {
      <span class="atlas-input-addon">{{ prefix() }}</span>
    }
    <input
      [id]="controlId()"
      [type]="type() === 'password' && revealed() ? 'text' : type()"
      [value]="value() ?? ''"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [placeholder]="placeholder()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid()"
      [attr.autocomplete]="autocomplete()"
      [attr.maxlength]="maxLength()"
      (input)="edit($any($event.target).value)"
      (blur)="markTouched()"
    />
    @if (clearable() && value() && !readonly() && !disabled()) {
      <button
        type="button"
        class="atlas-control-action"
        [attr.aria-label]="'Clear ' + (ariaLabel() || 'input')"
        (click)="clear()"
      >
        <atlas-icon name="close" />
      </button>
    }
    @if (type() === "password") {
      <button
        type="button"
        class="atlas-control-action password-action"
        [disabled]="disabled()"
        [attr.aria-label]="revealed() ? 'Hide password' : 'Show password'"
        [attr.aria-pressed]="revealed()"
        (click)="revealed.set(!revealed())"
      >
        {{ revealed() ? "Hide" : "Show" }}
      </button>
    }
    @if (suffix()) {
      <span class="atlas-input-addon">{{ suffix() }}</span>
    }
  </div>`, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTextInput, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-text-input",
                    imports: [AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => AtlasTextInput),
                            multi: true,
                        },
                    ],
                    host: { class: "atlas-control", "[class.is-disabled]": "disabled()" },
                    template: `<div
    class="atlas-input-shell"
    [class.is-invalid]="invalid()"
    [class.is-readonly]="readonly()"
  >
    @if (icon()) {
      <atlas-icon [name]="icon()" />
    }
    @if (prefix()) {
      <span class="atlas-input-addon">{{ prefix() }}</span>
    }
    <input
      [id]="controlId()"
      [type]="type() === 'password' && revealed() ? 'text' : type()"
      [value]="value() ?? ''"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [placeholder]="placeholder()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid()"
      [attr.autocomplete]="autocomplete()"
      [attr.maxlength]="maxLength()"
      (input)="edit($any($event.target).value)"
      (blur)="markTouched()"
    />
    @if (clearable() && value() && !readonly() && !disabled()) {
      <button
        type="button"
        class="atlas-control-action"
        [attr.aria-label]="'Clear ' + (ariaLabel() || 'input')"
        (click)="clear()"
      >
        <atlas-icon name="close" />
      </button>
    }
    @if (type() === "password") {
      <button
        type="button"
        class="atlas-control-action password-action"
        [disabled]="disabled()"
        [attr.aria-label]="revealed() ? 'Hide password' : 'Show password'"
        [attr.aria-pressed]="revealed()"
        (click)="revealed.set(!revealed())"
      >
        {{ revealed() ? "Hide" : "Show" }}
      </button>
    }
    @if (suffix()) {
      <span class="atlas-input-addon">{{ suffix() }}</span>
    }
  </div>`,
                }]
        }], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], autocomplete: [{ type: i0.Input, args: [{ isSignal: true, alias: "autocomplete", required: false }] }], maxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLength", required: false }] }] } });
class AtlasNumberInput extends AtlasValueControl {
    min = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    step = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []));
    prefix = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefix" }] : /* istanbul ignore next */ []));
    suffix = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suffix" }] : /* istanbul ignore next */ []));
    showButtons = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showButtons" }] : /* istanbul ignore next */ []));
    edit(value) {
        this.commit(value === ""
            ? null
            : Number.isFinite(Number(value))
                ? Number(value)
                : null);
    }
    increment(direction) {
        const next = Number(((this.value() ?? 0) + direction * this.step()).toFixed(10));
        this.commit(Math.min(this.max() ?? Infinity, Math.max(this.min() ?? -Infinity, next)));
        this.markTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasNumberInput, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasNumberInput, isStandalone: true, selector: "atlas-number-input", inputs: { min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, showButtons: { classPropertyName: "showButtons", publicName: "showButtons", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-disabled": "disabled()" }, classAttribute: "atlas-control" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => AtlasNumberInput),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: `<div
    class="atlas-input-shell"
    [class.is-invalid]="invalid()"
    [class.is-readonly]="readonly()"
  >
    @if (prefix()) {
      <span class="atlas-input-addon">{{ prefix() }}</span>
    }
    <input
      type="number"
      [id]="controlId()"
      [value]="value() ?? ''"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [min]="min()"
      [max]="max()"
      [step]="step()"
      [placeholder]="placeholder()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid()"
      (input)="edit($any($event.target).value)"
      (blur)="markTouched()"
    />
    @if (suffix()) {
      <span class="atlas-input-addon">{{ suffix() }}</span>
    }
    @if (showButtons()) {
      <div class="atlas-number-buttons">
        <button
          type="button"
          [disabled]="
            disabled() ||
            readonly() ||
            (value() !== null && max() !== null && value()! >= max()!)
          "
          aria-label="Increase value"
          (click)="increment(1)"
        >
          +</button
        ><button
          type="button"
          [disabled]="
            disabled() ||
            readonly() ||
            (value() !== null && min() !== null && value()! <= min()!)
          "
          aria-label="Decrease value"
          (click)="increment(-1)"
        >
          −
        </button>
      </div>
    }
  </div>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasNumberInput, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-number-input",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => AtlasNumberInput),
                            multi: true,
                        },
                    ],
                    host: { class: "atlas-control", "[class.is-disabled]": "disabled()" },
                    template: `<div
    class="atlas-input-shell"
    [class.is-invalid]="invalid()"
    [class.is-readonly]="readonly()"
  >
    @if (prefix()) {
      <span class="atlas-input-addon">{{ prefix() }}</span>
    }
    <input
      type="number"
      [id]="controlId()"
      [value]="value() ?? ''"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [min]="min()"
      [max]="max()"
      [step]="step()"
      [placeholder]="placeholder()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid()"
      (input)="edit($any($event.target).value)"
      (blur)="markTouched()"
    />
    @if (suffix()) {
      <span class="atlas-input-addon">{{ suffix() }}</span>
    }
    @if (showButtons()) {
      <div class="atlas-number-buttons">
        <button
          type="button"
          [disabled]="
            disabled() ||
            readonly() ||
            (value() !== null && max() !== null && value()! >= max()!)
          "
          aria-label="Increase value"
          (click)="increment(1)"
        >
          +</button
        ><button
          type="button"
          [disabled]="
            disabled() ||
            readonly() ||
            (value() !== null && min() !== null && value()! <= min()!)
          "
          aria-label="Decrease value"
          (click)="increment(-1)"
        >
          −
        </button>
      </div>
    }
  </div>`,
                }]
        }], propDecorators: { min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], showButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "showButtons", required: false }] }] } });

class AtlasSelect extends AtlasValueControl {
    options = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    filter = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []));
    clearable = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearable" }] : /* istanbul ignore next */ []));
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    query = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    opened = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    activeIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    selected = computed(() => this.options().find((option) => Object.is(option.value, this.value())), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    filtered = computed(() => filterCollection(this.options(), this.query(), (option) => `${option.label} ${option.description ?? ""} ${option.group ?? ""}`), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []));
    trigger = viewChild.required("trigger", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    popup = viewChild.required("popup", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "popup" }] : /* istanbul ignore next */ []));
    search = viewChild("search", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    onScroll = (event) => {
        if (!this.popup().nativeElement.contains(event.target))
            this.close(false);
    };
    toggle() {
        this.opened() ? this.close(true) : this.open();
    }
    open() {
        if (this.disabled() || this.readonly() || this.loading())
            return;
        this.query.set("");
        const index = this.options().findIndex((option) => Object.is(option.value, this.value()) && !option.disabled);
        this.activeIndex.set(index >= 0
            ? index
            : this.options().findIndex((option) => !option.disabled));
        const popup = this.popup().nativeElement;
        const rect = this.trigger().nativeElement.getBoundingClientRect();
        const win = popup.ownerDocument.defaultView;
        const below = win.innerHeight - rect.bottom - 10, above = rect.top - 10;
        const opensBelow = below >= Math.min(310, above);
        const height = Math.min(310, opensBelow ? below : above);
        Object.assign(popup.style, {
            left: `${Math.max(8, Math.min(rect.left, win.innerWidth - Math.min(rect.width, win.innerWidth - 16) - 8))}px`,
            top: opensBelow ? `${rect.bottom + 5}px` : "auto",
            bottom: opensBelow ? "auto" : `${win.innerHeight - rect.top + 5}px`,
            width: `${Math.min(rect.width, win.innerWidth - 16)}px`,
            maxHeight: `${height}px`,
        });
        popup.showPopover();
        this.opened.set(true);
        popup.ownerDocument.addEventListener("scroll", this.onScroll, true);
        queueMicrotask(() => {
            if (this.opened())
                this.search()?.nativeElement.focus();
        });
    }
    close(focus) {
        if (!this.opened())
            return;
        this.popup().nativeElement.hidePopover();
        this.opened.set(false);
        this.markTouched();
        this.popup().nativeElement.ownerDocument.removeEventListener("scroll", this.onScroll, true);
        if (focus)
            this.trigger().nativeElement.focus();
    }
    toggled(event) {
        const open = event.newState === "open";
        this.opened.set(open);
        if (!open) {
            this.markTouched();
            this.popup().nativeElement.ownerDocument.removeEventListener("scroll", this.onScroll, true);
        }
    }
    blur() {
        if (!this.opened())
            this.markTouched();
    }
    clear() {
        this.commit(null);
        this.markTouched();
        this.trigger().nativeElement.focus();
    }
    choose(option) {
        if (option.disabled)
            return;
        this.commit(option.value);
        this.close(true);
    }
    hover(index) {
        if (!this.filtered()[index]?.disabled)
            this.activeIndex.set(index);
    }
    searchFor(query) {
        this.query.set(query);
        this.activeIndex.set(this.filtered().findIndex((option) => !option.disabled));
    }
    key(event) {
        if (this.disabled() || this.readonly())
            return;
        if (event.key === "Escape") {
            if (this.opened()) {
                event.preventDefault();
                event.stopPropagation();
                this.close(true);
            }
            return;
        }
        if (event.key === "Tab") {
            this.close(false);
            return;
        }
        if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
            event.preventDefault();
            if (!this.opened()) {
                this.open();
                return;
            }
            const indices = this.filtered()
                .map((option, i) => (option.disabled ? -1 : i))
                .filter((i) => i >= 0);
            if (!indices.length)
                return;
            const current = indices.indexOf(this.activeIndex());
            const index = event.key === "Home"
                ? indices[0]
                : event.key === "End"
                    ? indices.at(-1)
                    : indices[(current +
                        (event.key === "ArrowDown" ? 1 : -1) +
                        indices.length) %
                        indices.length];
            this.activeIndex.set(index);
            this.popup()
                .nativeElement.querySelector(`[id="${this.controlId()}-option-${index}"]`)
                ?.scrollIntoView({ block: "nearest" });
            return;
        }
        if (event.key === "Enter" ||
            (event.key === " " && event.target === this.trigger().nativeElement)) {
            event.preventDefault();
            if (!this.opened()) {
                this.open();
                return;
            }
            const option = this.filtered()[this.activeIndex()];
            if (option)
                this.choose(option);
        }
    }
    setDisabledState(disabled) {
        super.setDisabledState(disabled);
        if (disabled && this.opened())
            this.close(false);
    }
    ngOnDestroy() {
        this.popup().nativeElement.ownerDocument.removeEventListener("scroll", this.onScroll, true);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSelect, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasSelect, isStandalone: true, selector: "atlas-select", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "window:resize": "close(false)" }, properties: { "class.is-disabled": "disabled()" }, classAttribute: "atlas-control" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => AtlasSelect),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }, { propertyName: "popup", first: true, predicate: ["popup"], descendants: true, isSignal: true }, { propertyName: "search", first: true, predicate: ["search"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `<div
      class="atlas-select-shell"
      [class.is-invalid]="invalid()"
      [class.is-readonly]="readonly()"
    >
      <button
        #trigger
        type="button"
        class="atlas-select-trigger"
        role="combobox"
        [id]="controlId()"
        [disabled]="disabled()"
        [attr.aria-label]="ariaLabel()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-expanded]="opened()"
        aria-haspopup="listbox"
        [attr.aria-controls]="controlId() + '-list'"
        [attr.aria-activedescendant]="
          opened() && activeIndex() >= 0
            ? controlId() + '-option-' + activeIndex()
            : null
        "
        [attr.aria-invalid]="invalid()"
        [attr.aria-readonly]="readonly()"
        (click)="toggle()"
        (keydown)="key($event)"
        (blur)="blur()"
      >
        <span [class.atlas-placeholder]="!selected()">{{
          selected()?.label || placeholder() || "Choose an option"
        }}</span>
        <atlas-icon [name]="loading() ? 'refresh' : 'down'" />
      </button>
      @if (clearable() && selected() && !readonly() && !disabled()) {
        <button
          type="button"
          class="atlas-select-clear atlas-control-action"
          [attr.aria-label]="'Clear ' + (ariaLabel() || 'selection')"
          (click)="clear()"
        >
          <atlas-icon name="close" />
        </button>
      }
    </div>
    <div
      #popup
      popover="auto"
      class="atlas-select-popover"
      (toggle)="toggled($event)"
      (keydown)="key($event)"
    >
      @if (filter()) {
        <div class="atlas-select-search">
          <atlas-icon name="search" /><input
            #search
            type="search"
            [attr.aria-label]="'Filter ' + (ariaLabel() || 'options')"
            [value]="query()"
            placeholder="Search options…"
            [attr.aria-controls]="controlId() + '-list'"
            [attr.aria-activedescendant]="
              activeIndex() >= 0
                ? controlId() + '-option-' + activeIndex()
                : null
            "
            (input)="searchFor($any($event.target).value)"
          />
        </div>
      }
      <div
        class="atlas-select-options"
        role="listbox"
        [id]="controlId() + '-list'"
        [attr.aria-label]="ariaLabel() || 'Options'"
      >
        @if (loading()) {
          <div class="atlas-options-empty" role="status">Loading options…</div>
        } @else {
          @for (option of filtered(); track option.value; let i = $index) {
            @if (
              option.group &&
              (i === 0 || filtered()[i - 1].group !== option.group)
            ) {
              <div class="atlas-option-group">{{ option.group }}</div>
            }
            <button
              type="button"
              role="option"
              tabindex="-1"
              class="atlas-select-option"
              [id]="controlId() + '-option-' + i"
              [class.is-active]="i === activeIndex()"
              [disabled]="option.disabled"
              [attr.aria-disabled]="!!option.disabled"
              [attr.aria-selected]="value() === option.value"
              (pointermove)="hover(i)"
              (click)="choose(option)"
            >
              <span
                ><strong>{{ option.label }}</strong>
                @if (option.description) {
                  <small>{{ option.description }}</small>
                }
              </span>
              @if (value() === option.value) {
                <atlas-icon name="check" />
              }
            </button>
          } @empty {
            <div class="atlas-options-empty">No matching options.</div>
          }
        }
      </div>
      <div class="atlas-select-help">
        <span>↑ ↓ navigate</span><span>Enter to select</span>
      </div>
    </div>`, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSelect, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-select",
                    imports: [AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => AtlasSelect),
                            multi: true,
                        },
                    ],
                    host: {
                        class: "atlas-control",
                        "[class.is-disabled]": "disabled()",
                        "(window:resize)": "close(false)",
                    },
                    template: `<div
      class="atlas-select-shell"
      [class.is-invalid]="invalid()"
      [class.is-readonly]="readonly()"
    >
      <button
        #trigger
        type="button"
        class="atlas-select-trigger"
        role="combobox"
        [id]="controlId()"
        [disabled]="disabled()"
        [attr.aria-label]="ariaLabel()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-expanded]="opened()"
        aria-haspopup="listbox"
        [attr.aria-controls]="controlId() + '-list'"
        [attr.aria-activedescendant]="
          opened() && activeIndex() >= 0
            ? controlId() + '-option-' + activeIndex()
            : null
        "
        [attr.aria-invalid]="invalid()"
        [attr.aria-readonly]="readonly()"
        (click)="toggle()"
        (keydown)="key($event)"
        (blur)="blur()"
      >
        <span [class.atlas-placeholder]="!selected()">{{
          selected()?.label || placeholder() || "Choose an option"
        }}</span>
        <atlas-icon [name]="loading() ? 'refresh' : 'down'" />
      </button>
      @if (clearable() && selected() && !readonly() && !disabled()) {
        <button
          type="button"
          class="atlas-select-clear atlas-control-action"
          [attr.aria-label]="'Clear ' + (ariaLabel() || 'selection')"
          (click)="clear()"
        >
          <atlas-icon name="close" />
        </button>
      }
    </div>
    <div
      #popup
      popover="auto"
      class="atlas-select-popover"
      (toggle)="toggled($event)"
      (keydown)="key($event)"
    >
      @if (filter()) {
        <div class="atlas-select-search">
          <atlas-icon name="search" /><input
            #search
            type="search"
            [attr.aria-label]="'Filter ' + (ariaLabel() || 'options')"
            [value]="query()"
            placeholder="Search options…"
            [attr.aria-controls]="controlId() + '-list'"
            [attr.aria-activedescendant]="
              activeIndex() >= 0
                ? controlId() + '-option-' + activeIndex()
                : null
            "
            (input)="searchFor($any($event.target).value)"
          />
        </div>
      }
      <div
        class="atlas-select-options"
        role="listbox"
        [id]="controlId() + '-list'"
        [attr.aria-label]="ariaLabel() || 'Options'"
      >
        @if (loading()) {
          <div class="atlas-options-empty" role="status">Loading options…</div>
        } @else {
          @for (option of filtered(); track option.value; let i = $index) {
            @if (
              option.group &&
              (i === 0 || filtered()[i - 1].group !== option.group)
            ) {
              <div class="atlas-option-group">{{ option.group }}</div>
            }
            <button
              type="button"
              role="option"
              tabindex="-1"
              class="atlas-select-option"
              [id]="controlId() + '-option-' + i"
              [class.is-active]="i === activeIndex()"
              [disabled]="option.disabled"
              [attr.aria-disabled]="!!option.disabled"
              [attr.aria-selected]="value() === option.value"
              (pointermove)="hover(i)"
              (click)="choose(option)"
            >
              <span
                ><strong>{{ option.label }}</strong>
                @if (option.description) {
                  <small>{{ option.description }}</small>
                }
              </span>
              @if (value() === option.value) {
                <atlas-icon name="check" />
              }
            </button>
          } @empty {
            <div class="atlas-options-empty">No matching options.</div>
          }
        }
      </div>
      <div class="atlas-select-help">
        <span>↑ ↓ navigate</span><span>Enter to select</span>
      </div>
    </div>`,
                }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], trigger: [{ type: i0.ViewChild, args: ["trigger", { isSignal: true }] }], popup: [{ type: i0.ViewChild, args: ["popup", { isSignal: true }] }], search: [{ type: i0.ViewChild, args: ["search", { isSignal: true }] }] } });

class AtlasListTemplate {
    template = inject(TemplateRef);
    static ngTemplateContextGuard(_directive, context) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasListTemplate, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.7", type: AtlasListTemplate, isStandalone: true, selector: "ng-template[atlasListTemplate]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasListTemplate, decorators: [{
            type: Directive,
            args: [{ selector: "ng-template[atlasListTemplate]" }]
        }] });
class AtlasListView {
    itemTemplate = contentChild(AtlasListTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    tabstop = computed(() => this.paged().items.find((item) => item.id === this.focusId() && !item.disabled)?.id ?? this.paged().items.find((item) => !item.disabled)?.id, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabstop" }] : /* istanbul ignore next */ []));
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    label = input("Records", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    layout = input("list", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    filterable = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterable" }] : /* istanbul ignore next */ []));
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    pageSize = input(5, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
    selectedId = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedId" }] : /* istanbul ignore next */ []));
    selectionChange = output();
    itemActivated = output();
    query = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    page = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []));
    focusId = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusId" }] : /* istanbul ignore next */ []));
    filtered = computed(() => filterCollection(this.items(), this.query(), (item) => `${item.title} ${item.description ?? ""} ${item.meta ?? ""}`), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []));
    paged = computed(() => pageCollection(this.filtered(), this.page(), this.pageSize()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paged" }] : /* istanbul ignore next */ []));
    firstEnabled = computed(() => this.paged().items.findIndex((item) => !item.disabled), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "firstEnabled" }] : /* istanbul ignore next */ []));
    search(query) {
        this.query.set(query);
        this.page.set(0);
        this.focusId.set(null);
    }
    changePage(delta) {
        this.page.set(this.paged().page + delta);
        this.focusId.set(null);
    }
    select(item) {
        if (item.disabled)
            return;
        this.selectedId.set(item.id);
        this.focusId.set(item.id);
        this.selectionChange.emit(item);
    }
    key(event, item) {
        if (event.key === "Enter") {
            event.preventDefault();
            this.select(item);
            this.itemActivated.emit(item);
            return;
        }
        if (![
            "ArrowDown",
            "ArrowUp",
            "ArrowLeft",
            "ArrowRight",
            "Home",
            "End",
        ].includes(event.key))
            return;
        event.preventDefault();
        const items = this.paged().items.filter((item) => !item.disabled);
        const current = items.findIndex((value) => value.id === item.id);
        const index = event.key === "Home"
            ? 0
            : event.key === "End"
                ? items.length - 1
                : (current +
                    (["ArrowDown", "ArrowRight"].includes(event.key) ? 1 : -1) +
                    items.length) %
                    items.length;
        const next = items[index];
        if (next) {
            this.select(next);
            const host = event.currentTarget.parentElement;
            const buttons = [
                ...host.querySelectorAll('button[role="option"]:not(:disabled)'),
            ];
            buttons[index]?.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasListView, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasListView, isStandalone: true, selector: "atlas-list-view", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedId: "selectedIdChange", selectionChange: "selectionChange", itemActivated: "itemActivated" }, host: { classAttribute: "atlas-list-view" }, queries: [{ propertyName: "itemTemplate", first: true, predicate: AtlasListTemplate, descendants: true, isSignal: true }], ngImport: i0, template: `@if (filterable()) {
      <div class="atlas-collection-toolbar">
        <div class="atlas-collection-search">
          <atlas-icon name="search" /><input
            atlasInput
            [attr.aria-label]="'Search ' + label()"
            placeholder="Search records…"
            [value]="query()"
            (input)="search($any($event.target).value)"
          />
        </div>
        <span class="atlas-collection-count"
          >{{ filtered().length }}
          {{ filtered().length === 1 ? "record" : "records" }}</span
        >
      </div>
    }
    <div
      class="atlas-list-items"
      [class.is-grid]="layout() === 'grid'"
      role="listbox"
      [attr.aria-label]="label()"
      [attr.aria-busy]="loading()"
    >
      @if (loading()) {
        <div class="atlas-options-empty" role="status">Loading records…</div>
      } @else {
        @for (item of paged().items; track item.id; let i = $index) {
          <button
            type="button"
            class="atlas-list-item"
            role="option"
            [attr.aria-selected]="selectedId() === item.id"
            [disabled]="item.disabled"
            [attr.aria-disabled]="!!item.disabled"
            [class.is-selected]="selectedId() === item.id"
            [attr.tabindex]="tabstop() === item.id ? 0 : -1"
            (click)="select(item)"
            (dblclick)="itemActivated.emit(item)"
            (keydown)="key($event, item)"
          >
            @if (itemTemplate(); as custom) {
              <ng-container
                [ngTemplateOutlet]="custom.template"
                [ngTemplateOutletContext]="{
                  $implicit: item,
                  selected: selectedId() === item.id,
                }"
              />
            } @else {
              <span class="atlas-list-item-icon"
                ><atlas-icon [name]="item.icon || 'box'" /></span
              ><span class="atlas-list-item-content"
                ><strong>{{ item.title }}</strong>
                @if (item.description) {
                  <small>{{ item.description }}</small>
                }
                @if (item.meta) {
                  <span class="atlas-list-meta">{{ item.meta }}</span>
                }
              </span>
              @if (item.badge) {
                <atlas-badge [tone]="item.tone || 'neutral'">{{
                  item.badge
                }}</atlas-badge>
              }
            }
            @if (selectedId() === item.id) {
              <atlas-icon class="atlas-list-check" name="check" />
            }
          </button>
        } @empty {
          <div class="atlas-options-empty">No records match your search.</div>
        }
      }
    </div>
    <footer class="atlas-table-footer">
      <span
        >{{ selectedId() ? "1 selected" : "Select a record" }} · Page
        {{ paged().page + 1 }} of {{ paged().pages }}</span
      >
      <div>
        <button
          type="button"
          class="atlas-window-control"
          aria-label="Previous list page"
          [disabled]="paged().page === 0"
          (click)="changePage(-1)"
        >
          <atlas-icon name="back" /></button
        ><button
          type="button"
          class="atlas-window-control"
          aria-label="Next list page"
          [disabled]="paged().page + 1 === paged().pages"
          (click)="changePage(1)"
        >
          <atlas-icon name="arrow" />
        </button>
      </div>
    </footer>`, isInline: true, dependencies: [{ kind: "component", type: AtlasBadge, selector: "atlas-badge", inputs: ["tone"] }, { kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasListView, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-list-view",
                    imports: [AtlasBadge, AtlasIcon, AtlasInput, NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-list-view" },
                    template: `@if (filterable()) {
      <div class="atlas-collection-toolbar">
        <div class="atlas-collection-search">
          <atlas-icon name="search" /><input
            atlasInput
            [attr.aria-label]="'Search ' + label()"
            placeholder="Search records…"
            [value]="query()"
            (input)="search($any($event.target).value)"
          />
        </div>
        <span class="atlas-collection-count"
          >{{ filtered().length }}
          {{ filtered().length === 1 ? "record" : "records" }}</span
        >
      </div>
    }
    <div
      class="atlas-list-items"
      [class.is-grid]="layout() === 'grid'"
      role="listbox"
      [attr.aria-label]="label()"
      [attr.aria-busy]="loading()"
    >
      @if (loading()) {
        <div class="atlas-options-empty" role="status">Loading records…</div>
      } @else {
        @for (item of paged().items; track item.id; let i = $index) {
          <button
            type="button"
            class="atlas-list-item"
            role="option"
            [attr.aria-selected]="selectedId() === item.id"
            [disabled]="item.disabled"
            [attr.aria-disabled]="!!item.disabled"
            [class.is-selected]="selectedId() === item.id"
            [attr.tabindex]="tabstop() === item.id ? 0 : -1"
            (click)="select(item)"
            (dblclick)="itemActivated.emit(item)"
            (keydown)="key($event, item)"
          >
            @if (itemTemplate(); as custom) {
              <ng-container
                [ngTemplateOutlet]="custom.template"
                [ngTemplateOutletContext]="{
                  $implicit: item,
                  selected: selectedId() === item.id,
                }"
              />
            } @else {
              <span class="atlas-list-item-icon"
                ><atlas-icon [name]="item.icon || 'box'" /></span
              ><span class="atlas-list-item-content"
                ><strong>{{ item.title }}</strong>
                @if (item.description) {
                  <small>{{ item.description }}</small>
                }
                @if (item.meta) {
                  <span class="atlas-list-meta">{{ item.meta }}</span>
                }
              </span>
              @if (item.badge) {
                <atlas-badge [tone]="item.tone || 'neutral'">{{
                  item.badge
                }}</atlas-badge>
              }
            }
            @if (selectedId() === item.id) {
              <atlas-icon class="atlas-list-check" name="check" />
            }
          </button>
        } @empty {
          <div class="atlas-options-empty">No records match your search.</div>
        }
      }
    </div>
    <footer class="atlas-table-footer">
      <span
        >{{ selectedId() ? "1 selected" : "Select a record" }} · Page
        {{ paged().page + 1 }} of {{ paged().pages }}</span
      >
      <div>
        <button
          type="button"
          class="atlas-window-control"
          aria-label="Previous list page"
          [disabled]="paged().page === 0"
          (click)="changePage(-1)"
        >
          <atlas-icon name="back" /></button
        ><button
          type="button"
          class="atlas-window-control"
          aria-label="Next list page"
          [disabled]="paged().page + 1 === paged().pages"
          (click)="changePage(1)"
        >
          <atlas-icon name="arrow" />
        </button>
      </div>
    </footer>`,
                }]
        }], propDecorators: { itemTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => AtlasListTemplate), { isSignal: true }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], selectedId: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedId", required: false }] }, { type: i0.Output, args: ["selectedIdChange"] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], itemActivated: [{ type: i0.Output, args: ["itemActivated"] }] } });

class AtlasStartMenu {
    label = input("Start", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    accountName = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accountName" }] : /* istanbul ignore next */ []));
    accountSelected = output();
    openAccount() { this.close(); this.accountSelected.emit(); }
    accountActions = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accountActions" }] : /* istanbul ignore next */ []));
    accountActionSelected = output();
    chooseAccount(id) {
        if (!this.accountActions().some(item => item.id === id && !item.disabled))
            return;
        this.close();
        this.accountActionSelected.emit(id);
    }
    menuId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "menuId" }] : /* istanbul ignore next */ []));
    items = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    itemSelected = output();
    opened = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    trigger = viewChild.required("trigger", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    popup = viewChild.required("popup", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "popup" }] : /* istanbul ignore next */ []));
    toggle() {
        this.opened() ? this.close() : this.open();
    }
    open(last = false) {
        const popup = this.popup().nativeElement;
        const rect = this.trigger().nativeElement.getBoundingClientRect();
        const win = popup.ownerDocument.defaultView;
        const workspace = this.trigger()
            .nativeElement.closest(".atlas-workspace")
            ?.getBoundingClientRect();
        const left = workspace ? workspace.left + 8 : 4;
        const right = workspace ? workspace.right - 8 : win.innerWidth - 4;
        const width = Math.min(280, right - left);
        popup.style.width = `${width}px`;
        popup.style.left = `${Math.max(left, Math.min(rect.left, right - width))}px`;
        const top = workspace?.top ?? 0;
        const bottom = workspace?.bottom ?? win.innerHeight;
        const below = bottom - rect.bottom - 8;
        const above = rect.top - top - 8;
        const down = below > above;
        popup.style.top = down ? `${rect.bottom + 3}px` : 'auto';
        popup.style.bottom = down ? 'auto' : `${win.innerHeight - rect.top + 3}px`;
        popup.style.maxHeight = `${Math.max(0, down ? below : above)}px`;
        popup.showPopover();
        this.opened.set(true);
        const buttons = popup.querySelectorAll('[role="menuitem"]:not(:disabled)');
        buttons[last ? buttons.length - 1 : 0]?.focus();
    }
    close() {
        this.popup().nativeElement.hidePopover();
        this.opened.set(false);
        this.trigger().nativeElement.focus();
    }
    choose(id) {
        if (!this.items().some(item => item.id === id && !item.disabled))
            return;
        this.close();
        this.itemSelected.emit(id);
    }
    key(event) {
        if (event.key === "Escape" || event.key === "Tab") {
            if (event.key === "Escape") {
                event.preventDefault();
                event.stopPropagation();
            }
            this.close();
            return;
        }
        if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key))
            return;
        event.preventDefault();
        const popup = this.popup().nativeElement;
        const buttons = Array.from(popup.querySelectorAll('[role="menuitem"]:not(:disabled)'));
        const current = buttons.indexOf(popup.ownerDocument.activeElement);
        const next = event.key === "Home"
            ? 0
            : event.key === "End"
                ? buttons.length - 1
                : (current + (event.key === "ArrowDown" ? 1 : -1) + buttons.length) %
                    buttons.length;
        buttons[next]?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasStartMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasStartMenu, isStandalone: true, selector: "atlas-start-menu", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, accountName: { classPropertyName: "accountName", publicName: "accountName", isSignal: true, isRequired: false, transformFunction: null }, accountActions: { classPropertyName: "accountActions", publicName: "accountActions", isSignal: true, isRequired: false, transformFunction: null }, menuId: { classPropertyName: "menuId", publicName: "menuId", isSignal: true, isRequired: true, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { accountSelected: "accountSelected", accountActionSelected: "accountActionSelected", itemSelected: "itemSelected" }, host: { listeners: { "window:resize": "opened() && close()" } }, viewQueries: [{ propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }, { propertyName: "popup", first: true, predicate: ["popup"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <button
      #trigger
      class="atlas-start-button"
      aria-haspopup="menu"
      [attr.aria-expanded]="opened()"
      [attr.aria-controls]="menuId()"
      (click)="toggle()"
      (keydown.arrowdown)="$event.preventDefault(); open()"
      (keydown.arrowup)="$event.preventDefault(); open(true)"
    >
      <atlas-icon name="grid" />
      <strong>{{ label() }}</strong>
    </button>
    <div
      #popup
      [id]="menuId()"
      popover="auto"
      class="atlas-start-popup"
      (toggle)="opened.set($any($event).newState === 'open')"
      (keydown)="key($event)"
    >
      <div class="atlas-start-heading">
        <strong>{{ label() }}</strong><span>Applications & tools</span>
      </div>
      <div class="atlas-start-items" role="menu" aria-label="Start menu">
        @for (item of items(); track item.id) {
          @if (item.separatorBefore) {
            <div role="separator" class="atlas-start-separator"></div>
          }
          <button role="menuitem" tabindex="-1" [disabled]="item.disabled" (click)="choose(item.id)">
            <atlas-icon [name]="item.icon" /><span>{{ item.label }}</span>
          </button>
        }
      </div>
      @if (accountName()) {
        <section class="atlas-start-account" aria-label="Account">
          <div role="menu" aria-label="User account"><button class="atlas-start-profile" role="menuitem" tabindex="-1" (click)="openAccount()">
            <span class="atlas-start-avatar" aria-hidden="true">{{ accountName().trim().slice(0, 1).toUpperCase() }}</span>
            <span class="atlas-start-identity"><strong>{{ accountName() }}</strong><span>My account</span></span>
          </button></div>
          <div class="atlas-start-items" role="menu" aria-label="Account options">
            @for (item of accountActions(); track item.id) {
              <button role="menuitem" tabindex="-1" [disabled]="item.disabled" (click)="chooseAccount(item.id)">
                <atlas-icon [name]="item.icon" /><span>{{ item.label }}</span>
              </button>
            }
          </div>
        </section>
      }
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasStartMenu, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-start-menu",
                    imports: [AtlasIcon],
                    host: { "(window:resize)": "opened() && close()" },
                    template: `
    <button
      #trigger
      class="atlas-start-button"
      aria-haspopup="menu"
      [attr.aria-expanded]="opened()"
      [attr.aria-controls]="menuId()"
      (click)="toggle()"
      (keydown.arrowdown)="$event.preventDefault(); open()"
      (keydown.arrowup)="$event.preventDefault(); open(true)"
    >
      <atlas-icon name="grid" />
      <strong>{{ label() }}</strong>
    </button>
    <div
      #popup
      [id]="menuId()"
      popover="auto"
      class="atlas-start-popup"
      (toggle)="opened.set($any($event).newState === 'open')"
      (keydown)="key($event)"
    >
      <div class="atlas-start-heading">
        <strong>{{ label() }}</strong><span>Applications & tools</span>
      </div>
      <div class="atlas-start-items" role="menu" aria-label="Start menu">
        @for (item of items(); track item.id) {
          @if (item.separatorBefore) {
            <div role="separator" class="atlas-start-separator"></div>
          }
          <button role="menuitem" tabindex="-1" [disabled]="item.disabled" (click)="choose(item.id)">
            <atlas-icon [name]="item.icon" /><span>{{ item.label }}</span>
          </button>
        }
      </div>
      @if (accountName()) {
        <section class="atlas-start-account" aria-label="Account">
          <div role="menu" aria-label="User account"><button class="atlas-start-profile" role="menuitem" tabindex="-1" (click)="openAccount()">
            <span class="atlas-start-avatar" aria-hidden="true">{{ accountName().trim().slice(0, 1).toUpperCase() }}</span>
            <span class="atlas-start-identity"><strong>{{ accountName() }}</strong><span>My account</span></span>
          </button></div>
          <div class="atlas-start-items" role="menu" aria-label="Account options">
            @for (item of accountActions(); track item.id) {
              <button role="menuitem" tabindex="-1" [disabled]="item.disabled" (click)="chooseAccount(item.id)">
                <atlas-icon [name]="item.icon" /><span>{{ item.label }}</span>
              </button>
            }
          </div>
        </section>
      }
    </div>
  `,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], accountName: [{ type: i0.Input, args: [{ isSignal: true, alias: "accountName", required: false }] }], accountSelected: [{ type: i0.Output, args: ["accountSelected"] }], accountActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "accountActions", required: false }] }], accountActionSelected: [{ type: i0.Output, args: ["accountActionSelected"] }], menuId: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuId", required: true }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], itemSelected: [{ type: i0.Output, args: ["itemSelected"] }], trigger: [{ type: i0.ViewChild, args: ["trigger", { isSignal: true }] }], popup: [{ type: i0.ViewChild, args: ["popup", { isSignal: true }] }] } });

function lookupCell(row, column) {
    return column.format ? column.format(row) : String(row[column.key] ?? "");
}
function filterLookup(rows, columns, query) {
    return filterCollection(rows, query, (row) => columns
        .filter((c) => c.searchable !== false)
        .map((c) => lookupCell(row, c))
        .join(" "));
}
function nextLookupIndex(rows, current, key, disabled) {
    const enabled = rows
        .map((row, i) => (disabled(row) ? -1 : i))
        .filter((i) => i >= 0);
    if (!enabled.length)
        return -1;
    if (key === "Home")
        return enabled[0];
    if (key === "End")
        return enabled.at(-1);
    const index = enabled.indexOf(current);
    if (index < 0)
        return key === "ArrowUp" ? enabled.at(-1) : enabled[0];
    return enabled[(index + (key === "ArrowUp" ? -1 : 1) + enabled.length) % enabled.length];
}

/** A record picker: commit a stable key while displaying a human-readable record label. */
class AtlasLookup {
    actions = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []));
    action = output();
    runAction(id) { const query = this.query(); this.close(false); this.action.emit({ id, query }); }
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    ariaLabel = input("Record", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    rows = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    columns = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    recordKey = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "recordKey" }] : /* istanbul ignore next */ []));
    displayWith = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayWith" }] : /* istanbul ignore next */ []));
    rowDisabled = input(() => false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowDisabled" }] : /* istanbul ignore next */ []));
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    touched = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    required = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []));
    clearable = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearable" }] : /* istanbul ignore next */ []));
    arrowNavigation = input("open", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "arrowNavigation" }] : /* istanbul ignore next */ []));
    placeholder = input("Choose a record", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    error = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    popupWidth = input(640, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "popupWidth" }] : /* istanbul ignore next */ []));
    touch = output();
    recordSelected = output();
    retry = output();
    remote = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "remote" }] : /* istanbul ignore next */ []));
    selectedText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedText" }] : /* istanbul ignore next */ []));
    page = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []));
    total = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []));
    pageSize = input(20, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
    queryChange = output();
    pageChange = output();
    opened = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    query = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    activeIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    filtered = computed(() => this.remote() ? [...this.rows()] : filterLookup(this.rows(), this.columns(), this.query()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []));
    selected = computed(() => this.rows().find((row) => this.isSelected(row)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    selectedLabel = computed(() => {
        const selected = this.selected();
        return selected
            ? this.displayWith()(selected)
            : this.value() === null
                ? this.placeholder()
                : this.selectedText() || `Unavailable record (${this.value()})`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedLabel" }] : /* istanbul ignore next */ []));
    activeId = computed(() => !this.loading() && !this.error() && this.filtered()[this.activeIndex()]
        ? `${this.controlId()}-row-${this.activeIndex()}`
        : null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []));
    columnWidths = computed(() => this.columns()
        .map((column) => column.width ? `${Math.max(40, column.width)}px` : "minmax(130px, 1fr)")
        .join(" "), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnWidths" }] : /* istanbul ignore next */ []));
    cell = lookupCell;
    trigger = viewChild.required("trigger", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    popup = viewChild.required("popup", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "popup" }] : /* istanbul ignore next */ []));
    search = viewChild.required("search", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    retryButton = viewChild("retryButton", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "retryButton" }] : /* istanbul ignore next */ []));
    scroll = viewChild.required("scroll", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scroll" }] : /* istanbul ignore next */ []));
    onScroll = (event) => {
        if (!this.popup().nativeElement.contains(event.target))
            this.close(false);
    };
    constructor() {
        effect(() => {
            if ((this.disabled() || this.readonly()) && this.opened())
                this.close(false);
        });
        effect(() => {
            const rows = this.filtered();
            this.activeIndex.set(nextLookupIndex(rows, -1, "Home", this.rowDisabled()));
        });
    }
    isSelected(row) {
        return Object.is(this.recordKey()(row), this.value());
    }
    focus(options) {
        this.trigger().nativeElement.focus(options);
    }
    open() {
        if (this.disabled() || this.readonly())
            return;
        if (this.opened()) {
            this.close(true);
            return;
        }
        this.query.set("");
        if (this.remote())
            this.queryChange.emit("");
        const selected = this.rows().findIndex((row) => this.isSelected(row) && !this.rowDisabled()(row));
        this.activeIndex.set(selected >= 0
            ? selected
            : nextLookupIndex(this.rows(), -1, "Home", this.rowDisabled()));
        const popup = this.popup().nativeElement;
        const rect = this.trigger().nativeElement.getBoundingClientRect();
        const win = popup.ownerDocument.defaultView;
        const mobile = this.trigger()
            .nativeElement.closest(".mobile-workspace")
            ?.getBoundingClientRect();
        const bounds = mobile ?? {
            left: 0,
            top: 0,
            right: win.innerWidth,
            bottom: win.innerHeight,
            width: win.innerWidth,
            height: win.innerHeight,
        };
        const width = Math.min(Math.max(rect.width, this.popupWidth()), bounds.width - 16);
        const below = bounds.bottom - rect.bottom - 12, above = rect.top - bounds.top - 12;
        const down = below >= Math.min(380, above);
        Object.assign(popup.style, {
            left: `${Math.max(bounds.left + 8, Math.min(rect.left, bounds.right - width - 8))}px`,
            width: `${width}px`,
            top: mobile
                ? `${bounds.top + 8}px`
                : down
                    ? `${rect.bottom + 5}px`
                    : "auto",
            bottom: mobile || down ? "auto" : `${win.innerHeight - rect.top + 5}px`,
            maxHeight: `${mobile ? Math.max(0, bounds.height - 16) : Math.max(0, Math.min(380, down ? below : above))}px`,
        });
        popup.showPopover();
        this.opened.set(true);
        this.search().nativeElement.focus({ preventScroll: true });
        popup.ownerDocument.addEventListener("scroll", this.onScroll, true);
    }
    close(restoreFocus) {
        if (!this.opened())
            return;
        this.popup().nativeElement.hidePopover();
        this.opened.set(false);
        this.detach();
        this.touch.emit();
        if (restoreFocus)
            this.focus({ preventScroll: true });
    }
    onToggle(event) {
        if (event.newState === "closed") {
            this.opened.set(false);
            this.detach();
            this.touch.emit();
        }
    }
    searchFor(query) {
        this.query.set(query);
        if (this.remote())
            this.queryChange.emit(query);
        this.activeIndex.set(nextLookupIndex(this.filtered(), -1, "Home", this.rowDisabled()));
    }
    highlight(index) {
        if (!this.rowDisabled()(this.filtered()[index]))
            this.activeIndex.set(index);
    }
    choose(row) {
        if (this.disabled() ||
            this.readonly() ||
            this.loading() ||
            this.error() ||
            this.rowDisabled()(row))
            return;
        this.value.set(this.recordKey()(row));
        this.recordSelected.emit(row);
        this.close(true);
    }
    clear() {
        if (this.disabled() || this.readonly())
            return;
        this.value.set(null);
        this.recordSelected.emit(null);
        this.touch.emit();
        this.focus();
    }
    retryLoad() {
        this.retry.emit();
        this.search().nativeElement.focus({ preventScroll: true });
    }
    triggerKey(event) {
        if (event.key === "F4" ||
            (event.altKey && event.key === "ArrowDown") ||
            (this.arrowNavigation() === "open" &&
                ["ArrowDown", "ArrowUp"].includes(event.key))) {
            event.preventDefault();
            event.stopPropagation();
            this.open();
        }
    }
    popupKey(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            this.close(true);
            return;
        }
        if (event.key === "Tab" && this.actions().length) {
            const controls = [...this.popup().nativeElement.querySelectorAll('input, button:not([disabled]):not([tabindex="-1"])')];
            const index = controls.indexOf(event.target);
            const next = index + (event.shiftKey ? -1 : 1);
            if (next >= 0 && next < controls.length) {
                event.preventDefault();
                controls[next].focus();
            }
            else
                this.close(true);
            return;
        }
        if (event.target.tagName === 'BUTTON')
            return;
        if (event.key === "Tab") {
            if (this.error() &&
                !event.shiftKey &&
                event.target === this.search().nativeElement) {
                event.preventDefault();
                this.retryButton()?.nativeElement.focus();
                return;
            }
            if (this.error() &&
                event.shiftKey &&
                event.target === this.retryButton()?.nativeElement) {
                event.preventDefault();
                this.search().nativeElement.focus();
                return;
            }
            this.close(true);
            return;
        }
        if (this.loading() || this.error())
            return;
        if (this.remote() && ['PageUp', 'PageDown'].includes(event.key)) {
            event.preventDefault();
            event.stopPropagation();
            const page = this.page() + (event.key === 'PageDown' ? 1 : -1);
            if (page >= 0 && page * this.pageSize() < this.total())
                this.pageChange.emit(page);
            return;
        }
        if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
            event.preventDefault();
            this.activeIndex.set(nextLookupIndex(this.filtered(), this.activeIndex(), event.key, this.rowDisabled()));
            // Scroll only the results container; scrolling ancestors would detach the overlay.
            const row = this.popup().nativeElement.querySelector(`[id="${this.controlId()}-row-${this.activeIndex()}"]`);
            if (row) {
                const scroll = this.scroll().nativeElement;
                const top = row.getBoundingClientRect().top -
                    scroll.getBoundingClientRect().top +
                    scroll.scrollTop;
                if (top < scroll.scrollTop + 36)
                    scroll.scrollTop = top - 36;
                else if (top + row.offsetHeight >
                    scroll.scrollTop + scroll.clientHeight)
                    scroll.scrollTop = top + row.offsetHeight - scroll.clientHeight;
            }
        }
        else if (event.key === "Enter" &&
            event.target === this.search().nativeElement) {
            event.preventDefault();
            const row = this.filtered()[this.activeIndex()];
            if (row)
                this.choose(row);
        }
    }
    detach() {
        this.popup().nativeElement.ownerDocument.removeEventListener("scroll", this.onScroll, true);
    }
    ngOnDestroy() {
        this.detach();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasLookup, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasLookup, isStandalone: true, selector: "atlas-lookup", inputs: { actions: { classPropertyName: "actions", publicName: "actions", isSignal: true, isRequired: false, transformFunction: null }, controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: true, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, recordKey: { classPropertyName: "recordKey", publicName: "recordKey", isSignal: true, isRequired: true, transformFunction: null }, displayWith: { classPropertyName: "displayWith", publicName: "displayWith", isSignal: true, isRequired: true, transformFunction: null }, rowDisabled: { classPropertyName: "rowDisabled", publicName: "rowDisabled", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, arrowNavigation: { classPropertyName: "arrowNavigation", publicName: "arrowNavigation", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, popupWidth: { classPropertyName: "popupWidth", publicName: "popupWidth", isSignal: true, isRequired: false, transformFunction: null }, remote: { classPropertyName: "remote", publicName: "remote", isSignal: true, isRequired: false, transformFunction: null }, selectedText: { classPropertyName: "selectedText", publicName: "selectedText", isSignal: true, isRequired: false, transformFunction: null }, page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { action: "action", value: "valueChange", touch: "touch", recordSelected: "recordSelected", retry: "retry", queryChange: "queryChange", pageChange: "pageChange" }, host: { listeners: { "window:resize": "close(false)" }, classAttribute: "atlas-control" }, viewQueries: [{ propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }, { propertyName: "popup", first: true, predicate: ["popup"], descendants: true, isSignal: true }, { propertyName: "search", first: true, predicate: ["search"], descendants: true, isSignal: true }, { propertyName: "retryButton", first: true, predicate: ["retryButton"], descendants: true, isSignal: true }, { propertyName: "scroll", first: true, predicate: ["scroll"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div
      class="atlas-select-shell"
      [class.is-invalid]="invalid() && touched()"
      [class.is-readonly]="readonly()"
    >
      <button
        #trigger
        type="button"
        role="combobox"
        aria-haspopup="grid"
        class="atlas-select-trigger"
        [id]="controlId()"
        [disabled]="disabled()"
        [attr.aria-label]="ariaLabel()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-expanded]="opened()"
        [attr.aria-controls]="controlId() + '-grid'"
        [attr.aria-readonly]="readonly()"
        [attr.aria-required]="required()"
        [attr.aria-invalid]="invalid() && touched()"
        (click)="open()"
        (keydown)="triggerKey($event)"
        (blur)="!opened() && touch.emit()"
      >
        <span [class.atlas-placeholder]="value() === null">{{
          selectedLabel()
        }}</span
        ><atlas-icon name="down" />
      </button>
      @if (clearable() && value() !== null && !disabled() && !readonly()) {
        <button
          type="button"
          class="atlas-select-clear atlas-control-action"
          [attr.aria-label]="'Clear ' + ariaLabel()"
          (click)="clear()"
        >
          <atlas-icon name="close" />
        </button>
      }
    </div>
    <div
      #popup
      popover="auto"
      class="atlas-select-popover atlas-lookup-popover"
      (toggle)="onToggle($event)"
      (keydown)="popupKey($event)"
    >
      <div class="atlas-select-search">
        <atlas-icon name="search" />
        <input
          #search
          type="text"
          role="combobox"
          aria-haspopup="grid"
          aria-expanded="true"
          [attr.aria-label]="'Search ' + ariaLabel()"
          placeholder="Search across columns…"
          [attr.aria-controls]="controlId() + '-grid'"
          [attr.aria-activedescendant]="activeId()"
          [value]="query()"
          (input)="searchFor($any($event.target).value)"
        />
      </div>
      <div #scroll class="atlas-lookup-scroll" [attr.aria-busy]="loading()">
        <div
          role="grid"
          [id]="controlId() + '-grid'"
          [attr.aria-label]="ariaLabel() + ' results'"
          aria-readonly="true"
        >
          <div
            role="row"
            class="atlas-lookup-head"
            [style.grid-template-columns]="columnWidths()"
          >
            @for (column of columns(); track column.key) {
              <span
                role="columnheader"
                [style.text-align]="column.align || 'left'"
                >{{ column.label }}</span
              >
            }
          </div>
          @if (!loading() && !error()) {
            @for (row of filtered(); track recordKey()(row); let i = $index) {
              <div
                role="row"
                class="atlas-lookup-row"
                [id]="controlId() + '-row-' + i"
                [style.grid-template-columns]="columnWidths()"
                [class.is-active]="activeIndex() === i"
                [class.is-selected]="isSelected(row)"
                [attr.aria-selected]="isSelected(row)"
                [attr.aria-disabled]="rowDisabled()(row)"
                (pointermove)="highlight(i)"
                (click)="choose(row)"
              >
                @for (column of columns(); track column.key) {
                  <span
                    role="gridcell"
                    [attr.data-label]="column.label"
                    [style.text-align]="column.align || 'left'"
                    >{{ cell(row, column) }}</span
                  >
                }
              </div>
            }
          }
        </div>
        @if (loading()) {
          <div class="atlas-options-empty" role="status">Loading records…</div>
        } @else if (error()) {
          <div class="atlas-options-empty" role="alert">
            {{ error() }}
            <button
              #retryButton
              type="button"
              class="atlas-button"
              (click)="retryLoad()"
            >
              Retry
            </button>
          </div>
        } @else if (!filtered().length) {
          <div class="atlas-options-empty" role="status">
            No matching records. Try another search.
          </div>
        }
      </div>
      @if (actions().length) {
        <div class="atlas-select-help" aria-label="Record actions">
          @for (action of actions(); track action.id) {
            <button type="button" class="atlas-button" (click)="runAction(action.id)">{{action.label}}</button>
          }
        </div>
      }
      @if(remote()) {
        <div class="atlas-select-help">
          <button type="button" tabindex="-1" [disabled]="loading() || page()===0" (click)="pageChange.emit(page()-1)" aria-label="Previous lookup page" aria-keyshortcuts="PageUp">Previous</button>
          <span>{{total()}} matches · Page {{page()+1}}</span>
          <button type="button" tabindex="-1" [disabled]="loading() || (page()+1)*pageSize()>=total()" (click)="pageChange.emit(page()+1)" aria-label="Next lookup page" aria-keyshortcuts="PageDown">Next</button>
        </div>
      }
      <div class="atlas-select-help">
        <span aria-live="polite">{{
          loading() || error()
            ? "No results available"
            : filtered().length + " records"
        }}</span
        ><span>↑ ↓ navigate · Enter selects · Esc cancels @if(remote()){ · PageUp/Down pages }</span>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasLookup, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-lookup",
                    imports: [AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-control", "(window:resize)": "close(false)" },
                    template: `
    <div
      class="atlas-select-shell"
      [class.is-invalid]="invalid() && touched()"
      [class.is-readonly]="readonly()"
    >
      <button
        #trigger
        type="button"
        role="combobox"
        aria-haspopup="grid"
        class="atlas-select-trigger"
        [id]="controlId()"
        [disabled]="disabled()"
        [attr.aria-label]="ariaLabel()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-expanded]="opened()"
        [attr.aria-controls]="controlId() + '-grid'"
        [attr.aria-readonly]="readonly()"
        [attr.aria-required]="required()"
        [attr.aria-invalid]="invalid() && touched()"
        (click)="open()"
        (keydown)="triggerKey($event)"
        (blur)="!opened() && touch.emit()"
      >
        <span [class.atlas-placeholder]="value() === null">{{
          selectedLabel()
        }}</span
        ><atlas-icon name="down" />
      </button>
      @if (clearable() && value() !== null && !disabled() && !readonly()) {
        <button
          type="button"
          class="atlas-select-clear atlas-control-action"
          [attr.aria-label]="'Clear ' + ariaLabel()"
          (click)="clear()"
        >
          <atlas-icon name="close" />
        </button>
      }
    </div>
    <div
      #popup
      popover="auto"
      class="atlas-select-popover atlas-lookup-popover"
      (toggle)="onToggle($event)"
      (keydown)="popupKey($event)"
    >
      <div class="atlas-select-search">
        <atlas-icon name="search" />
        <input
          #search
          type="text"
          role="combobox"
          aria-haspopup="grid"
          aria-expanded="true"
          [attr.aria-label]="'Search ' + ariaLabel()"
          placeholder="Search across columns…"
          [attr.aria-controls]="controlId() + '-grid'"
          [attr.aria-activedescendant]="activeId()"
          [value]="query()"
          (input)="searchFor($any($event.target).value)"
        />
      </div>
      <div #scroll class="atlas-lookup-scroll" [attr.aria-busy]="loading()">
        <div
          role="grid"
          [id]="controlId() + '-grid'"
          [attr.aria-label]="ariaLabel() + ' results'"
          aria-readonly="true"
        >
          <div
            role="row"
            class="atlas-lookup-head"
            [style.grid-template-columns]="columnWidths()"
          >
            @for (column of columns(); track column.key) {
              <span
                role="columnheader"
                [style.text-align]="column.align || 'left'"
                >{{ column.label }}</span
              >
            }
          </div>
          @if (!loading() && !error()) {
            @for (row of filtered(); track recordKey()(row); let i = $index) {
              <div
                role="row"
                class="atlas-lookup-row"
                [id]="controlId() + '-row-' + i"
                [style.grid-template-columns]="columnWidths()"
                [class.is-active]="activeIndex() === i"
                [class.is-selected]="isSelected(row)"
                [attr.aria-selected]="isSelected(row)"
                [attr.aria-disabled]="rowDisabled()(row)"
                (pointermove)="highlight(i)"
                (click)="choose(row)"
              >
                @for (column of columns(); track column.key) {
                  <span
                    role="gridcell"
                    [attr.data-label]="column.label"
                    [style.text-align]="column.align || 'left'"
                    >{{ cell(row, column) }}</span
                  >
                }
              </div>
            }
          }
        </div>
        @if (loading()) {
          <div class="atlas-options-empty" role="status">Loading records…</div>
        } @else if (error()) {
          <div class="atlas-options-empty" role="alert">
            {{ error() }}
            <button
              #retryButton
              type="button"
              class="atlas-button"
              (click)="retryLoad()"
            >
              Retry
            </button>
          </div>
        } @else if (!filtered().length) {
          <div class="atlas-options-empty" role="status">
            No matching records. Try another search.
          </div>
        }
      </div>
      @if (actions().length) {
        <div class="atlas-select-help" aria-label="Record actions">
          @for (action of actions(); track action.id) {
            <button type="button" class="atlas-button" (click)="runAction(action.id)">{{action.label}}</button>
          }
        </div>
      }
      @if(remote()) {
        <div class="atlas-select-help">
          <button type="button" tabindex="-1" [disabled]="loading() || page()===0" (click)="pageChange.emit(page()-1)" aria-label="Previous lookup page" aria-keyshortcuts="PageUp">Previous</button>
          <span>{{total()}} matches · Page {{page()+1}}</span>
          <button type="button" tabindex="-1" [disabled]="loading() || (page()+1)*pageSize()>=total()" (click)="pageChange.emit(page()+1)" aria-label="Next lookup page" aria-keyshortcuts="PageDown">Next</button>
        </div>
      }
      <div class="atlas-select-help">
        <span aria-live="polite">{{
          loading() || error()
            ? "No results available"
            : filtered().length + " records"
        }}</span
        ><span>↑ ↓ navigate · Enter selects · Esc cancels @if(remote()){ · PageUp/Down pages }</span>
      </div>
    </div>
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { actions: [{ type: i0.Input, args: [{ isSignal: true, alias: "actions", required: false }] }], action: [{ type: i0.Output, args: ["action"] }], controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: true }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], recordKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "recordKey", required: true }] }], displayWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "displayWith", required: true }] }], rowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowDisabled", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], arrowNavigation: [{ type: i0.Input, args: [{ isSignal: true, alias: "arrowNavigation", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], popupWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "popupWidth", required: false }] }], touch: [{ type: i0.Output, args: ["touch"] }], recordSelected: [{ type: i0.Output, args: ["recordSelected"] }], retry: [{ type: i0.Output, args: ["retry"] }], remote: [{ type: i0.Input, args: [{ isSignal: true, alias: "remote", required: false }] }], selectedText: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedText", required: false }] }], page: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }], total: [{ type: i0.Input, args: [{ isSignal: true, alias: "total", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], queryChange: [{ type: i0.Output, args: ["queryChange"] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], trigger: [{ type: i0.ViewChild, args: ["trigger", { isSignal: true }] }], popup: [{ type: i0.ViewChild, args: ["popup", { isSignal: true }] }], search: [{ type: i0.ViewChild, args: ["search", { isSignal: true }] }], retryButton: [{ type: i0.ViewChild, args: ["retryButton", { isSignal: true }] }], scroll: [{ type: i0.ViewChild, args: ["scroll", { isSignal: true }] }] } });

class AtlasTextarea {
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    value = model("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    touched = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    required = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []));
    placeholder = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    maxLength = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "maxLength" }] : /* istanbul ignore next */ []));
    rows = input(4, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    showCount = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showCount" }] : /* istanbul ignore next */ []));
    touch = output();
    native = viewChild.required("native", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "native" }] : /* istanbul ignore next */ []));
    edit(value) {
        if (!this.disabled() && !this.readonly())
            this.value.set(value);
    }
    focus(options) {
        this.native().nativeElement.focus(options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTextarea, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTextarea, isStandalone: true, selector: "atlas-textarea", inputs: { controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, maxLength: { classPropertyName: "maxLength", publicName: "maxLength", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, showCount: { classPropertyName: "showCount", publicName: "showCount", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touch: "touch" }, host: { classAttribute: "atlas-control" }, viewQueries: [{ propertyName: "native", first: true, predicate: ["native"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <textarea
      #native
      class="atlas-input atlas-textarea"
      [id]="controlId()"
      [attr.aria-label]="ariaLabel()"
      [value]="value()"
      [rows]="rows()"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [required]="required()"
      [attr.maxlength]="maxLength()"
      [placeholder]="placeholder()"
      [attr.aria-invalid]="invalid() && touched()"
      [attr.aria-describedby]="describedBy()"
      (input)="edit($any($event.target).value)"
      (blur)="touch.emit()"
    ></textarea>
    @if (showCount()) {
      <span class="atlas-textarea-count"
        >{{ value().length
        }}{{
          maxLength() === undefined ? " characters" : " / " + maxLength()
        }}</span
      >
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTextarea, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-textarea",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <textarea
      #native
      class="atlas-input atlas-textarea"
      [id]="controlId()"
      [attr.aria-label]="ariaLabel()"
      [value]="value()"
      [rows]="rows()"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [required]="required()"
      [attr.maxlength]="maxLength()"
      [placeholder]="placeholder()"
      [attr.aria-invalid]="invalid() && touched()"
      [attr.aria-describedby]="describedBy()"
      (input)="edit($any($event.target).value)"
      (blur)="touch.emit()"
    ></textarea>
    @if (showCount()) {
      <span class="atlas-textarea-count"
        >{{ value().length
        }}{{
          maxLength() === undefined ? " characters" : " / " + maxLength()
        }}</span
      >
    }
  `,
                    host: { class: "atlas-control" },
                }]
        }], propDecorators: { controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], maxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLength", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], showCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCount", required: false }] }], touch: [{ type: i0.Output, args: ["touch"] }], native: [{ type: i0.ViewChild, args: ["native", { isSignal: true }] }] } });
class AtlasToggle {
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    label = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    checked = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    touched = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    touch = output();
    native = viewChild.required("native", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "native" }] : /* istanbul ignore next */ []));
    toggle() {
        if (!this.disabled() && !this.readonly())
            this.checked.update((value) => !value);
    }
    focus(options) {
        this.native().nativeElement.focus(options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasToggle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.7", type: AtlasToggle, isStandalone: true, selector: "atlas-toggle", inputs: { controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange", touch: "touch" }, viewQueries: [{ propertyName: "native", first: true, predicate: ["native"], descendants: true, isSignal: true }], ngImport: i0, template: `<button
    #native
    type="button"
    role="switch"
    class="atlas-toggle"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-checked]="checked()"
    [attr.aria-readonly]="readonly()"
    [attr.aria-label]="label()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
    (click)="toggle()"
    (blur)="touch.emit()"
  >
    <span class="atlas-toggle-track" aria-hidden="true"><span></span></span
    ><span>{{ label() }}</span>
  </button>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasToggle, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-toggle",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<button
    #native
    type="button"
    role="switch"
    class="atlas-toggle"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-checked]="checked()"
    [attr.aria-readonly]="readonly()"
    [attr.aria-label]="label()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
    (click)="toggle()"
    (blur)="touch.emit()"
  >
    <span class="atlas-toggle-track" aria-hidden="true"><span></span></span
    ><span>{{ label() }}</span>
  </button>`,
                }]
        }], propDecorators: { controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }, { type: i0.Output, args: ["checkedChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }], touch: [{ type: i0.Output, args: ["touch"] }], native: [{ type: i0.ViewChild, args: ["native", { isSignal: true }] }] } });

/** Calendar date only. Never converts a business date through a timezone. */
function validCalendarDate(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    if (!match)
        return false;
    const [year, month, day] = match.slice(1).map(Number);
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    return (year > 0 &&
        month >= 1 &&
        month <= 12 &&
        day >= 1 &&
        day <=
            [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]);
}
function dateRangeError(range, min = "", max = "") {
    if (!range.start && !range.end)
        return "";
    if (!range.start || !range.end)
        return "Enter both dates.";
    if (!validCalendarDate(range.start) || !validCalendarDate(range.end))
        return "Enter valid calendar dates.";
    if (range.end < range.start)
        return "End date must be on or after start date.";
    if (min && range.start < min)
        return `Start date must be on or after ${min}.`;
    if (max && range.end > max)
        return `End date must be on or before ${max}.`;
    return "";
}
function toggleChoice(values, key, limit = 0) {
    if (values.includes(key))
        return values.filter((v) => v !== key);
    return limit > 0 && values.length >= limit ? [...values] : [...values, key];
}
/** Accept locale decimal/group separators and ASCII digits; reject partial/ambiguous input. */
function parseLocaleNumber(text, locale) {
    const value = text.trim();
    if (!value)
        return null;
    const parts = new Intl.NumberFormat(locale).formatToParts(12345.6);
    const decimal = parts.find((p) => p.type === "decimal")?.value ?? ".";
    const group = parts.find((p) => p.type === "group")?.value ?? ",";
    const segments = value.split(decimal);
    if (segments.length > 2)
        return undefined;
    let integer = segments[0];
    if (integer.includes(group)) {
        const groups = integer.replace(/^[+-]/, "").split(group);
        if (!/^\d{1,3}$/.test(groups[0]) ||
            groups.slice(1).some((g) => !/^\d{3}$/.test(g)))
            return undefined;
        integer = integer.split(group).join("");
    }
    const normalized = integer + (segments.length === 2 ? "." + segments[1] : "");
    if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(normalized))
        return undefined;
    const number = Number(normalized);
    return Number.isFinite(number) ? number : undefined;
}

class AtlasChoiceState {
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    label = input("Options", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    options = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    touched = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    touch = output();
    guardReadonly(event) {
        if (this.readonly())
            event.preventDefault();
    }
    hostElement = inject(ElementRef);
    focus(options) {
        this.hostElement.nativeElement
            .querySelector("input:not(:disabled)")
            ?.focus(options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasChoiceState, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasChoiceState, isStandalone: true, inputs: { controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { touch: "touch" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasChoiceState, decorators: [{
            type: Directive
        }], propDecorators: { controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], touch: [{ type: i0.Output, args: ["touch"] }] } });
class AtlasCheckboxGroup extends AtlasChoiceState {
    value = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    limit = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "limit" }] : /* istanbul ignore next */ []));
    blocked(key) {
        return (this.limit() > 0 &&
            this.value().length >= this.limit() &&
            !this.value().includes(key));
    }
    choose(option) {
        if (!this.disabled() && !this.readonly() && !option.disabled)
            this.value.set(toggleChoice(this.value(), option.value, this.limit()));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCheckboxGroup, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasCheckboxGroup, isStandalone: true, selector: "atlas-checkbox-group", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, limit: { classPropertyName: "limit", publicName: "limit", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, usesInheritance: true, ngImport: i0, template: `<fieldset
    class="atlas-choice-group"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
  >
    <legend>{{ label() }}</legend>
    @for (option of options(); track option.value) {
      <label
        ><input
          type="checkbox"
          [checked]="value().includes(option.value)"
          [disabled]="option.disabled || blocked(option.value)"
          [attr.aria-readonly]="readonly()"
          (click)="guardReadonly($event)"
          (change)="choose(option)"
          (blur)="touch.emit()"
        /><span
          >{{ option.label }}
          @if (option.description) {
            <small>{{ option.description }}</small>
          }
        </span></label
      >
    }
    @if (limit()) {
      <small>{{ value().length }} / {{ limit() }} selected</small>
    }
  </fieldset>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCheckboxGroup, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-checkbox-group",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<fieldset
    class="atlas-choice-group"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
  >
    <legend>{{ label() }}</legend>
    @for (option of options(); track option.value) {
      <label
        ><input
          type="checkbox"
          [checked]="value().includes(option.value)"
          [disabled]="option.disabled || blocked(option.value)"
          [attr.aria-readonly]="readonly()"
          (click)="guardReadonly($event)"
          (change)="choose(option)"
          (blur)="touch.emit()"
        /><span
          >{{ option.label }}
          @if (option.description) {
            <small>{{ option.description }}</small>
          }
        </span></label
      >
    }
    @if (limit()) {
      <small>{{ value().length }} / {{ limit() }} selected</small>
    }
  </fieldset>`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], limit: [{ type: i0.Input, args: [{ isSignal: true, alias: "limit", required: false }] }] } });
class AtlasRadioGroup extends AtlasChoiceState {
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    choose(option) {
        if (!this.disabled() && !this.readonly() && !option.disabled)
            this.value.set(option.value);
    }
    readonlyKey(event) {
        if (this.readonly() &&
            ["ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight", " "].includes(event.key))
            event.preventDefault();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRadioGroup, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasRadioGroup, isStandalone: true, selector: "atlas-radio-group", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, usesInheritance: true, ngImport: i0, template: `<fieldset
    class="atlas-choice-group"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
  >
    <legend>{{ label() }}</legend>
    @for (option of options(); track option.value) {
      <label
        ><input
          type="radio"
          [name]="controlId()"
          [value]="option.value"
          [checked]="value() === option.value"
          [disabled]="option.disabled"
          [attr.aria-readonly]="readonly()"
          (click)="guardReadonly($event)"
          (keydown)="readonlyKey($event)"
          (change)="choose(option)"
          (blur)="touch.emit()"
        /><span
          >{{ option.label }}
          @if (option.description) {
            <small>{{ option.description }}</small>
          }
        </span></label
      >
    }
  </fieldset>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRadioGroup, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-radio-group",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<fieldset
    class="atlas-choice-group"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
  >
    <legend>{{ label() }}</legend>
    @for (option of options(); track option.value) {
      <label
        ><input
          type="radio"
          [name]="controlId()"
          [value]="option.value"
          [checked]="value() === option.value"
          [disabled]="option.disabled"
          [attr.aria-readonly]="readonly()"
          (click)="guardReadonly($event)"
          (keydown)="readonlyKey($event)"
          (change)="choose(option)"
          (blur)="touch.emit()"
        /><span
          >{{ option.label }}
          @if (option.description) {
            <small>{{ option.description }}</small>
          }
        </span></label
      >
    }
  </fieldset>`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }] } });
class AtlasChoiceOverlay extends AtlasChoiceState {
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    opened = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    query = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    filtered = computed(() => filterCollection(this.options(), this.query(), (o) => o.label + " " + (o.description ?? "")), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []));
    trigger = viewChild.required("trigger", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    popup = viewChild.required("popup", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "popup" }] : /* istanbul ignore next */ []));
    search = viewChild.required("search", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    onScroll = (event) => {
        if (!this.popup().nativeElement.contains(event.target))
            this.close(false);
    };
    constructor() {
        super();
        effect(() => {
            if ((this.disabled() || this.readonly()) && this.opened())
                this.close(false);
        });
    }
    open() {
        if (this.disabled() || this.readonly() || this.opened())
            return;
        const popup = this.popup().nativeElement, rect = this.trigger().nativeElement.getBoundingClientRect();
        const win = popup.ownerDocument.defaultView;
        const mobileBounds = this.trigger()
            .nativeElement.closest(".mobile-workspace")
            ?.getBoundingClientRect();
        const right = mobileBounds?.right ?? win.innerWidth, left = mobileBounds?.left ?? 0;
        const below = (mobileBounds?.bottom ?? win.innerHeight) - rect.bottom - 12, above = rect.top - (mobileBounds?.top ?? 0) - 12, down = below >= Math.min(320, above);
        const width = Math.min(Math.max(280, rect.width), right - left - 16);
        Object.assign(popup.style, {
            left: `${Math.max(left + 8, Math.min(rect.left, right - width - 8))}px`,
            width: `${width}px`,
            top: down ? `${rect.bottom + 5}px` : "auto",
            bottom: down ? "auto" : `${win.innerHeight - rect.top + 5}px`,
            maxHeight: `${Math.max(0, Math.min(320, down ? below : above))}px`,
        });
        popup.showPopover();
        this.opened.set(true);
        this.search().nativeElement.focus({ preventScroll: true });
        popup.ownerDocument.addEventListener("scroll", this.onScroll, true);
    }
    close(focus = true) {
        if (!this.opened())
            return;
        this.popup().nativeElement.hidePopover();
        this.opened.set(false);
        this.detach();
        this.touch.emit();
        if (focus)
            this.focus();
    }
    toggled(event) {
        if (event.newState === "closed") {
            this.opened.set(false);
            this.detach();
            this.touch.emit();
        }
    }
    focus(options) {
        this.trigger().nativeElement.focus(options);
    }
    dismissKey(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            this.close();
            return true;
        }
        return false;
    }
    detach() {
        this.popup().nativeElement.ownerDocument.removeEventListener("scroll", this.onScroll, true);
    }
    ngOnDestroy() {
        this.detach();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasChoiceOverlay, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.1.7", type: AtlasChoiceOverlay, isStandalone: true, inputs: { loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }, { propertyName: "popup", first: true, predicate: ["popup"], descendants: true, isSignal: true }, { propertyName: "search", first: true, predicate: ["search"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasChoiceOverlay, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], trigger: [{ type: i0.ViewChild, args: ["trigger", { isSignal: true }] }], popup: [{ type: i0.ViewChild, args: ["popup", { isSignal: true }] }], search: [{ type: i0.ViewChild, args: ["search", { isSignal: true }] }] } });
class AtlasMultiSelect extends AtlasChoiceOverlay {
    value = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    limit = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "limit" }] : /* istanbul ignore next */ []));
    optionLabel(key) {
        return this.options().find((o) => o.value === key)?.label ?? key;
    }
    blocked(key) {
        return (this.limit() > 0 &&
            this.value().length >= this.limit() &&
            !this.value().includes(key));
    }
    choose(option) {
        if (!this.disabled() &&
            !this.readonly() &&
            !this.loading() &&
            !option.disabled)
            this.value.set(toggleChoice(this.value(), option.value, this.limit()));
    }
    remove(key) {
        if (!this.disabled() && !this.readonly()) {
            this.value.update((v) => v.filter((k) => k !== key));
            this.touch.emit();
        }
    }
    clear() {
        if (!this.disabled() && !this.readonly()) {
            this.value.set([]);
            this.touch.emit();
        }
    }
    key(event) {
        if (this.dismissKey(event))
            return;
        if (event.key === "Tab") {
            const buttons = Array.from(this.popup().nativeElement.querySelectorAll("input:not(:disabled),button:not(:disabled)"));
            if ((event.shiftKey && event.target === buttons[0]) ||
                (!event.shiftKey && event.target === buttons.at(-1)))
                this.close();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMultiSelect, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasMultiSelect, isStandalone: true, selector: "atlas-multi-select", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, limit: { classPropertyName: "limit", publicName: "limit", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { listeners: { "window:resize": "close(false)" }, classAttribute: "atlas-control" }, usesInheritance: true, ngImport: i0, template: `<button
      #trigger
      type="button"
      class="atlas-select-trigger atlas-multi-trigger"
      [id]="controlId()"
      [disabled]="disabled()"
      aria-haspopup="dialog"
      [attr.aria-expanded]="opened()"
      [attr.aria-controls]="controlId() + '-popup'"
      [attr.aria-label]="label()"
      [attr.aria-readonly]="readonly()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid() && touched()"
      (click)="opened() ? close() : open()"
      (blur)="!opened() && touch.emit()"
    >
      <span>{{
        value().length ? value().length + " selected" : "Choose options"
      }}</span
      ><atlas-icon name="down" />
    </button>
    <div class="atlas-token-list">
      @for (key of value(); track key) {
        <span
          >{{ optionLabel(key)
          }}<button
            type="button"
            [disabled]="disabled() || readonly()"
            [attr.aria-label]="'Remove ' + optionLabel(key)"
            (click)="remove(key)"
          >
            ×
          </button></span
        >
      }
    </div>
    <div
      #popup
      popover="auto"
      role="dialog"
      [id]="controlId() + '-popup'"
      [attr.aria-label]="label() + ' selection'"
      class="atlas-select-popover"
      (toggle)="toggled($event)"
      (keydown)="key($event)"
    >
      <div class="atlas-select-search">
        <atlas-icon name="search" /><input
          #search
          type="search"
          [attr.aria-label]="'Search ' + label()"
          [value]="query()"
          (input)="query.set($any($event.target).value)"
          placeholder="Search options…"
        />
      </div>
      <div class="atlas-choice-results">
        @if (loading()) {
          <p role="status">Loading options…</p>
        } @else {
          @for (option of filtered(); track option.value) {
            <label
              ><input
                type="checkbox"
                [checked]="value().includes(option.value)"
                [disabled]="option.disabled || blocked(option.value)"
                (change)="choose(option)"
              /><span
                >{{ option.label }}<small>{{ option.description }}</small></span
              ></label
            >
          } @empty {
            <p role="status">No matching options.</p>
          }
        }
      </div>
      <div class="atlas-multi-footer">
        <span aria-live="polite"
          >{{ value().length }} selected{{
            limit() ? " / " + limit() : ""
          }}</span
        ><button type="button" (click)="clear()">Clear</button
        ><button type="button" (click)="close()">Done</button>
      </div>
    </div>`, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMultiSelect, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-multi-select",
                    imports: [AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-control", "(window:resize)": "close(false)" },
                    template: `<button
      #trigger
      type="button"
      class="atlas-select-trigger atlas-multi-trigger"
      [id]="controlId()"
      [disabled]="disabled()"
      aria-haspopup="dialog"
      [attr.aria-expanded]="opened()"
      [attr.aria-controls]="controlId() + '-popup'"
      [attr.aria-label]="label()"
      [attr.aria-readonly]="readonly()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid() && touched()"
      (click)="opened() ? close() : open()"
      (blur)="!opened() && touch.emit()"
    >
      <span>{{
        value().length ? value().length + " selected" : "Choose options"
      }}</span
      ><atlas-icon name="down" />
    </button>
    <div class="atlas-token-list">
      @for (key of value(); track key) {
        <span
          >{{ optionLabel(key)
          }}<button
            type="button"
            [disabled]="disabled() || readonly()"
            [attr.aria-label]="'Remove ' + optionLabel(key)"
            (click)="remove(key)"
          >
            ×
          </button></span
        >
      }
    </div>
    <div
      #popup
      popover="auto"
      role="dialog"
      [id]="controlId() + '-popup'"
      [attr.aria-label]="label() + ' selection'"
      class="atlas-select-popover"
      (toggle)="toggled($event)"
      (keydown)="key($event)"
    >
      <div class="atlas-select-search">
        <atlas-icon name="search" /><input
          #search
          type="search"
          [attr.aria-label]="'Search ' + label()"
          [value]="query()"
          (input)="query.set($any($event.target).value)"
          placeholder="Search options…"
        />
      </div>
      <div class="atlas-choice-results">
        @if (loading()) {
          <p role="status">Loading options…</p>
        } @else {
          @for (option of filtered(); track option.value) {
            <label
              ><input
                type="checkbox"
                [checked]="value().includes(option.value)"
                [disabled]="option.disabled || blocked(option.value)"
                (change)="choose(option)"
              /><span
                >{{ option.label }}<small>{{ option.description }}</small></span
              ></label
            >
          } @empty {
            <p role="status">No matching options.</p>
          }
        }
      </div>
      <div class="atlas-multi-footer">
        <span aria-live="polite"
          >{{ value().length }} selected{{
            limit() ? " / " + limit() : ""
          }}</span
        ><button type="button" (click)="clear()">Clear</button
        ><button type="button" (click)="close()">Done</button>
      </div>
    </div>`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], limit: [{ type: i0.Input, args: [{ isSignal: true, alias: "limit", required: false }] }] } });
class AtlasAutocomplete extends AtlasChoiceOverlay {
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    active = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    display = computed(() => this.options().find((o) => o.value === this.value())?.label ?? "", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []));
    first() {
        return this.filtered().findIndex((o) => !o.disabled);
    }
    type(text) {
        this.query.set(text);
        this.active.set(this.first());
        this.open();
    }
    open() {
        super.open();
        this.active.set(this.first());
    }
    focus(options) {
        this.trigger().nativeElement.querySelector("input")?.focus(options);
    }
    choose(option) {
        if (this.disabled() || this.readonly() || this.loading() || option.disabled)
            return;
        this.value.set(option.value);
        this.close();
    }
    close(focus = true) {
        super.close(focus);
        const native = this.trigger().nativeElement.querySelector("input");
        if (native)
            native.value = this.display();
    }
    toggled(event) {
        super.toggled(event);
        if (event.newState === "closed") {
            const native = this.trigger().nativeElement.querySelector("input");
            if (native)
                native.value = this.display();
        }
    }
    clear() {
        if (!this.disabled() && !this.readonly()) {
            this.value.set(null);
            this.query.set("");
            this.touch.emit();
            this.focus();
        }
    }
    key(event) {
        if (this.dismissKey(event))
            return;
        if (event.key === "Tab") {
            this.close();
            return;
        }
        if (this.loading())
            return;
        if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
            event.preventDefault();
            this.active.set(nextLookupIndex(this.filtered(), this.active(), event.key, (o) => !!o.disabled));
            const row = this.popup().nativeElement.querySelector(`[id="${this.controlId()}-option-${this.active()}"]`);
            const scroll = row?.parentElement;
            if (row && scroll) {
                const top = row.getBoundingClientRect().top -
                    scroll.getBoundingClientRect().top +
                    scroll.scrollTop;
                if (top < scroll.scrollTop)
                    scroll.scrollTop = top;
                else if (top + row.offsetHeight >
                    scroll.scrollTop + scroll.clientHeight)
                    scroll.scrollTop = top + row.offsetHeight - scroll.clientHeight;
            }
        }
        else if (event.key === "Enter") {
            event.preventDefault();
            const option = this.filtered()[this.active()];
            if (option)
                this.choose(option);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAutocomplete, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasAutocomplete, isStandalone: true, selector: "atlas-autocomplete", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { listeners: { "window:resize": "close(false)" }, classAttribute: "atlas-control" }, usesInheritance: true, ngImport: i0, template: `<div #trigger class="atlas-select-shell">
      <input
        class="atlas-input"
        [id]="controlId()"
        [value]="display()"
        [disabled]="disabled()"
        [readOnly]="readonly()"
        role="combobox"
        aria-haspopup="listbox"
        [attr.aria-expanded]="opened()"
        [attr.aria-controls]="controlId() + '-list'"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid() && touched()"
        placeholder="Type to find a record…"
        (input)="type($any($event.target).value)"
        (keydown.arrowdown)="$event.preventDefault(); open()"
        (blur)="!opened() && touch.emit()"
      /><button
        type="button"
        class="atlas-control-action"
        [disabled]="disabled() || readonly()"
        [attr.aria-label]="'Clear ' + label()"
        (click)="clear()"
      >
        <atlas-icon name="close" />
      </button>
    </div>
    <div
      #popup
      popover="auto"
      class="atlas-select-popover"
      (toggle)="toggled($event)"
      (keydown)="key($event)"
    >
      <div class="atlas-select-search">
        <input
          #search
          type="text"
          role="combobox"
          aria-expanded="true"
          aria-haspopup="listbox"
          [attr.aria-label]="'Search ' + label()"
          [attr.aria-controls]="controlId() + '-list'"
          [attr.aria-activedescendant]="
            !loading() && filtered()[active()]
              ? controlId() + '-option-' + active()
              : null
          "
          [value]="query()"
          (input)="query.set($any($event.target).value); active.set(first())"
        />
      </div>
      <div
        class="atlas-select-options"
        role="listbox"
        [id]="controlId() + '-list'"
        [attr.aria-label]="label() + ' suggestions'"
      >
        @if (loading()) {
          <p class="atlas-options-empty" role="status">Loading suggestions…</p>
        } @else {
          @for (option of filtered(); track option.value; let i = $index) {
            <button
              type="button"
              role="option"
              tabindex="-1"
              class="atlas-select-option"
              [id]="controlId() + '-option-' + i"
              [disabled]="option.disabled"
              [attr.aria-selected]="value() === option.value"
              [class.is-active]="active() === i"
              (click)="choose(option)"
            >
              <span
                ><strong>{{ option.label }}</strong
                ><small>{{ option.description }}</small></span
              >
            </button>
          } @empty {
            <p class="atlas-options-empty" role="status">
              No matching suggestions.
            </p>
          }
        }
      </div>
      <div class="atlas-select-help">
        Enter selects · Escape keeps the previous value
      </div>
    </div>`, isInline: true, dependencies: [{ kind: "component", type: AtlasIcon, selector: "atlas-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAutocomplete, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-autocomplete",
                    imports: [AtlasIcon],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-control", "(window:resize)": "close(false)" },
                    template: `<div #trigger class="atlas-select-shell">
      <input
        class="atlas-input"
        [id]="controlId()"
        [value]="display()"
        [disabled]="disabled()"
        [readOnly]="readonly()"
        role="combobox"
        aria-haspopup="listbox"
        [attr.aria-expanded]="opened()"
        [attr.aria-controls]="controlId() + '-list'"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid() && touched()"
        placeholder="Type to find a record…"
        (input)="type($any($event.target).value)"
        (keydown.arrowdown)="$event.preventDefault(); open()"
        (blur)="!opened() && touch.emit()"
      /><button
        type="button"
        class="atlas-control-action"
        [disabled]="disabled() || readonly()"
        [attr.aria-label]="'Clear ' + label()"
        (click)="clear()"
      >
        <atlas-icon name="close" />
      </button>
    </div>
    <div
      #popup
      popover="auto"
      class="atlas-select-popover"
      (toggle)="toggled($event)"
      (keydown)="key($event)"
    >
      <div class="atlas-select-search">
        <input
          #search
          type="text"
          role="combobox"
          aria-expanded="true"
          aria-haspopup="listbox"
          [attr.aria-label]="'Search ' + label()"
          [attr.aria-controls]="controlId() + '-list'"
          [attr.aria-activedescendant]="
            !loading() && filtered()[active()]
              ? controlId() + '-option-' + active()
              : null
          "
          [value]="query()"
          (input)="query.set($any($event.target).value); active.set(first())"
        />
      </div>
      <div
        class="atlas-select-options"
        role="listbox"
        [id]="controlId() + '-list'"
        [attr.aria-label]="label() + ' suggestions'"
      >
        @if (loading()) {
          <p class="atlas-options-empty" role="status">Loading suggestions…</p>
        } @else {
          @for (option of filtered(); track option.value; let i = $index) {
            <button
              type="button"
              role="option"
              tabindex="-1"
              class="atlas-select-option"
              [id]="controlId() + '-option-' + i"
              [disabled]="option.disabled"
              [attr.aria-selected]="value() === option.value"
              [class.is-active]="active() === i"
              (click)="choose(option)"
            >
              <span
                ><strong>{{ option.label }}</strong
                ><small>{{ option.description }}</small></span
              >
            </button>
          } @empty {
            <p class="atlas-options-empty" role="status">
              No matching suggestions.
            </p>
          }
        }
      </div>
      <div class="atlas-select-help">
        Enter selects · Escape keeps the previous value
      </div>
    </div>`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }] } });

class AtlasEntryState {
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    label = input("Value", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    touched = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    touch = output();
    native = viewChild.required("native", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "native" }] : /* istanbul ignore next */ []));
    focus(options) {
        this.native().nativeElement.focus(options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasEntryState, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.1.7", type: AtlasEntryState, isStandalone: true, inputs: { controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { touch: "touch" }, viewQueries: [{ propertyName: "native", first: true, predicate: ["native"], descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasEntryState, decorators: [{
            type: Directive
        }], propDecorators: { controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], touch: [{ type: i0.Output, args: ["touch"] }], native: [{ type: i0.ViewChild, args: ["native", { isSignal: true }] }] } });
class AtlasDateInput extends AtlasEntryState {
    value = model("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    minDate = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minDate" }] : /* istanbul ignore next */ []));
    maxDate = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxDate" }] : /* istanbul ignore next */ []));
    edit(value) {
        if (!this.disabled() && !this.readonly())
            this.value.set(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDateInput, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasDateInput, isStandalone: true, selector: "atlas-date-input", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, minDate: { classPropertyName: "minDate", publicName: "minDate", isSignal: true, isRequired: false, transformFunction: null }, maxDate: { classPropertyName: "maxDate", publicName: "maxDate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "atlas-control" }, usesInheritance: true, ngImport: i0, template: `<input
    #native
    class="atlas-input"
    type="date"
    [id]="controlId()"
    [attr.aria-label]="label()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
    [value]="value()"
    [min]="minDate()"
    [max]="maxDate()"
    [disabled]="disabled()"
    [readOnly]="readonly()"
    (input)="edit($any($event.target).value)"
    (blur)="touch.emit()"
  />`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDateInput, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-date-input",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-control" },
                    template: `<input
    #native
    class="atlas-input"
    type="date"
    [id]="controlId()"
    [attr.aria-label]="label()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
    [value]="value()"
    [min]="minDate()"
    [max]="maxDate()"
    [disabled]="disabled()"
    [readOnly]="readonly()"
    (input)="edit($any($event.target).value)"
    (blur)="touch.emit()"
  />`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], minDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "minDate", required: false }] }], maxDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxDate", required: false }] }] } });
class AtlasDateRangeInput extends AtlasEntryState {
    value = model({ start: "", end: "" }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    minDate = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minDate" }] : /* istanbul ignore next */ []));
    maxDate = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxDate" }] : /* istanbul ignore next */ []));
    rangeError = computed(() => dateRangeError(this.value(), this.minDate(), this.maxDate()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rangeError" }] : /* istanbul ignore next */ []));
    edit(key, value) {
        if (!this.disabled() && !this.readonly())
            this.value.update((v) => ({ ...v, [key]: value }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDateRangeInput, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasDateRangeInput, isStandalone: true, selector: "atlas-date-range", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, minDate: { classPropertyName: "minDate", publicName: "minDate", isSignal: true, isRequired: false, transformFunction: null }, maxDate: { classPropertyName: "maxDate", publicName: "maxDate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { classAttribute: "atlas-control" }, usesInheritance: true, ngImport: i0, template: `<fieldset
      class="atlas-date-range"
      [attr.aria-invalid]="touched() && !!rangeError()"
      [disabled]="disabled()"
      [attr.aria-describedby]="describedBy()"
    >
      <legend>{{ label() }}</legend>
      <label
        >From<input
          #native
          class="atlas-input"
          type="date"
          [id]="controlId()"
          [attr.aria-label]="label() + ' start'"
          [value]="value().start"
          [min]="minDate()"
          [max]="maxDate()"
          [readOnly]="readonly()"
          (input)="edit('start', $any($event.target).value)"
          (blur)="touch.emit()" /></label
      ><label
        >To<input
          class="atlas-input"
          type="date"
          [attr.aria-label]="label() + ' end'"
          [value]="value().end"
          [min]="value().start || minDate()"
          [max]="maxDate()"
          [readOnly]="readonly()"
          (input)="edit('end', $any($event.target).value)"
          (blur)="touch.emit()"
      /></label>
    </fieldset>
    @if (touched() && rangeError()) {
      <p class="atlas-field-error" role="status">{{ rangeError() }}</p>
    }`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDateRangeInput, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-date-range",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-control" },
                    template: `<fieldset
      class="atlas-date-range"
      [attr.aria-invalid]="touched() && !!rangeError()"
      [disabled]="disabled()"
      [attr.aria-describedby]="describedBy()"
    >
      <legend>{{ label() }}</legend>
      <label
        >From<input
          #native
          class="atlas-input"
          type="date"
          [id]="controlId()"
          [attr.aria-label]="label() + ' start'"
          [value]="value().start"
          [min]="minDate()"
          [max]="maxDate()"
          [readOnly]="readonly()"
          (input)="edit('start', $any($event.target).value)"
          (blur)="touch.emit()" /></label
      ><label
        >To<input
          class="atlas-input"
          type="date"
          [attr.aria-label]="label() + ' end'"
          [value]="value().end"
          [min]="value().start || minDate()"
          [max]="maxDate()"
          [readOnly]="readonly()"
          (input)="edit('end', $any($event.target).value)"
          (blur)="touch.emit()"
      /></label>
    </fieldset>
    @if (touched() && rangeError()) {
      <p class="atlas-field-error" role="status">{{ rangeError() }}</p>
    }`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], minDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "minDate", required: false }] }], maxDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxDate", required: false }] }] } });
class AtlasDecimalInput extends AtlasEntryState {
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    locale = input("en-US", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "locale" }] : /* istanbul ignore next */ []));
    currency = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currency" }] : /* istanbul ignore next */ []));
    fractionDigits = input(2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fractionDigits" }] : /* istanbul ignore next */ []));
    parseErrorChange = output();
    text = linkedSignal(() => this.format(this.value(), true), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    parseError = computed(() => parseLocaleNumber(this.text(), this.locale()) === undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "parseError" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => this.parseErrorChange.emit(this.parseError()));
    }
    reset() {
        this.text.set(this.format(this.value(), true));
    }
    format(value, grouping) {
        return value === null
            ? ""
            : new Intl.NumberFormat(this.locale(), {
                useGrouping: grouping,
                minimumFractionDigits: grouping ? this.fractionDigits() : 0,
                maximumFractionDigits: Math.max(this.fractionDigits(), 10),
            }).format(value);
    }
    begin() {
        if (!this.parseError())
            this.text.set(this.format(this.value(), false));
    }
    edit(text) {
        if (this.disabled() || this.readonly())
            return;
        const number = parseLocaleNumber(text, this.locale());
        if (number !== undefined)
            this.value.set(number);
        this.text.set(text);
    }
    finish() {
        if (!this.parseError())
            this.text.set(this.format(this.value(), true));
        this.touch.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDecimalInput, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasDecimalInput, isStandalone: true, selector: "atlas-decimal-input", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, currency: { classPropertyName: "currency", publicName: "currency", isSignal: true, isRequired: false, transformFunction: null }, fractionDigits: { classPropertyName: "fractionDigits", publicName: "fractionDigits", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", parseErrorChange: "parseErrorChange" }, host: { classAttribute: "atlas-control" }, usesInheritance: true, ngImport: i0, template: `<div
      class="atlas-input-shell"
      [class.is-invalid]="parseError() || (invalid() && touched())"
    >
      @if (currency()) {
        <span class="atlas-input-affix">{{ currency() }}</span>
      }
      <input
        #native
        type="text"
        inputmode="decimal"
        [id]="controlId()"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="parseError() || (invalid() && touched())"
        [disabled]="disabled()"
        [readOnly]="readonly()"
        [value]="text()"
        (input)="edit($any($event.target).value)"
        (focus)="begin()"
        (blur)="finish()"
      />
    </div>
    @if (parseError()) {
      <p class="atlas-field-error" role="status">
        Enter a valid number for {{ locale() }}.
      </p>
    }`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDecimalInput, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-decimal-input",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-control" },
                    template: `<div
      class="atlas-input-shell"
      [class.is-invalid]="parseError() || (invalid() && touched())"
    >
      @if (currency()) {
        <span class="atlas-input-affix">{{ currency() }}</span>
      }
      <input
        #native
        type="text"
        inputmode="decimal"
        [id]="controlId()"
        [attr.aria-label]="label()"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="parseError() || (invalid() && touched())"
        [disabled]="disabled()"
        [readOnly]="readonly()"
        [value]="text()"
        (input)="edit($any($event.target).value)"
        (focus)="begin()"
        (blur)="finish()"
      />
    </div>
    @if (parseError()) {
      <p class="atlas-field-error" role="status">
        Enter a valid number for {{ locale() }}.
      </p>
    }`,
                }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], currency: [{ type: i0.Input, args: [{ isSignal: true, alias: "currency", required: false }] }], fractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "fractionDigits", required: false }] }], parseErrorChange: [{ type: i0.Output, args: ["parseErrorChange"] }] } });
class AtlasValidationSummary {
    issues = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "issues" }] : /* istanbul ignore next */ []));
    fieldRequested = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasValidationSummary, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasValidationSummary, isStandalone: true, selector: "atlas-validation-summary", inputs: { issues: { classPropertyName: "issues", publicName: "issues", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { fieldRequested: "fieldRequested" }, ngImport: i0, template: `@if (issues().length) {
    <section
      class="atlas-validation-summary"
      role="alert"
      aria-label="Form validation"
    >
      <strong
        >Review {{ issues().length }}
        {{ issues().length === 1 ? "field" : "fields" }}</strong
      >
      <ul>
        @for (issue of issues(); track issue.id) {
          <li>
            <button type="button" (click)="fieldRequested.emit(issue.id)">
              {{ issue.message }}
            </button>
          </li>
        }
      </ul>
    </section>
  }`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasValidationSummary, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-validation-summary",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `@if (issues().length) {
    <section
      class="atlas-validation-summary"
      role="alert"
      aria-label="Form validation"
    >
      <strong
        >Review {{ issues().length }}
        {{ issues().length === 1 ? "field" : "fields" }}</strong
      >
      <ul>
        @for (issue of issues(); track issue.id) {
          <li>
            <button type="button" (click)="fieldRequested.emit(issue.id)">
              {{ issue.message }}
            </button>
          </li>
        }
      </ul>
    </section>
  }`,
                }]
        }], propDecorators: { issues: [{ type: i0.Input, args: [{ isSignal: true, alias: "issues", required: false }] }], fieldRequested: [{ type: i0.Output, args: ["fieldRequested"] }] } });

/** Filtering includes ancestors of matches. Search expansion does not change saved expansion. */
function flattenTree(nodes, expanded, query = "") {
    const term = query.trim().toLocaleLowerCase();
    const matches = (node) => !term ||
        `${node.label} ${node.description ?? ""}`
            .toLocaleLowerCase()
            .includes(term) ||
        !!node.children?.some(matches);
    const result = [];
    const visit = (siblings, level, parent) => {
        const shown = siblings.filter(matches);
        shown.forEach((node, index) => {
            const open = (!!node.children?.length || !!node.hasChildren) &&
                (!!term || expanded.includes(node.id));
            result.push({
                node,
                level,
                parent,
                position: index + 1,
                size: shown.length,
                expanded: open,
            });
            if (open)
                visit(node.children ?? [], level + 1, node.id);
        });
    };
    visit(nodes, 1, null);
    return result;
}
function findTreeNode(nodes, id) {
    for (const node of nodes) {
        if (node.id === id)
            return node;
        const found = findTreeNode(node.children ?? [], id);
        if (found)
            return found;
    }
    return undefined;
}

class AtlasTree {
    nodes = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    label = input("Hierarchy", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    filterable = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterable" }] : /* istanbul ignore next */ []));
    leafOnly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "leafOnly" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    error = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    retry = output();
    selectedId = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedId" }] : /* istanbul ignore next */ []));
    expandedIds = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandedIds" }] : /* istanbul ignore next */ []));
    nodeSelected = output();
    query = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    focused = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []));
    visible = computed(() => flattenTree(this.nodes(), this.expandedIds(), this.query()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    tabstop = computed(() => this.visible().some((r) => r.node.id === this.focused())
        ? this.focused()
        : this.visible()[0]?.node.id, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabstop" }] : /* istanbul ignore next */ []));
    toggle(row) {
        if (this.disabled() || !row.node.children?.length || this.query().trim())
            return;
        this.expandedIds.update((ids) => ids.includes(row.node.id)
            ? ids.filter((id) => id !== row.node.id)
            : [...ids, row.node.id]);
    }
    choose(row) {
        if (this.disabled() ||
            this.readonly() ||
            row.node.disabled ||
            (this.leafOnly() && row.node.children?.length))
            return;
        this.selectedId.set(row.node.id);
        this.nodeSelected.emit(row.node);
    }
    key(event, item) {
        const rows = this.visible(), index = rows.findIndex((row) => row.node.id === item.node.id);
        const row = rows[index];
        if (!row)
            return;
        let target = index;
        switch (event.key) {
            case "ArrowDown":
                target = Math.min(rows.length - 1, index + 1);
                break;
            case "ArrowUp":
                target = Math.max(0, index - 1);
                break;
            case "Home":
                target = 0;
                break;
            case "End":
                target = rows.length - 1;
                break;
            case "ArrowRight":
                if (row.node.children?.length) {
                    if (!row.expanded)
                        this.toggle(row);
                    else
                        target = Math.min(rows.length - 1, index + 1);
                }
                break;
            case "ArrowLeft":
                if (row.expanded && !this.query().trim())
                    this.toggle(row);
                else if (row.parent)
                    target = rows.findIndex((r) => r.node.id === row.parent);
                break;
            case "Enter":
            case " ":
                this.choose(row);
                break;
            default:
                return;
        }
        event.preventDefault();
        const node = rows[target];
        if (node) {
            this.focused.set(node.node.id);
            event.currentTarget.parentElement
                ?.querySelectorAll('[role="treeitem"]')[target]?.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTree, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTree, isStandalone: true, selector: "atlas-tree", inputs: { nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: false, transformFunction: null }, leafOnly: { classPropertyName: "leafOnly", publicName: "leafOnly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null }, expandedIds: { classPropertyName: "expandedIds", publicName: "expandedIds", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { retry: "retry", selectedId: "selectedIdChange", expandedIds: "expandedIdsChange", nodeSelected: "nodeSelected" }, ngImport: i0, template: `
    @if (filterable()) {
      <input
        atlasInput
        type="search"
        [attr.aria-label]="'Search ' + label()"
        placeholder="Search hierarchy…"
        [value]="query()"
        (input)="query.set($any($event.target).value)"
      />
    }
    <div
      class="atlas-tree"
      role="tree"
      [attr.aria-label]="label()"
      [attr.aria-busy]="loading()"
    >
      @if (!loading() && !error()) {
        @for (row of visible(); track row.node.id) {
          <button
            type="button"
            role="treeitem"
            class="atlas-tree-row"
            [style.--atlas-tree-depth]="row.level - 1"
            [attr.aria-level]="row.level"
            [attr.aria-posinset]="row.position"
            [attr.aria-setsize]="row.size"
            [attr.aria-expanded]="
              row.node.children?.length ? row.expanded : null
            "
            [attr.aria-selected]="selectedId() === row.node.id"
            [attr.aria-disabled]="
              disabled() ||
              row.node.disabled ||
              (leafOnly() && !!row.node.children?.length)
            "
            [attr.tabindex]="tabstop() === row.node.id ? 0 : -1"
            (focus)="focused.set(row.node.id)"
            (click)="choose(row)"
            (keydown)="key($event, row)"
          >
            <span
              class="atlas-tree-disclosure"
              aria-hidden="true"
              (click)="$event.stopPropagation(); toggle(row)"
              >{{
                row.node.children?.length ? (row.expanded ? "▾" : "▸") : "·"
              }}</span
            >
            <span class="atlas-tree-label"
              ><strong>{{ row.node.label }}</strong>
              @if (row.node.description) {
                <small>{{ row.node.description }}</small>
              }
            </span>
            @if (selectedId() === row.node.id) {
              <span aria-hidden="true">✓</span>
            }
          </button>
        }
      }
    </div>
    @if (loading()) {
      <p class="atlas-options-empty" role="status">Loading hierarchy…</p>
    } @else if (error()) {
      <div class="atlas-options-empty">
        <p role="alert">{{ error() }}</p>
        <button type="button" (click)="retry.emit()">Retry</button>
      </div>
    } @else if (!visible().length) {
      <p class="atlas-options-empty" role="status">No matching nodes.</p>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTree, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-tree",
                    imports: [AtlasInput],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (filterable()) {
      <input
        atlasInput
        type="search"
        [attr.aria-label]="'Search ' + label()"
        placeholder="Search hierarchy…"
        [value]="query()"
        (input)="query.set($any($event.target).value)"
      />
    }
    <div
      class="atlas-tree"
      role="tree"
      [attr.aria-label]="label()"
      [attr.aria-busy]="loading()"
    >
      @if (!loading() && !error()) {
        @for (row of visible(); track row.node.id) {
          <button
            type="button"
            role="treeitem"
            class="atlas-tree-row"
            [style.--atlas-tree-depth]="row.level - 1"
            [attr.aria-level]="row.level"
            [attr.aria-posinset]="row.position"
            [attr.aria-setsize]="row.size"
            [attr.aria-expanded]="
              row.node.children?.length ? row.expanded : null
            "
            [attr.aria-selected]="selectedId() === row.node.id"
            [attr.aria-disabled]="
              disabled() ||
              row.node.disabled ||
              (leafOnly() && !!row.node.children?.length)
            "
            [attr.tabindex]="tabstop() === row.node.id ? 0 : -1"
            (focus)="focused.set(row.node.id)"
            (click)="choose(row)"
            (keydown)="key($event, row)"
          >
            <span
              class="atlas-tree-disclosure"
              aria-hidden="true"
              (click)="$event.stopPropagation(); toggle(row)"
              >{{
                row.node.children?.length ? (row.expanded ? "▾" : "▸") : "·"
              }}</span
            >
            <span class="atlas-tree-label"
              ><strong>{{ row.node.label }}</strong>
              @if (row.node.description) {
                <small>{{ row.node.description }}</small>
              }
            </span>
            @if (selectedId() === row.node.id) {
              <span aria-hidden="true">✓</span>
            }
          </button>
        }
      }
    </div>
    @if (loading()) {
      <p class="atlas-options-empty" role="status">Loading hierarchy…</p>
    } @else if (error()) {
      <div class="atlas-options-empty">
        <p role="alert">{{ error() }}</p>
        <button type="button" (click)="retry.emit()">Retry</button>
      </div>
    } @else if (!visible().length) {
      <p class="atlas-options-empty" role="status">No matching nodes.</p>
    }
  `,
                }]
        }], propDecorators: { nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: false }] }], leafOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "leafOnly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], retry: [{ type: i0.Output, args: ["retry"] }], selectedId: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedId", required: false }] }, { type: i0.Output, args: ["selectedIdChange"] }], expandedIds: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandedIds", required: false }] }, { type: i0.Output, args: ["expandedIdsChange"] }], nodeSelected: [{ type: i0.Output, args: ["nodeSelected"] }] } });
class AtlasTreeSelect {
    nodes = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    label = input("Choose a node", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    placeholder = input("Choose a node…", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    controlId = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    leafOnly = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "leafOnly" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    touched = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    touchedChange = output();
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    error = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    retry = output();
    open = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    selected = computed(() => findTreeNode(this.nodes(), this.value()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    trigger = viewChild("trigger", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    invert = (value) => !value;
    focus() {
        this.trigger()?.nativeElement.focus();
    }
    close(event) {
        event?.stopPropagation();
        this.open.set(false);
        this.touchedChange.emit(true);
        this.focus();
    }
    commit(node) {
        if (this.disabled() || this.readonly())
            return;
        this.value.set(node.id);
        this.close();
    }
    clear() {
        if (this.disabled() || this.readonly())
            return;
        this.value.set(null);
        this.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTreeSelect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTreeSelect, isStandalone: true, selector: "atlas-tree-select", inputs: { nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null }, leafOnly: { classPropertyName: "leafOnly", publicName: "leafOnly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touchedChange: "touchedChange", retry: "retry" }, host: { listeners: { "focusout": "touchedChange.emit(true)" } }, viewQueries: [{ propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <button
      #trigger
      type="button"
      class="atlas-tree-select-trigger atlas-input"
      [id]="controlId()"
      [disabled]="disabled()"
      [attr.aria-label]="label()"
      [attr.aria-expanded]="open()"
      [attr.aria-invalid]="invalid()"
      [attr.aria-describedby]="describedBy()"
      (click)="open.update(invert)"
    >
      {{ selected()?.label || placeholder() }} <span aria-hidden="true">▾</span>
    </button>
    @if (open()) {
      <div class="atlas-tree-select-panel" (keydown.escape)="close($event)">
        <atlas-tree
          [nodes]="nodes()"
          [label]="label()"
          [selectedId]="value()"
          [leafOnly]="leafOnly()"
          [disabled]="disabled()"
          [readonly]="readonly()"
          [loading]="loading()"
          [error]="error()"
          (retry)="retry.emit()"
          (nodeSelected)="commit($event)"
        />
        <div class="atlas-tree-select-actions">
          <button
            type="button"
            [disabled]="disabled() || readonly() || !value()"
            (click)="clear()"
          >
            Clear selection</button
          ><button type="button" (click)="close()">Done</button>
        </div>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "component", type: AtlasTree, selector: "atlas-tree", inputs: ["nodes", "label", "filterable", "leafOnly", "disabled", "readonly", "loading", "error", "selectedId", "expandedIds"], outputs: ["retry", "selectedIdChange", "expandedIdsChange", "nodeSelected"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTreeSelect, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-tree-select",
                    imports: [AtlasTree],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { "(focusout)": "touchedChange.emit(true)" },
                    template: `
    <button
      #trigger
      type="button"
      class="atlas-tree-select-trigger atlas-input"
      [id]="controlId()"
      [disabled]="disabled()"
      [attr.aria-label]="label()"
      [attr.aria-expanded]="open()"
      [attr.aria-invalid]="invalid()"
      [attr.aria-describedby]="describedBy()"
      (click)="open.update(invert)"
    >
      {{ selected()?.label || placeholder() }} <span aria-hidden="true">▾</span>
    </button>
    @if (open()) {
      <div class="atlas-tree-select-panel" (keydown.escape)="close($event)">
        <atlas-tree
          [nodes]="nodes()"
          [label]="label()"
          [selectedId]="value()"
          [leafOnly]="leafOnly()"
          [disabled]="disabled()"
          [readonly]="readonly()"
          [loading]="loading()"
          [error]="error()"
          (retry)="retry.emit()"
          (nodeSelected)="commit($event)"
        />
        <div class="atlas-tree-select-actions">
          <button
            type="button"
            [disabled]="disabled() || readonly() || !value()"
            (click)="clear()"
          >
            Clear selection</button
          ><button type="button" (click)="close()">Done</button>
        </div>
      </div>
    }
  `,
                }]
        }], propDecorators: { nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], leafOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "leafOnly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }], touchedChange: [{ type: i0.Output, args: ["touchedChange"] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], retry: [{ type: i0.Output, args: ["retry"] }], trigger: [{ type: i0.ViewChild, args: ["trigger", { isSignal: true }] }] } });

function validateEditRow(row, columns) {
    const errors = {};
    for (const column of columns) {
        if (column.readonly)
            continue;
        const value = row[column.key];
        if (value == null || String(value).trim() === "") {
            if (column.required)
                errors[column.key] = `${column.label} is required.`;
            continue;
        }
        if (column.type === "number") {
            const number = Number(value);
            if (!Number.isFinite(number))
                errors[column.key] = `${column.label} must be a number.`;
            else if (column.min !== undefined && number < column.min)
                errors[column.key] = `${column.label} must be at least ${column.min}.`;
            else if (column.max !== undefined && number > column.max)
                errors[column.key] = `${column.label} must be at most ${column.max}.`;
            else if (column.step &&
                Math.abs((number - (column.min ?? 0)) / column.step -
                    Math.round((number - (column.min ?? 0)) / column.step)) > 1e-7)
                errors[column.key] =
                    `${column.label} must use steps of ${column.step}.`;
        }
        if (column.type === "select" &&
            !column.options?.some((option) => option.value === value && !option.disabled))
            errors[column.key] = `Choose an available ${column.label.toLowerCase()}.`;
    }
    return errors;
}
/** Replaces an existing row by stable key. Never mutates the source collection. */
function replaceEditedRow(rows, draft, key) {
    if (!rows.some((row) => row[key] === draft[key]))
        throw new Error("The edited row no longer exists. Cancel and reload the records.");
    return rows.map((row) => row[key] === draft[key] ? structuredClone(draft) : row);
}

let gridSequence$1 = 0;
class AtlasEditableGrid {
    rows = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    draft = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "draft" }] : /* istanbul ignore next */ []));
    columns = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    keyField = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "keyField" }] : /* istanbul ignore next */ []));
    label = input("Editable records", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    removable = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removable" }] : /* istanbul ignore next */ []));
    removeRequested = output();
    rowApplied = output();
    attempted = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "attempted" }] : /* istanbul ignore next */ []));
    notice = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "notice" }] : /* istanbul ignore next */ []));
    errors = computed(() => this.attempted() && this.draft()
        ? validateEditRow(this.draft(), this.columns())
        : {}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
    host = inject(ElementRef);
    id = `atlas-edit-${++gridSequence$1}`;
    origin;
    editingKey = "";
    errorId(key) {
        return `${this.id}-${key}`;
    }
    isEditing(row) {
        return (!!this.draft() && row[this.keyField()] === this.draft()[this.keyField()]);
    }
    display(row, column) {
        return column.format
            ? column.format(row)
            : (column.options?.find((option) => option.value === row[column.key])
                ?.label ?? String(row[column.key] ?? ""));
    }
    begin(row, event) {
        if (this.disabled() || this.draft())
            return;
        this.origin = event?.currentTarget;
        this.editingKey = String(row[this.keyField()]);
        requestAnimationFrame(() => this.host.nativeElement
            .querySelector("input:not(:disabled), select:not(:disabled)")
            ?.focus());
        this.draft.set(structuredClone(row));
        this.attempted.set(false);
        this.notice.set("");
    }
    edit(column, value) {
        if (this.disabled() || column.readonly || !this.draft())
            return;
        this.draft.update((row) => ({
            ...row,
            [column.key]: column.type === "number"
                ? value === ""
                    ? null
                    : Number(value)
                : value,
        }));
        this.notice.set("");
    }
    apply() {
        if (this.disabled() || !this.draft())
            return;
        this.attempted.set(true);
        if (Object.keys(validateEditRow(this.draft(), this.columns())).length) {
            this.notice.set("Please correct the row before applying it.");
            return;
        }
        try {
            const row = this.draft();
            this.rows.set(replaceEditedRow(this.rows(), row, this.keyField()));
            this.draft.set(null);
            this.rowApplied.emit(row);
            this.notice.set("Row applied to the draft. Save the order to commit it.");
            this.restore();
        }
        catch (error) {
            this.notice.set(error.message);
        }
    }
    cancel() {
        if (this.disabled())
            return;
        this.draft.set(null);
        this.attempted.set(false);
        this.notice.set("Row changes cancelled.");
        this.restore();
    }
    restore() {
        requestAnimationFrame(() => {
            if (this.origin?.isConnected)
                this.origin.focus();
            else {
                const buttons = [
                    ...this.host.nativeElement.querySelectorAll("button[data-edit-key]"),
                ];
                (buttons.find((button) => button.dataset["editKey"] === this.editingKey) ?? buttons[0])?.focus();
            }
        });
    }
    key(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            this.cancel();
        }
        if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
            event.preventDefault();
            this.apply();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasEditableGrid, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasEditableGrid, isStandalone: true, selector: "atlas-editable-grid", inputs: { rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, draft: { classPropertyName: "draft", publicName: "draft", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, keyField: { classPropertyName: "keyField", publicName: "keyField", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { rows: "rowsChange", draft: "draftChange", removeRequested: "removeRequested", rowApplied: "rowApplied" }, ngImport: i0, template: `
    <div class="atlas-edit-grid-scroll">
      <table
        class="atlas-table atlas-edit-grid"
        [attr.aria-label]="label()"
        [attr.aria-busy]="disabled()"
      >
        <thead>
          <tr>
            @for (column of columns(); track column.key) {
              <th scope="col">{{ column.label }}</th>
            }
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          @for (row of rows(); track row[keyField()]) {
            <tr [class.selected]="isEditing(row)">
              @for (column of columns(); track column.key) {
                <td [attr.data-label]="column.label">
                  @if (isEditing(row) && !column.readonly) {
                    @if (column.type === "select") {
                      <select
                        atlasInput
                        [attr.aria-label]="
                          column.label + ' for ' + row[keyField()]
                        "
                        [value]="draft()![column.key] ?? ''"
                        [disabled]="disabled()"
                        [attr.aria-invalid]="!!errors()[column.key]"
                        [attr.aria-describedby]="
                          errors()[column.key] ? errorId(column.key) : null
                        "
                        (change)="edit(column, $any($event.target).value)"
                        (keydown)="key($event)"
                      >
                        <option value="">Choose…</option>
                        @for (
                          option of column.options || [];
                          track option.value
                        ) {
                          <option
                            [value]="option.value"
                            [disabled]="option.disabled"
                          >
                            {{ option.label }}
                          </option>
                        }
                      </select>
                    } @else {
                      <input
                        atlasInput
                        [type]="column.type === 'number' ? 'number' : 'text'"
                        [attr.aria-label]="
                          column.label + ' for ' + row[keyField()]
                        "
                        [value]="draft()![column.key] ?? ''"
                        [disabled]="disabled()"
                        [min]="column.min ?? null"
                        [max]="column.max ?? null"
                        [step]="column.step ?? 'any'"
                        [attr.aria-invalid]="!!errors()[column.key]"
                        [attr.aria-describedby]="
                          errors()[column.key] ? errorId(column.key) : null
                        "
                        (input)="edit(column, $any($event.target).value)"
                        (keydown)="key($event)"
                      />
                    }
                    @if (errors()[column.key]; as error) {
                      <small
                        class="atlas-edit-error"
                        [id]="errorId(column.key)"
                        >{{ error }}</small
                      >
                    }
                  } @else {
                    {{ display(isEditing(row) ? draft()! : row, column) }}
                  }
                </td>
              }
              <td class="atlas-edit-actions">
                @if (isEditing(row)) {
                  <button
                    atlasButton
                    type="button"
                    [disabled]="disabled()"
                    (click)="apply()"
                  >
                    Apply row</button
                  ><button
                    atlasButton
                    type="button"
                    [disabled]="disabled()"
                    (click)="cancel()"
                  >
                    Cancel row
                  </button>
                } @else {
                  <button
                    atlasButton
                    type="button"
                    [attr.aria-label]="'Edit ' + row[keyField()]"
                    [attr.data-edit-key]="row[keyField()]"
                    [disabled]="disabled() || !!draft()"
                    (click)="begin(row, $event)"
                  >
                    Edit
                  </button>
                  @if (removable()) {
                    <button
                      atlasButton
                      type="button"
                      [attr.aria-label]="'Remove ' + row[keyField()]"
                      [disabled]="disabled() || !!draft()"
                      (click)="removeRequested.emit(row)"
                    >
                      Remove
                    </button>
                  }
                }
              </td>
            </tr>
          } @empty {
            <tr>
              <td
                [attr.colspan]="columns().length + 1"
                class="atlas-table-empty"
              >
                No line items. Add a line to begin.
              </td>
            </tr>
          }
        </tbody>
      </table>
    </div>
    <p class="atlas-edit-status" role="status">
      {{
        notice() ||
          (draft()
            ? "Editing a row. Apply keeps changes in the order draft; Cancel restores the row."
            : "Select Edit to change a row.")
      }}
    </p>
  `, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasEditableGrid, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-editable-grid",
                    imports: [AtlasButton, AtlasInput],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <div class="atlas-edit-grid-scroll">
      <table
        class="atlas-table atlas-edit-grid"
        [attr.aria-label]="label()"
        [attr.aria-busy]="disabled()"
      >
        <thead>
          <tr>
            @for (column of columns(); track column.key) {
              <th scope="col">{{ column.label }}</th>
            }
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          @for (row of rows(); track row[keyField()]) {
            <tr [class.selected]="isEditing(row)">
              @for (column of columns(); track column.key) {
                <td [attr.data-label]="column.label">
                  @if (isEditing(row) && !column.readonly) {
                    @if (column.type === "select") {
                      <select
                        atlasInput
                        [attr.aria-label]="
                          column.label + ' for ' + row[keyField()]
                        "
                        [value]="draft()![column.key] ?? ''"
                        [disabled]="disabled()"
                        [attr.aria-invalid]="!!errors()[column.key]"
                        [attr.aria-describedby]="
                          errors()[column.key] ? errorId(column.key) : null
                        "
                        (change)="edit(column, $any($event.target).value)"
                        (keydown)="key($event)"
                      >
                        <option value="">Choose…</option>
                        @for (
                          option of column.options || [];
                          track option.value
                        ) {
                          <option
                            [value]="option.value"
                            [disabled]="option.disabled"
                          >
                            {{ option.label }}
                          </option>
                        }
                      </select>
                    } @else {
                      <input
                        atlasInput
                        [type]="column.type === 'number' ? 'number' : 'text'"
                        [attr.aria-label]="
                          column.label + ' for ' + row[keyField()]
                        "
                        [value]="draft()![column.key] ?? ''"
                        [disabled]="disabled()"
                        [min]="column.min ?? null"
                        [max]="column.max ?? null"
                        [step]="column.step ?? 'any'"
                        [attr.aria-invalid]="!!errors()[column.key]"
                        [attr.aria-describedby]="
                          errors()[column.key] ? errorId(column.key) : null
                        "
                        (input)="edit(column, $any($event.target).value)"
                        (keydown)="key($event)"
                      />
                    }
                    @if (errors()[column.key]; as error) {
                      <small
                        class="atlas-edit-error"
                        [id]="errorId(column.key)"
                        >{{ error }}</small
                      >
                    }
                  } @else {
                    {{ display(isEditing(row) ? draft()! : row, column) }}
                  }
                </td>
              }
              <td class="atlas-edit-actions">
                @if (isEditing(row)) {
                  <button
                    atlasButton
                    type="button"
                    [disabled]="disabled()"
                    (click)="apply()"
                  >
                    Apply row</button
                  ><button
                    atlasButton
                    type="button"
                    [disabled]="disabled()"
                    (click)="cancel()"
                  >
                    Cancel row
                  </button>
                } @else {
                  <button
                    atlasButton
                    type="button"
                    [attr.aria-label]="'Edit ' + row[keyField()]"
                    [attr.data-edit-key]="row[keyField()]"
                    [disabled]="disabled() || !!draft()"
                    (click)="begin(row, $event)"
                  >
                    Edit
                  </button>
                  @if (removable()) {
                    <button
                      atlasButton
                      type="button"
                      [attr.aria-label]="'Remove ' + row[keyField()]"
                      [disabled]="disabled() || !!draft()"
                      (click)="removeRequested.emit(row)"
                    >
                      Remove
                    </button>
                  }
                }
              </td>
            </tr>
          } @empty {
            <tr>
              <td
                [attr.colspan]="columns().length + 1"
                class="atlas-table-empty"
              >
                No line items. Add a line to begin.
              </td>
            </tr>
          }
        </tbody>
      </table>
    </div>
    <p class="atlas-edit-status" role="status">
      {{
        notice() ||
          (draft()
            ? "Editing a row. Apply keeps changes in the order draft; Cancel restores the row."
            : "Select Edit to change a row.")
      }}
    </p>
  `,
                }]
        }], propDecorators: { rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }, { type: i0.Output, args: ["rowsChange"] }], draft: [{ type: i0.Input, args: [{ isSignal: true, alias: "draft", required: false }] }, { type: i0.Output, args: ["draftChange"] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], keyField: [{ type: i0.Input, args: [{ isSignal: true, alias: "keyField", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], removable: [{ type: i0.Input, args: [{ isSignal: true, alias: "removable", required: false }] }], removeRequested: [{ type: i0.Output, args: ["removeRequested"] }], rowApplied: [{ type: i0.Output, args: ["rowApplied"] }] } });

/**
 * Reusable continuous-cell navigation for a native table; owns no data or save state.
 * Use one tbody, stable columns, and an immediate overflow:auto wrapper.
 * Mark one input/button or AtlasLookup host per editable td with data-sheet-editor.
 * For lookups use arrowNavigation="grid" and clearable=false.
 * Integration guide and complete example: docs/controls/DATASHEET-INTEGRATION.md.
 */
class AtlasDatasheet {
    element = inject(ElementRef);
    navigate(event) {
        const target = event.target;
        if (event.defaultPrevented ||
            event.isComposing ||
            event.altKey ||
            target.closest("[popover]"))
            return;
        const table = this.element.nativeElement;
        const cells = Array.from(table.querySelectorAll("[data-sheet-editor]"))
            .map((el) => el.matches("input,button,select,textarea")
            ? el
            : el.querySelector("[role=combobox]"))
            .filter((el) => el && !el.matches(":disabled") && !el.closest("[hidden]"));
        const index = cells.indexOf(target);
        if (index < 0)
            return;
        let next;
        if (event.key === "Tab")
            next = cells[index + (event.shiftKey ? -1 : 1)];
        else if ((event.key === "ArrowLeft" || event.key === "ArrowRight") &&
            !event.ctrlKey &&
            !event.metaKey &&
            !event.shiftKey) {
            const row = target.closest("tr");
            const candidate = cells[index + (event.key === "ArrowLeft" ? -1 : 1)];
            if (candidate?.closest("tr") === row)
                next = candidate;
            event.preventDefault(); // Keep focus at the row boundary; Tab wraps rows.
        }
        else if ((event.ctrlKey || event.metaKey) && event.key === "Home")
            next = cells[0];
        else if ((event.ctrlKey || event.metaKey) && event.key === "End")
            next = cells.at(-1);
        else if (event.key === "ArrowUp" ||
            event.key === "ArrowDown" ||
            (event.key === "Enter" && target.tagName === "INPUT")) {
            const row = target.closest("tr");
            const column = target.closest("td").cellIndex;
            const rows = Array.from(table.tBodies[0].rows);
            const delta = event.key === "ArrowUp" || (event.key === "Enter" && event.shiftKey)
                ? -1
                : 1;
            for (let r = rows.indexOf(row) + delta; r >= 0 && r < rows.length; r += delta) {
                next = cells.find((el) => el.closest("td") === rows[r].cells[column]);
                if (next)
                    break;
            }
            event.preventDefault(); // Prevent numeric spinners even at a row boundary.
        }
        if (next) {
            event.preventDefault();
            next.focus({ preventScroll: true });
            // Only scroll the datasheet region; never scroll the desktop canvas.
            const scroll = table.parentElement;
            const a = next.getBoundingClientRect(), b = scroll.getBoundingClientRect();
            if (a.bottom > b.bottom)
                scroll.scrollTop += a.bottom - b.bottom;
            if (a.top < b.top + 32)
                scroll.scrollTop -= b.top + 32 - a.top;
            if (a.right > b.right)
                scroll.scrollLeft += a.right - b.right;
            if (a.left < b.left)
                scroll.scrollLeft -= b.left - a.left;
            if (next instanceof HTMLInputElement && next.type !== "number")
                next.select();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDatasheet, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.7", type: AtlasDatasheet, isStandalone: true, selector: "table[atlasDatasheet]", host: { listeners: { "keydown": "navigate($event)" }, classAttribute: "atlas-datasheet" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDatasheet, decorators: [{
            type: Directive,
            args: [{
                    selector: "table[atlasDatasheet]",
                    host: { class: "atlas-datasheet", "(keydown)": "navigate($event)" },
                }]
        }] });

class AtlasRecordNavigator {
    records = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "records" }] : /* istanbul ignore next */ []));
    currentId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentId" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    navigate = output();
    create = output();
    selectRecord(event) {
        const select = event.target;
        const id = select.value;
        select.value = this.currentId();
        this.request(id);
    }
    index() {
        return this.records().findIndex((r) => r.id === this.currentId());
    }
    choose(index) {
        const record = this.records()[index];
        if (record)
            this.request(record.id);
    }
    request(id) {
        if (!this.disabled() &&
            id !== this.currentId() &&
            this.records().some((r) => r.id === id))
            this.navigate.emit(id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRecordNavigator, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasRecordNavigator, isStandalone: true, selector: "atlas-record-navigator", inputs: { records: { classPropertyName: "records", publicName: "records", isSignal: true, isRequired: true, transformFunction: null }, currentId: { classPropertyName: "currentId", publicName: "currentId", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { navigate: "navigate", create: "create" }, ngImport: i0, template: `<nav
    class="atlas-record-navigation"
    aria-label="Record navigation"
  >
    <button
      atlasButton
      [disabled]="disabled() || index() <= 0"
      (click)="choose(0)"
    >
      First
    </button>
    <button
      atlasButton
      [disabled]="disabled() || index() <= 0"
      (click)="choose(index() - 1)"
    >
      Previous
    </button>
    <span aria-live="polite">{{ index() + 1 }} of {{ records().length }}</span>
    <button
      atlasButton
      [disabled]="disabled() || index() >= records().length - 1"
      (click)="choose(index() + 1)"
    >
      Next
    </button>
    <button
      atlasButton
      [disabled]="disabled() || index() >= records().length - 1"
      (click)="choose(records().length - 1)"
    >
      Last
    </button>
    <label
      >Find record
      <select
        [disabled]="disabled()"

        (change)="selectRecord($event)"
      >
        @for (record of records(); track record.id) {
          <option [value]="record.id" [selected]="record.id === currentId()">{{ record.label }}</option>
        }
      </select></label
    ><button atlasButton [disabled]="disabled()" (click)="create.emit()">
      New record
    </button>
  </nav>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRecordNavigator, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-record-navigator",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<nav
    class="atlas-record-navigation"
    aria-label="Record navigation"
  >
    <button
      atlasButton
      [disabled]="disabled() || index() <= 0"
      (click)="choose(0)"
    >
      First
    </button>
    <button
      atlasButton
      [disabled]="disabled() || index() <= 0"
      (click)="choose(index() - 1)"
    >
      Previous
    </button>
    <span aria-live="polite">{{ index() + 1 }} of {{ records().length }}</span>
    <button
      atlasButton
      [disabled]="disabled() || index() >= records().length - 1"
      (click)="choose(index() + 1)"
    >
      Next
    </button>
    <button
      atlasButton
      [disabled]="disabled() || index() >= records().length - 1"
      (click)="choose(records().length - 1)"
    >
      Last
    </button>
    <label
      >Find record
      <select
        [disabled]="disabled()"

        (change)="selectRecord($event)"
      >
        @for (record of records(); track record.id) {
          <option [value]="record.id" [selected]="record.id === currentId()">{{ record.label }}</option>
        }
      </select></label
    ><button atlasButton [disabled]="disabled()" (click)="create.emit()">
      New record
    </button>
  </nav>`,
                }]
        }], propDecorators: { records: [{ type: i0.Input, args: [{ isSignal: true, alias: "records", required: true }] }], currentId: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentId", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], navigate: [{ type: i0.Output, args: ["navigate"] }], create: [{ type: i0.Output, args: ["create"] }] } });
class AtlasValidationNavigator {
    errors = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
    activate = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasValidationNavigator, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasValidationNavigator, isStandalone: true, selector: "atlas-validation-navigator", inputs: { errors: { classPropertyName: "errors", publicName: "errors", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { activate: "activate" }, ngImport: i0, template: `@if (errors().length) {
    <section class="atlas-edit-alert" aria-label="Validation errors">
      <p role="alert">{{ errors().length }} fields need attention</p>
      <ul>
        @for (error of errors(); track error.id) {
          <li>
            <button type="button" (click)="activate.emit(error)">
              {{ error.message }}
            </button>
          </li>
        }
      </ul>
    </section>
  }`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasValidationNavigator, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-validation-navigator",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `@if (errors().length) {
    <section class="atlas-edit-alert" aria-label="Validation errors">
      <p role="alert">{{ errors().length }} fields need attention</p>
      <ul>
        @for (error of errors(); track error.id) {
          <li>
            <button type="button" (click)="activate.emit(error)">
              {{ error.message }}
            </button>
          </li>
        }
      </ul>
    </section>
  }`,
                }]
        }], propDecorators: { errors: [{ type: i0.Input, args: [{ isSignal: true, alias: "errors", required: true }] }], activate: [{ type: i0.Output, args: ["activate"] }] } });
/** Consumer chooses when to clear dependent state; this helper never mutates records. */
function dependentRecords(rows, parent, parentKey) {
    return parent === null
        ? []
        : rows.filter((row) => Object.is(parentKey(row), parent));
}

class AtlasPropertySheet {
    fields = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []));
    value = model({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    groups = computed(() => [
        ...new Set(this.fields().map((f) => f.group)),
    ], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []));
    set(key, value) {
        if (!this.disabled())
            this.value.update((current) => ({ ...current, [key]: value }));
    }
    edit(field, event) {
        const el = event.target;
        this.set(field.key, field.type === "number"
            ? Number.isFinite(el.valueAsNumber)
                ? el.valueAsNumber
                : null
            : el.value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPropertySheet, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasPropertySheet, isStandalone: true, selector: "atlas-property-sheet", inputs: { fields: { classPropertyName: "fields", publicName: "fields", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, ngImport: i0, template: `<div class="atlas-property-sheet">
    @for (group of groups(); track group) {
      <fieldset>
        <legend>{{ group }}</legend>
        @for (field of fields(); track field.key) {
          @if (field.group === group) {
            <label class="atlas-property-row"
              ><span>{{ field.label }}</span>
              @if (field.readonly) {
                <output>{{ value()[field.key] }}</output>
              } @else {
                @switch (field.type) {
                  @case ("boolean") {
                    <input
                      type="checkbox"
                      [checked]="value()[field.key]"
                      [disabled]="disabled()"
                      (change)="set(field.key, $any($event.target).checked)"
                    />
                  }
                  @case ("select") {
                    <select
                      atlasInput
                      [disabled]="disabled()"
                      (change)="set(field.key, $any($event.target).value)"
                    >
                      @for (option of field.options; track option.value) {
                        <option
                          [value]="option.value"
                          [selected]="option.value === value()[field.key]"
                        >
                          {{ option.label }}
                        </option>
                      }
                    </select>
                  }
                  @default {
                    <input
                      atlasInput
                      [type]="field.type"
                      [value]="value()[field.key] ?? ''"
                      [min]="field.min ?? null"
                      [max]="field.max ?? null"
                      [step]="field.step ?? 'any'"
                      [disabled]="disabled()"
                      (input)="edit(field, $event)"
                    />
                  }
                }
              }
              @if (field.hint) {
                <small>{{ field.hint }}</small>
              }
            </label>
          }
        }
      </fieldset>
    }
  </div>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPropertySheet, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-property-sheet",
                    imports: [AtlasInput],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<div class="atlas-property-sheet">
    @for (group of groups(); track group) {
      <fieldset>
        <legend>{{ group }}</legend>
        @for (field of fields(); track field.key) {
          @if (field.group === group) {
            <label class="atlas-property-row"
              ><span>{{ field.label }}</span>
              @if (field.readonly) {
                <output>{{ value()[field.key] }}</output>
              } @else {
                @switch (field.type) {
                  @case ("boolean") {
                    <input
                      type="checkbox"
                      [checked]="value()[field.key]"
                      [disabled]="disabled()"
                      (change)="set(field.key, $any($event.target).checked)"
                    />
                  }
                  @case ("select") {
                    <select
                      atlasInput
                      [disabled]="disabled()"
                      (change)="set(field.key, $any($event.target).value)"
                    >
                      @for (option of field.options; track option.value) {
                        <option
                          [value]="option.value"
                          [selected]="option.value === value()[field.key]"
                        >
                          {{ option.label }}
                        </option>
                      }
                    </select>
                  }
                  @default {
                    <input
                      atlasInput
                      [type]="field.type"
                      [value]="value()[field.key] ?? ''"
                      [min]="field.min ?? null"
                      [max]="field.max ?? null"
                      [step]="field.step ?? 'any'"
                      [disabled]="disabled()"
                      (input)="edit(field, $event)"
                    />
                  }
                }
              }
              @if (field.hint) {
                <small>{{ field.hint }}</small>
              }
            </label>
          }
        }
      </fieldset>
    }
  </div>`,
                }]
        }], propDecorators: { fields: [{ type: i0.Input, args: [{ isSignal: true, alias: "fields", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });
class AtlasTotalsPanel {
    lines = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "lines" }] : /* istanbul ignore next */ []));
    currency = input("USD", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currency" }] : /* istanbul ignore next */ []));
    locale = input("en-US", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "locale" }] : /* istanbul ignore next */ []));
    label = input("Totals", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    format(value) {
        return new Intl.NumberFormat(this.locale(), {
            style: "currency",
            currency: this.currency(),
        }).format(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTotalsPanel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTotalsPanel, isStandalone: true, selector: "atlas-totals-panel", inputs: { lines: { classPropertyName: "lines", publicName: "lines", isSignal: true, isRequired: true, transformFunction: null }, currency: { classPropertyName: "currency", publicName: "currency", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<dl class="atlas-totals-panel" [attr.aria-label]="label()">
    @for (line of lines(); track line.id) {
      <div [class.atlas-total-emphasis]="line.emphasis">
        <dt>{{ line.label }}</dt>
        <dd>{{ format(line.value) }}</dd>
      </div>
    }
  </dl>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTotalsPanel, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-totals-panel",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<dl class="atlas-totals-panel" [attr.aria-label]="label()">
    @for (line of lines(); track line.id) {
      <div [class.atlas-total-emphasis]="line.emphasis">
        <dt>{{ line.label }}</dt>
        <dd>{{ format(line.value) }}</dd>
      </div>
    }
  </dl>`,
                }]
        }], propDecorators: { lines: [{ type: i0.Input, args: [{ isSignal: true, alias: "lines", required: true }] }], currency: [{ type: i0.Input, args: [{ isSignal: true, alias: "currency", required: false }] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });
class AtlasActivityTimeline {
    events = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    label = input("Activity", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    date(value) {
        const time = new Date(value);
        return Number.isNaN(time.valueOf()) ? value : time.toLocaleString();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasActivityTimeline, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasActivityTimeline, isStandalone: true, selector: "atlas-activity-timeline", inputs: { events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<ol class="atlas-activity-timeline" [attr.aria-label]="label()">
    @for (event of events(); track event.id) {
      <li>
        <div>
          <strong>{{ event.title }}</strong
          ><span>{{ event.kind }}</span>
        </div>
        <p>{{ event.detail }}</p>
        <small
          >{{ event.actor }} ·
          <time [attr.datetime]="event.timestamp">{{
            date(event.timestamp)
          }}</time></small
        >
      </li>
    } @empty {
      <li>No activity yet.</li>
    }
  </ol>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasActivityTimeline, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-activity-timeline",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<ol class="atlas-activity-timeline" [attr.aria-label]="label()">
    @for (event of events(); track event.id) {
      <li>
        <div>
          <strong>{{ event.title }}</strong
          ><span>{{ event.kind }}</span>
        </div>
        <p>{{ event.detail }}</p>
        <small
          >{{ event.actor }} ·
          <time [attr.datetime]="event.timestamp">{{
            date(event.timestamp)
          }}</time></small
        >
      </li>
    } @empty {
      <li>No activity yet.</li>
    }
  </ol>`,
                }]
        }], propDecorators: { events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });
class AtlasAttachmentList {
    files = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "files" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    accept = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []));
    add = output();
    preview = output();
    retry = output();
    remove = output();
    pick(event) {
        const el = event.target;
        if (!this.disabled() && el.files?.length)
            this.add.emit(Array.from(el.files));
        el.value = "";
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAttachmentList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasAttachmentList, isStandalone: true, selector: "atlas-attachment-list", inputs: { files: { classPropertyName: "files", publicName: "files", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { add: "add", preview: "preview", retry: "retry", remove: "remove" }, ngImport: i0, template: `<section class="atlas-attachment-list" aria-label="Attachments">
    <label class="atlas-file-picker"
      >Add files<input
        type="file"
        multiple
        [disabled]="disabled()"
        [accept]="accept()"
        (change)="pick($event)"
    /></label>
    <ul>
      @for (file of files(); track file.id) {
        <li>
          <div>
            <strong>{{ file.name }}</strong
            ><small
              >{{ (file.size / 1024).toFixed(1) }} KB · {{ file.status }}</small
            >
            @if (file.status === "uploading") {
              <progress
                max="100"
                [value]="file.progress"
                [attr.aria-label]="'Uploading ' + file.name"
              ></progress>
            }
            @if (file.error) {
              <span role="alert">{{ file.error }}</span>
            }
          </div>
          <div>
            @if (file.status === "ready") {
              <button
                atlasButton
                type="button"
                [disabled]="disabled()"
                (click)="preview.emit(file.id)"
              >
                Preview {{ file.name }}
              </button>
            }
            @if (file.status === "error") {
              <button
                atlasButton
                type="button"
                [disabled]="disabled()"
                (click)="retry.emit(file.id)"
              >
                Retry {{ file.name }}
              </button>
            }
            <button
              atlasButton
              type="button"
              [disabled]="disabled()"
              (click)="remove.emit(file.id)"
            >
              {{ file.status === "uploading" ? "Cancel" : "Remove" }}
              {{ file.name }}
            </button>
          </div>
        </li>
      } @empty {
        <li>No attachments. Choose files to get started.</li>
      }
    </ul>
  </section>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAttachmentList, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-attachment-list",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<section class="atlas-attachment-list" aria-label="Attachments">
    <label class="atlas-file-picker"
      >Add files<input
        type="file"
        multiple
        [disabled]="disabled()"
        [accept]="accept()"
        (change)="pick($event)"
    /></label>
    <ul>
      @for (file of files(); track file.id) {
        <li>
          <div>
            <strong>{{ file.name }}</strong
            ><small
              >{{ (file.size / 1024).toFixed(1) }} KB · {{ file.status }}</small
            >
            @if (file.status === "uploading") {
              <progress
                max="100"
                [value]="file.progress"
                [attr.aria-label]="'Uploading ' + file.name"
              ></progress>
            }
            @if (file.error) {
              <span role="alert">{{ file.error }}</span>
            }
          </div>
          <div>
            @if (file.status === "ready") {
              <button
                atlasButton
                type="button"
                [disabled]="disabled()"
                (click)="preview.emit(file.id)"
              >
                Preview {{ file.name }}
              </button>
            }
            @if (file.status === "error") {
              <button
                atlasButton
                type="button"
                [disabled]="disabled()"
                (click)="retry.emit(file.id)"
              >
                Retry {{ file.name }}
              </button>
            }
            <button
              atlasButton
              type="button"
              [disabled]="disabled()"
              (click)="remove.emit(file.id)"
            >
              {{ file.status === "uploading" ? "Cancel" : "Remove" }}
              {{ file.name }}
            </button>
          </div>
        </li>
      } @empty {
        <li>No attachments. Choose files to get started.</li>
      }
    </ul>
  </section>`,
                }]
        }], propDecorators: { files: [{ type: i0.Input, args: [{ isSignal: true, alias: "files", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], accept: [{ type: i0.Input, args: [{ isSignal: true, alias: "accept", required: false }] }], add: [{ type: i0.Output, args: ["add"] }], preview: [{ type: i0.Output, args: ["preview"] }], retry: [{ type: i0.Output, args: ["retry"] }], remove: [{ type: i0.Output, args: ["remove"] }] } });

function matchesFilterRules(row, rules) {
    return rules.every((rule) => {
        const value = row[rule.field];
        if (value === null || value === undefined)
            return false;
        if (rule.operator === "gte" || rule.operator === "lte") {
            if (!rule.value.trim() || !String(value).trim())
                return false;
            const n = Number(value), limit = Number(rule.value);
            return (Number.isFinite(n) &&
                Number.isFinite(limit) &&
                (rule.operator === "gte" ? n >= limit : n <= limit));
        }
        if (rule.operator === "equals" && typeof value === "number")
            return (!!rule.value.trim() &&
                Number.isFinite(value) &&
                Number.isFinite(Number(rule.value)) &&
                value === Number(rule.value));
        const actual = String(value).toLocaleLowerCase(), wanted = rule.value.toLocaleLowerCase();
        return rule.operator === "equals"
            ? actual === wanted
            : actual.includes(wanted);
    });
}
class AtlasFilterBuilder {
    fields = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []));
    rules = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rules" }] : /* istanbul ignore next */ []));
    views = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "views" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    saveRequested = output();
    deleteRequested = output();
    name = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    sequence = 0;
    operatorLabel(operator) {
        return {
            contains: "contains",
            equals: "is equal to",
            gte: "is at least",
            lte: "is at most",
        }[operator];
    }
    numeric(key) {
        return this.fields().find((f) => f.key === key)?.type === "number";
    }
    operators(key) {
        return this.numeric(key)
            ? ["equals", "gte", "lte"]
            : ["contains", "equals"];
    }
    patch(id, patch) {
        if (!this.disabled())
            this.rules.update((r) => r.map((rule) => (rule.id === id ? { ...rule, ...patch } : rule)));
    }
    field(id, key) {
        this.patch(id, { field: key, operator: this.operators(key)[0], value: "" });
    }
    add() {
        if (this.disabled() || !this.fields().length)
            return;
        let id;
        do {
            id = `filter-${++this.sequence}`;
        } while (this.rules().some((r) => r.id === id));
        const field = this.fields()[0].key;
        this.rules.update((r) => [
            ...r,
            { id, field, operator: this.operators(field)[0], value: "" },
        ]);
    }
    remove(id) {
        if (!this.disabled())
            this.rules.update((r) => r.filter((rule) => rule.id !== id));
    }
    copy(rules) {
        return structuredClone(rules);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasFilterBuilder, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasFilterBuilder, isStandalone: true, selector: "atlas-filter-builder", inputs: { fields: { classPropertyName: "fields", publicName: "fields", isSignal: true, isRequired: true, transformFunction: null }, rules: { classPropertyName: "rules", publicName: "rules", isSignal: true, isRequired: false, transformFunction: null }, views: { classPropertyName: "views", publicName: "views", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { rules: "rulesChange", saveRequested: "saveRequested", deleteRequested: "deleteRequested" }, ngImport: i0, template: `<section class="atlas-filter-builder" aria-label="Filter builder">
    <p>Match all conditions</p>
    @for (rule of rules(); track rule.id; let i = $index) {
      <div class="atlas-filter-rule">
        <select
          atlasInput
          [attr.aria-label]="'Field, filter ' + (i + 1)"
          [disabled]="disabled()"
          (change)="field(rule.id, $any($event.target).value)"
        >
          @for (f of fields(); track f.key) {
            <option [value]="f.key" [selected]="f.key === rule.field">
              {{ f.label }}
            </option>
          }</select
        ><select
          atlasInput
          [attr.aria-label]="'Operator, filter ' + (i + 1)"
          [disabled]="disabled()"
          (change)="patch(rule.id, { operator: $any($event.target).value })"
        >
          @for (op of operators(rule.field); track op) {
            <option [value]="op" [selected]="op === rule.operator">
              {{ operatorLabel(op) }}
            </option>
          }</select
        ><input
          atlasInput
          [attr.aria-label]="'Value, filter ' + (i + 1)"
          [type]="numeric(rule.field) ? 'number' : 'text'"
          [value]="rule.value"
          [disabled]="disabled()"
          (input)="patch(rule.id, { value: $any($event.target).value })"
        /><button
          atlasButton
          type="button"
          [disabled]="disabled()"
          [attr.aria-label]="'Remove filter ' + (i + 1)"
          (click)="remove(rule.id)"
        >
          Remove
        </button>
      </div>
    }
    <button
      atlasButton
      type="button"
      [disabled]="disabled() || !fields().length"
      (click)="add()"
    >
      Add condition</button
    ><button
      atlasButton
      type="button"
      [disabled]="disabled() || !rules().length"
      (click)="rules.set([])"
    >
      Clear filters
    </button>
    <div class="atlas-saved-views">
      <label
        >View name<input
          atlasInput
          [disabled]="disabled()"
          [value]="name()"
          (input)="name.set($any($event.target).value)" /></label
      ><button
        atlasButton
        type="button"
        [disabled]="disabled() || !name().trim()"
        (click)="saveRequested.emit(name().trim()); name.set('')"
      >
        Save current view
      </button>
      @for (view of views(); track view.id) {
        <button
          atlasButton
          type="button"
          [disabled]="disabled()"
          (click)="rules.set(copy(view.rules))"
        >
          Load {{ view.name }}</button
        ><button
          atlasButton
          type="button"
          [disabled]="disabled()"
          [attr.aria-label]="'Delete view ' + view.name"
          (click)="deleteRequested.emit(view.id)"
        >
          ×
        </button>
      }
    </div>
  </section>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasFilterBuilder, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-filter-builder",
                    imports: [AtlasButton, AtlasInput],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<section class="atlas-filter-builder" aria-label="Filter builder">
    <p>Match all conditions</p>
    @for (rule of rules(); track rule.id; let i = $index) {
      <div class="atlas-filter-rule">
        <select
          atlasInput
          [attr.aria-label]="'Field, filter ' + (i + 1)"
          [disabled]="disabled()"
          (change)="field(rule.id, $any($event.target).value)"
        >
          @for (f of fields(); track f.key) {
            <option [value]="f.key" [selected]="f.key === rule.field">
              {{ f.label }}
            </option>
          }</select
        ><select
          atlasInput
          [attr.aria-label]="'Operator, filter ' + (i + 1)"
          [disabled]="disabled()"
          (change)="patch(rule.id, { operator: $any($event.target).value })"
        >
          @for (op of operators(rule.field); track op) {
            <option [value]="op" [selected]="op === rule.operator">
              {{ operatorLabel(op) }}
            </option>
          }</select
        ><input
          atlasInput
          [attr.aria-label]="'Value, filter ' + (i + 1)"
          [type]="numeric(rule.field) ? 'number' : 'text'"
          [value]="rule.value"
          [disabled]="disabled()"
          (input)="patch(rule.id, { value: $any($event.target).value })"
        /><button
          atlasButton
          type="button"
          [disabled]="disabled()"
          [attr.aria-label]="'Remove filter ' + (i + 1)"
          (click)="remove(rule.id)"
        >
          Remove
        </button>
      </div>
    }
    <button
      atlasButton
      type="button"
      [disabled]="disabled() || !fields().length"
      (click)="add()"
    >
      Add condition</button
    ><button
      atlasButton
      type="button"
      [disabled]="disabled() || !rules().length"
      (click)="rules.set([])"
    >
      Clear filters
    </button>
    <div class="atlas-saved-views">
      <label
        >View name<input
          atlasInput
          [disabled]="disabled()"
          [value]="name()"
          (input)="name.set($any($event.target).value)" /></label
      ><button
        atlasButton
        type="button"
        [disabled]="disabled() || !name().trim()"
        (click)="saveRequested.emit(name().trim()); name.set('')"
      >
        Save current view
      </button>
      @for (view of views(); track view.id) {
        <button
          atlasButton
          type="button"
          [disabled]="disabled()"
          (click)="rules.set(copy(view.rules))"
        >
          Load {{ view.name }}</button
        ><button
          atlasButton
          type="button"
          [disabled]="disabled()"
          [attr.aria-label]="'Delete view ' + view.name"
          (click)="deleteRequested.emit(view.id)"
        >
          ×
        </button>
      }
    </div>
  </section>`,
                }]
        }], propDecorators: { fields: [{ type: i0.Input, args: [{ isSignal: true, alias: "fields", required: true }] }], rules: [{ type: i0.Input, args: [{ isSignal: true, alias: "rules", required: false }] }, { type: i0.Output, args: ["rulesChange"] }], views: [{ type: i0.Input, args: [{ isSignal: true, alias: "views", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], saveRequested: [{ type: i0.Output, args: ["saveRequested"] }], deleteRequested: [{ type: i0.Output, args: ["deleteRequested"] }] } });

/** Feature-owned upload state. Call destroy() on disposal. Adapter owns HTTP and remote file IDs. */
class AtlasUploadQueue {
    adapter;
    maxBytes;
    files = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "files" }] : /* istanbul ignore next */ []));
    error = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    sources = new Map();
    requests = new Map();
    sequence = 0;
    disposed = false;
    constructor(adapter, maxBytes = 10 * 1024 * 1024) {
        this.adapter = adapter;
        this.maxBytes = maxBytes;
    }
    add(files) {
        if (this.disposed)
            return;
        this.error.set("");
        for (const file of files) {
            if (file.size > this.maxBytes) {
                this.error.set(`${file.name} exceeds the ${this.maxBytes / 1024 / 1024} MB limit.`);
                continue;
            }
            const id = `upload-${++this.sequence}`;
            this.sources.set(id, file);
            this.files.update((rows) => [
                ...rows,
                {
                    id,
                    name: file.name,
                    size: file.size,
                    status: "uploading",
                    progress: 0,
                },
            ]);
            void this.upload(id);
        }
    }
    file(id) {
        return this.sources.get(id) ?? null;
    }
    async upload(id) {
        const file = this.sources.get(id);
        if (!file || this.disposed || this.requests.has(id))
            return;
        const controller = new AbortController();
        this.requests.set(id, controller);
        const current = () => !this.disposed && this.requests.get(id) === controller;
        this.patch(id, { status: "uploading", progress: 0, error: undefined });
        try {
            await this.adapter(file, {
                signal: controller.signal,
                progress: (percent) => {
                    if (current() && Number.isFinite(percent))
                        this.patch(id, { progress: Math.max(0, Math.min(100, percent)) });
                },
            });
            if (current())
                this.patch(id, { status: "ready", progress: 100 });
        }
        catch (error) {
            if (current())
                this.patch(id, {
                    status: "error",
                    error: error instanceof Error
                        ? error.message
                        : "Upload failed. Retry to continue.",
                });
        }
        finally {
            if (current())
                this.requests.delete(id);
        }
    }
    remove(id) {
        const controller = this.requests.get(id);
        this.requests.delete(id);
        controller?.abort();
        this.sources.delete(id);
        this.files.update((rows) => rows.filter((row) => row.id !== id));
    }
    destroy() {
        this.disposed = true;
        this.requests.forEach((c) => c.abort());
        this.requests.clear();
        this.sources.clear();
    }
    patch(id, patch) {
        this.files.update((rows) => rows.map((row) => (row.id === id ? { ...row, ...patch } : row)));
    }
}

let layoutSequence = 0;
function nextAtlasTab(tabs, current, key) {
    const enabled = tabs.filter((tab) => !tab.disabled);
    if (!enabled.length)
        return undefined;
    if (key === "Home")
        return enabled[0].id;
    if (key === "End")
        return enabled[enabled.length - 1].id;
    if (key !== "ArrowLeft" && key !== "ArrowRight")
        return undefined;
    const index = enabled.findIndex((tab) => tab.id === current);
    return enabled[(Math.max(0, index) + (key === "ArrowRight" ? 1 : -1) + enabled.length) %
        enabled.length].id;
}
function clampAtlasSplit(value, minimum = 15, maximum = 85) {
    const low = Math.max(5, Math.min(90, Number.isFinite(minimum) ? minimum : 15));
    const high = Math.max(low, Math.min(95, Number.isFinite(maximum) ? maximum : 85));
    return Math.max(low, Math.min(high, Number.isFinite(value) ? value : 35));
}
class AtlasTab {
    id = input.required({ ...(ngDevMode ? { debugName: "id" } : /* istanbul ignore next */ {}), alias: "atlasTab" });
    label = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTab, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasTab, isStandalone: true, selector: "ng-template[atlasTab]", inputs: { id: { classPropertyName: "id", publicName: "atlasTab", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTab, decorators: [{
            type: Directive,
            args: [{ selector: "ng-template[atlasTab]" }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "atlasTab", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });
class AtlasTabs {
    uid = `atlas-tabs-${++layoutSequence}`;
    label = input("Sections", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    selected = model("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    tabs = contentChildren(AtlasTab, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []));
    visited = signal(new Set(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visited" }] : /* istanbul ignore next */ []));
    active = computed(() => this.tabs()
        .find((tab) => tab.id() === this.selected() && !tab.disabled())
        ?.id() ??
        this.tabs()
            .find((tab) => !tab.disabled())
            ?.id() ??
        "", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const id = this.active();
            if (id)
                this.visited.update((seen) => new Set([...seen, id]));
        });
    }
    key(event, id) {
        const next = nextAtlasTab(this.tabs().map((tab) => ({ id: tab.id(), disabled: tab.disabled() })), id, event.key);
        if (next === undefined)
            return;
        event.preventDefault();
        this.selected.set(next);
        const index = this.tabs().findIndex((tab) => tab.id() === next);
        event.currentTarget.parentElement
            ?.querySelectorAll("[role=tab]")[index]?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTabs, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTabs, isStandalone: true, selector: "atlas-tabs", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selected: "selectedChange" }, host: { classAttribute: "atlas-tabs" }, queries: [{ propertyName: "tabs", predicate: AtlasTab, isSignal: true }], ngImport: i0, template: `<div
      class="atlas-tab-strip"
      role="tablist"
      [attr.aria-label]="label()"
    >
      @for (tab of tabs(); track tab.id(); let i = $index) {
        <button
          type="button"
          role="tab"
          [id]="uid + '-tab-' + i"
          [attr.aria-controls]="uid + '-panel-' + i"
          [attr.aria-selected]="active() === tab.id()"
          [disabled]="tab.disabled()"
          [attr.tabindex]="active() === tab.id() ? 0 : -1"
          (click)="selected.set(tab.id())"
          (keydown)="key($event, tab.id())"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    @for (tab of tabs(); track tab.id(); let i = $index) {
      <section
        role="tabpanel"
        class="atlas-tab-body"
        [id]="uid + '-panel-' + i"
        [attr.aria-labelledby]="uid + '-tab-' + i"
        [hidden]="active() !== tab.id()"
        tabindex="0"
      >
        @if (visited().has(tab.id()) || active() === tab.id()) {
          <ng-container [ngTemplateOutlet]="tab.template" />
        }
      </section>
    }`, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTabs, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-tabs",
                    imports: [NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-tabs" },
                    template: `<div
      class="atlas-tab-strip"
      role="tablist"
      [attr.aria-label]="label()"
    >
      @for (tab of tabs(); track tab.id(); let i = $index) {
        <button
          type="button"
          role="tab"
          [id]="uid + '-tab-' + i"
          [attr.aria-controls]="uid + '-panel-' + i"
          [attr.aria-selected]="active() === tab.id()"
          [disabled]="tab.disabled()"
          [attr.tabindex]="active() === tab.id() ? 0 : -1"
          (click)="selected.set(tab.id())"
          (keydown)="key($event, tab.id())"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    @for (tab of tabs(); track tab.id(); let i = $index) {
      <section
        role="tabpanel"
        class="atlas-tab-body"
        [id]="uid + '-panel-' + i"
        [attr.aria-labelledby]="uid + '-tab-' + i"
        [hidden]="active() !== tab.id()"
        tabindex="0"
      >
        @if (visited().has(tab.id()) || active() === tab.id()) {
          <ng-container [ngTemplateOutlet]="tab.template" />
        }
      </section>
    }`,
                }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], selected: [{ type: i0.Input, args: [{ isSignal: true, alias: "selected", required: false }] }, { type: i0.Output, args: ["selectedChange"] }], tabs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => AtlasTab), { isSignal: true }] }] } });
class AtlasFieldset {
    uid = `atlas-fieldset-${++layoutSequence}`;
    label = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    collapsible = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsible" }] : /* istanbul ignore next */ []));
    collapsed = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsed" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasFieldset, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasFieldset, isStandalone: true, selector: "atlas-fieldset", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, collapsible: { classPropertyName: "collapsible", publicName: "collapsible", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { collapsed: "collapsedChange" }, host: { classAttribute: "atlas-fieldset-host" }, ngImport: i0, template: `<fieldset class="atlas-fieldset" [disabled]="disabled()">
    <legend>
      @if (collapsible()) {
        <button
          type="button"
          [attr.aria-expanded]="!collapsed()"
          [attr.aria-controls]="uid"
          (click)="collapsed.set(!collapsed())"
        >
          <span aria-hidden="true">{{ collapsed() ? "▸" : "▾" }}</span>
          {{ label() }}
        </button>
      } @else {
        {{ label() }}
      }
    </legend>
    <div class="atlas-fieldset-body" [id]="uid" [hidden]="collapsed()">
      <ng-content />
    </div>
  </fieldset>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasFieldset, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-fieldset",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-fieldset-host" },
                    template: `<fieldset class="atlas-fieldset" [disabled]="disabled()">
    <legend>
      @if (collapsible()) {
        <button
          type="button"
          [attr.aria-expanded]="!collapsed()"
          [attr.aria-controls]="uid"
          (click)="collapsed.set(!collapsed())"
        >
          <span aria-hidden="true">{{ collapsed() ? "▸" : "▾" }}</span>
          {{ label() }}
        </button>
      } @else {
        {{ label() }}
      }
    </legend>
    <div class="atlas-fieldset-body" [id]="uid" [hidden]="collapsed()">
      <ng-content />
    </div>
  </fieldset>`,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], collapsible: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsible", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }, { type: i0.Output, args: ["collapsedChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });
class AtlasAccordionSection {
    uid = `atlas-accordion-${++layoutSequence}`;
    label = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    expanded = model(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAccordionSection, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasAccordionSection, isStandalone: true, selector: "atlas-accordion-section", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, expanded: { classPropertyName: "expanded", publicName: "expanded", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { expanded: "expandedChange" }, host: { classAttribute: "atlas-accordion-section" }, ngImport: i0, template: `<h3 class="atlas-accordion-heading">
      <button
        type="button"
        [id]="uid + '-heading'"
        [attr.aria-expanded]="expanded()"
        [attr.aria-controls]="uid"
        (click)="expanded.set(!expanded())"
      >
        <span>{{ label() }}</span
        ><span aria-hidden="true">{{ expanded() ? "−" : "+" }}</span>
      </button>
    </h3>
    <section
      class="atlas-accordion-body"
      [id]="uid"
      [attr.aria-labelledby]="uid + '-heading'"
      [hidden]="!expanded()"
    >
      <ng-content />
    </section>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAccordionSection, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-accordion-section",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { class: "atlas-accordion-section" },
                    template: `<h3 class="atlas-accordion-heading">
      <button
        type="button"
        [id]="uid + '-heading'"
        [attr.aria-expanded]="expanded()"
        [attr.aria-controls]="uid"
        (click)="expanded.set(!expanded())"
      >
        <span>{{ label() }}</span
        ><span aria-hidden="true">{{ expanded() ? "−" : "+" }}</span>
      </button>
    </h3>
    <section
      class="atlas-accordion-body"
      [id]="uid"
      [attr.aria-labelledby]="uid + '-heading'"
      [hidden]="!expanded()"
    >
      <ng-content />
    </section>`,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], expanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "expanded", required: false }] }, { type: i0.Output, args: ["expandedChange"] }] } });
class AtlasSplitPane {
    uid = `atlas-split-${++layoutSequence}`;
    primaryLabel = input("Navigation", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "primaryLabel" }] : /* istanbul ignore next */ []));
    secondaryLabel = input("Details", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "secondaryLabel" }] : /* istanbul ignore next */ []));
    ratio = model(35, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ratio" }] : /* istanbul ignore next */ []));
    minimum = input(15, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minimum" }] : /* istanbul ignore next */ []));
    maximum = input(70, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maximum" }] : /* istanbul ignore next */ []));
    breakpoint = input(700, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    collapsed = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsed" }] : /* istanbul ignore next */ []));
    width = signal(1000, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    narrow = computed(() => this.width() < this.breakpoint(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "narrow" }] : /* istanbul ignore next */ []));
    lower = computed(() => clampAtlasSplit(0, this.minimum(), this.maximum()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "lower" }] : /* istanbul ignore next */ []));
    upper = computed(() => clampAtlasSplit(95, this.minimum(), this.maximum()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "upper" }] : /* istanbul ignore next */ []));
    size = computed(() => clampAtlasSplit(this.ratio(), this.minimum(), this.maximum()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    host = inject(ElementRef);
    dragging = false;
    constructor() {
        const destroy = inject(DestroyRef);
        afterNextRender(() => {
            const observer = new ResizeObserver((entries) => this.width.set(entries[0].contentRect.width));
            observer.observe(this.host.nativeElement);
            destroy.onDestroy(() => observer.disconnect());
        });
    }
    key(event) {
        if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key))
            return;
        event.preventDefault();
        this.ratio.set(clampAtlasSplit(event.key === "Home"
            ? this.minimum()
            : event.key === "End"
                ? this.maximum()
                : this.size() +
                    (event.key === "ArrowRight" ? 1 : -1) * (event.shiftKey ? 10 : 2), this.minimum(), this.maximum()));
    }
    start(event) {
        if (event.button !== 0)
            return;
        event.preventDefault();
        event.currentTarget.focus();
        event.currentTarget.setPointerCapture(event.pointerId);
        this.dragging = true;
    }
    move(event) {
        if (!this.dragging)
            return;
        const bounds = this.host.nativeElement.getBoundingClientRect();
        if (bounds.width)
            this.ratio.set(clampAtlasSplit(((event.clientX - bounds.left) / bounds.width) * 100, this.minimum(), this.maximum()));
    }
    stop(event) {
        this.dragging = false;
        const target = event.currentTarget;
        if (target.hasPointerCapture(event.pointerId))
            target.releasePointerCapture(event.pointerId);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSplitPane, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasSplitPane, isStandalone: true, selector: "atlas-split-pane", inputs: { primaryLabel: { classPropertyName: "primaryLabel", publicName: "primaryLabel", isSignal: true, isRequired: false, transformFunction: null }, secondaryLabel: { classPropertyName: "secondaryLabel", publicName: "secondaryLabel", isSignal: true, isRequired: false, transformFunction: null }, ratio: { classPropertyName: "ratio", publicName: "ratio", isSignal: true, isRequired: false, transformFunction: null }, minimum: { classPropertyName: "minimum", publicName: "minimum", isSignal: true, isRequired: false, transformFunction: null }, maximum: { classPropertyName: "maximum", publicName: "maximum", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { ratio: "ratioChange", collapsed: "collapsedChange" }, host: { properties: { "class.is-stacked": "narrow()", "class.is-collapsed": "collapsed()" }, classAttribute: "atlas-split-pane" }, ngImport: i0, template: `<div class="atlas-split-controls">
      <button
        type="button"
        class="atlas-button"
        [attr.aria-expanded]="!collapsed()"
        [attr.aria-controls]="uid"
        (click)="collapsed.set(!collapsed())"
      >
        {{ collapsed() ? "Show" : "Hide" }} {{ primaryLabel() }}
      </button>
    </div>
    <div
      class="atlas-split-grid"
      [style.grid-template-columns]="
        narrow() || collapsed()
          ? 'minmax(0,1fr)'
          : size() + '% 10px minmax(0,1fr)'
      "
    >
      <section
        class="atlas-split-primary"
        [id]="uid"
        [attr.aria-label]="primaryLabel()"
        [hidden]="collapsed()"
      >
        <ng-content select="[atlasSplitPrimary]" />
      </section>
      <div
        class="atlas-splitter"
        role="separator"
        tabindex="0"
        aria-orientation="vertical"
        [attr.aria-label]="'Resize ' + primaryLabel()"
        [attr.aria-controls]="uid"
        [attr.aria-valuemin]="lower()"
        [attr.aria-valuemax]="upper()"
        [attr.aria-valuenow]="size()"
        [hidden]="narrow() || collapsed()"
        (keydown)="key($event)"
        (pointerdown)="start($event)"
        (pointermove)="move($event)"
        (pointerup)="stop($event)"
        (pointercancel)="stop($event)"
        (lostpointercapture)="dragging = false"
      ></div>
      <section
        class="atlas-split-secondary"
        [attr.aria-label]="secondaryLabel()"
      >
        <ng-content select="[atlasSplitSecondary]" />
      </section>
    </div>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSplitPane, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-split-pane",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        class: "atlas-split-pane",
                        "[class.is-stacked]": "narrow()",
                        "[class.is-collapsed]": "collapsed()",
                    },
                    template: `<div class="atlas-split-controls">
      <button
        type="button"
        class="atlas-button"
        [attr.aria-expanded]="!collapsed()"
        [attr.aria-controls]="uid"
        (click)="collapsed.set(!collapsed())"
      >
        {{ collapsed() ? "Show" : "Hide" }} {{ primaryLabel() }}
      </button>
    </div>
    <div
      class="atlas-split-grid"
      [style.grid-template-columns]="
        narrow() || collapsed()
          ? 'minmax(0,1fr)'
          : size() + '% 10px minmax(0,1fr)'
      "
    >
      <section
        class="atlas-split-primary"
        [id]="uid"
        [attr.aria-label]="primaryLabel()"
        [hidden]="collapsed()"
      >
        <ng-content select="[atlasSplitPrimary]" />
      </section>
      <div
        class="atlas-splitter"
        role="separator"
        tabindex="0"
        aria-orientation="vertical"
        [attr.aria-label]="'Resize ' + primaryLabel()"
        [attr.aria-controls]="uid"
        [attr.aria-valuemin]="lower()"
        [attr.aria-valuemax]="upper()"
        [attr.aria-valuenow]="size()"
        [hidden]="narrow() || collapsed()"
        (keydown)="key($event)"
        (pointerdown)="start($event)"
        (pointermove)="move($event)"
        (pointerup)="stop($event)"
        (pointercancel)="stop($event)"
        (lostpointercapture)="dragging = false"
      ></div>
      <section
        class="atlas-split-secondary"
        [attr.aria-label]="secondaryLabel()"
      >
        <ng-content select="[atlasSplitSecondary]" />
      </section>
    </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { primaryLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "primaryLabel", required: false }] }], secondaryLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "secondaryLabel", required: false }] }], ratio: [{ type: i0.Input, args: [{ isSignal: true, alias: "ratio", required: false }] }, { type: i0.Output, args: ["ratioChange"] }], minimum: [{ type: i0.Input, args: [{ isSignal: true, alias: "minimum", required: false }] }], maximum: [{ type: i0.Input, args: [{ isSignal: true, alias: "maximum", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }, { type: i0.Output, args: ["collapsedChange"] }] } });

/** null means selection is incomplete because an enabled branch is still unloaded. Disabled subtrees are excluded. */
function atlasCheckLeaves(node) {
    if (node.disabled)
        return [];
    if (node.hasChildren && node.children === undefined)
        return null;
    if (!node.children?.length)
        return node.hasChildren ? [] : [node.id];
    const leaves = [];
    for (const child of node.children) {
        const result = atlasCheckLeaves(child);
        if (result === null)
            return null;
        leaves.push(...result);
    }
    return leaves;
}
function atlasCheckState(node, checked) {
    const leaves = atlasCheckLeaves(node);
    if (leaves === null) {
        return node.children?.some((child) => atlasCheckState(child, checked) !== false)
            ? "mixed"
            : false;
    }
    if (!leaves.length)
        return false;
    const count = leaves.filter((id) => checked.includes(id)).length;
    return count === leaves.length ? true : count > 0 ? "mixed" : false;
}
function atlasToggleChecks(node, checked) {
    const leaves = atlasCheckLeaves(node);
    if (!leaves?.length)
        return [...checked];
    const result = new Set(checked);
    const remove = leaves.every((id) => result.has(id));
    for (const id of leaves) {
        if (remove)
            result.delete(id);
        else
            result.add(id);
    }
    return [...result];
}
class AtlasHierarchyBase {
    nodes = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    label = input("Hierarchy", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    expandedIds = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandedIds" }] : /* istanbul ignore next */ []));
    selectedId = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedId" }] : /* istanbul ignore next */ []));
    checkedIds = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checkedIds" }] : /* istanbul ignore next */ []));
    /** Adapter inserts children immutably and owns node loading/error state. */
    loadChildren = output();
    nodeSelected = output();
    focused = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []));
    visible = computed(() => flattenTree(this.nodes(), this.expandedIds()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    tabstop = computed(() => this.visible().some((row) => row.node.id === this.focused())
        ? this.focused()
        : this.visible()[0]?.node.id, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabstop" }] : /* istanbul ignore next */ []));
    branch(node) {
        return !!node.children?.length || !!node.hasChildren;
    }
    blocked(row) {
        if (this.disabled() || row.node.disabled)
            return true;
        let parent = row.parent;
        while (parent) {
            const ancestor = this.visible().find((item) => item.node.id === parent);
            if (ancestor?.node.disabled)
                return true;
            parent = ancestor?.parent ?? null;
        }
        return false;
    }
    checkBlocked(row) {
        return (this.blocked(row) ||
            this.readonly() ||
            !atlasCheckLeaves(row.node)?.length);
    }
    state(node) {
        return atlasCheckState(node, this.checkedIds());
    }
    check(row) {
        if (!this.checkBlocked(row))
            this.checkedIds.set(atlasToggleChecks(row.node, this.checkedIds()));
    }
    toggle(row) {
        if (!this.branch(row.node) || this.blocked(row))
            return;
        const expanded = this.expandedIds().includes(row.node.id);
        this.expandedIds.update((ids) => expanded ? ids.filter((id) => id !== row.node.id) : [...ids, row.node.id]);
        if (!expanded && row.node.children === undefined && !row.node.loading)
            this.loadChildren.emit(row.node);
    }
    retry(row) {
        if (!this.blocked(row) && !row.node.loading)
            this.loadChildren.emit(row.node);
    }
    choose(row) {
        if (this.blocked(row) || this.readonly())
            return;
        this.selectedId.set(row.node.id);
        this.nodeSelected.emit(row.node);
    }
    key(event, row, checks = false) {
        const rows = this.visible(), index = rows.findIndex((item) => item.node.id === row.node.id);
        let target = index;
        switch (event.key) {
            case "ArrowDown":
                target = Math.min(rows.length - 1, index + 1);
                break;
            case "ArrowUp":
                target = Math.max(0, index - 1);
                break;
            case "Home":
                target = 0;
                break;
            case "End":
                target = rows.length - 1;
                break;
            case "ArrowRight":
                if (this.branch(row.node)) {
                    if (!row.expanded)
                        this.toggle(row);
                    else if (row.node.children?.length)
                        target = index + 1;
                }
                break;
            case "ArrowLeft":
                if (row.expanded)
                    this.toggle(row);
                else if (row.parent)
                    target = rows.findIndex((item) => item.node.id === row.parent);
                break;
            case "Enter":
                if (row.node.error)
                    this.retry(row);
                else if (checks)
                    this.check(row);
                else
                    this.choose(row);
                break;
            case " ":
                if (checks)
                    this.check(row);
                else
                    this.choose(row);
                break;
            default:
                return;
        }
        event.preventDefault();
        if (rows[target]) {
            this.focused.set(rows[target].node.id);
            const root = event.currentTarget.closest('[role="tree"], [role="treegrid"]');
            root
                ?.querySelectorAll("[data-hierarchy-row]")[target]?.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasHierarchyBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasHierarchyBase, isStandalone: true, inputs: { nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, expandedIds: { classPropertyName: "expandedIds", publicName: "expandedIds", isSignal: true, isRequired: false, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null }, checkedIds: { classPropertyName: "checkedIds", publicName: "checkedIds", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { expandedIds: "expandedIdsChange", selectedId: "selectedIdChange", checkedIds: "checkedIdsChange", loadChildren: "loadChildren", nodeSelected: "nodeSelected" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasHierarchyBase, decorators: [{
            type: Directive
        }], propDecorators: { nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], expandedIds: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandedIds", required: false }] }, { type: i0.Output, args: ["expandedIdsChange"] }], selectedId: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedId", required: false }] }, { type: i0.Output, args: ["selectedIdChange"] }], checkedIds: [{ type: i0.Input, args: [{ isSignal: true, alias: "checkedIds", required: false }] }, { type: i0.Output, args: ["checkedIdsChange"] }], loadChildren: [{ type: i0.Output, args: ["loadChildren"] }], nodeSelected: [{ type: i0.Output, args: ["nodeSelected"] }] } });
class AtlasCheckTree extends AtlasHierarchyBase {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCheckTree, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasCheckTree, isStandalone: true, selector: "atlas-check-tree", usesInheritance: true, ngImport: i0, template: `
    <div
      class="atlas-tree atlas-check-tree"
      role="tree"
      [attr.aria-label]="label()"
      aria-multiselectable="true"
    >
      @for (row of visible(); track row.node.id) {
        <div
          class="atlas-tree-row"
          role="treeitem"
          data-hierarchy-row
          [style.--atlas-tree-depth]="row.level - 1"
          [attr.aria-level]="row.level"
          [attr.aria-posinset]="row.position"
          [attr.aria-setsize]="row.size"
          [attr.aria-expanded]="branch(row.node) ? row.expanded : null"
          [attr.aria-checked]="state(row.node)"
          [attr.aria-disabled]="checkBlocked(row)"
          [attr.aria-busy]="row.node.loading || false"
          [attr.tabindex]="tabstop() === row.node.id ? 0 : -1"
          (focus)="focused.set(row.node.id)"
          (keydown)="key($event, row, true)"
        >
          <button
            type="button"
            tabindex="-1"
            class="atlas-tree-disclosure"
            [disabled]="!branch(row.node) || blocked(row)"
            [attr.aria-label]="
              (row.expanded ? 'Collapse ' : 'Expand ') + row.node.label
            "
            (click)="toggle(row)"
          >
            {{ branch(row.node) ? (row.expanded ? "▾" : "▸") : "·" }}
          </button>
          <input
            type="checkbox"
            tabindex="-1"
            [attr.aria-label]="'Check ' + row.node.label"
            [checked]="state(row.node) === true"
            [indeterminate]="state(row.node) === 'mixed'"
            [disabled]="checkBlocked(row)"
            (change)="check(row)"
          />
          <span class="atlas-tree-label"
            ><strong>{{ row.node.label }}</strong
            ><small>{{ row.node.description }}</small></span
          >
          @if (row.node.loading) {
            <small role="status">Loading…</small>
          }
          @if (row.node.error) {
            <span role="alert">{{ row.node.error }}</span
            ><button
              type="button"
              tabindex="-1"
              [disabled]="blocked(row)"
              (click)="retry(row)"
            >
              Retry
            </button>
          }
        </div>
      } @empty {
        <p class="atlas-options-empty">No nodes.</p>
      }
    </div>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCheckTree, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-check-tree",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <div
      class="atlas-tree atlas-check-tree"
      role="tree"
      [attr.aria-label]="label()"
      aria-multiselectable="true"
    >
      @for (row of visible(); track row.node.id) {
        <div
          class="atlas-tree-row"
          role="treeitem"
          data-hierarchy-row
          [style.--atlas-tree-depth]="row.level - 1"
          [attr.aria-level]="row.level"
          [attr.aria-posinset]="row.position"
          [attr.aria-setsize]="row.size"
          [attr.aria-expanded]="branch(row.node) ? row.expanded : null"
          [attr.aria-checked]="state(row.node)"
          [attr.aria-disabled]="checkBlocked(row)"
          [attr.aria-busy]="row.node.loading || false"
          [attr.tabindex]="tabstop() === row.node.id ? 0 : -1"
          (focus)="focused.set(row.node.id)"
          (keydown)="key($event, row, true)"
        >
          <button
            type="button"
            tabindex="-1"
            class="atlas-tree-disclosure"
            [disabled]="!branch(row.node) || blocked(row)"
            [attr.aria-label]="
              (row.expanded ? 'Collapse ' : 'Expand ') + row.node.label
            "
            (click)="toggle(row)"
          >
            {{ branch(row.node) ? (row.expanded ? "▾" : "▸") : "·" }}
          </button>
          <input
            type="checkbox"
            tabindex="-1"
            [attr.aria-label]="'Check ' + row.node.label"
            [checked]="state(row.node) === true"
            [indeterminate]="state(row.node) === 'mixed'"
            [disabled]="checkBlocked(row)"
            (change)="check(row)"
          />
          <span class="atlas-tree-label"
            ><strong>{{ row.node.label }}</strong
            ><small>{{ row.node.description }}</small></span
          >
          @if (row.node.loading) {
            <small role="status">Loading…</small>
          }
          @if (row.node.error) {
            <span role="alert">{{ row.node.error }}</span
            ><button
              type="button"
              tabindex="-1"
              [disabled]="blocked(row)"
              (click)="retry(row)"
            >
              Retry
            </button>
          }
        </div>
      } @empty {
        <p class="atlas-options-empty">No nodes.</p>
      }
    </div>
  `,
                }]
        }] });
class AtlasTreeGrid extends AtlasHierarchyBase {
    columns = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    hierarchyLabel = input("Account / item", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hierarchyLabel" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTreeGrid, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasTreeGrid, isStandalone: true, selector: "atlas-tree-grid", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, hierarchyLabel: { classPropertyName: "hierarchyLabel", publicName: "hierarchyLabel", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0, template: `
    <div class="atlas-table-scroll">
      <table
        class="atlas-table atlas-tree-grid"
        role="treegrid"
        [attr.aria-label]="label()"
        [attr.aria-readonly]="readonly()"
      >
        <thead>
          <tr>
            <th scope="col">{{ hierarchyLabel() }}</th>
            @for (column of columns(); track column.key) {
              <th scope="col" [style.text-align]="column.align || 'left'">
                {{ column.label }}
              </th>
            }
          </tr>
        </thead>
        <tbody>
          @for (row of visible(); track row.node.id) {
            <tr
              role="row"
              data-hierarchy-row
              [attr.aria-level]="row.level"
              [attr.aria-posinset]="row.position"
              [attr.aria-setsize]="row.size"
              [attr.aria-expanded]="branch(row.node) ? row.expanded : null"
              [attr.aria-selected]="selectedId() === row.node.id"
              [attr.aria-disabled]="blocked(row)"
              [attr.aria-busy]="row.node.loading || false"
              [attr.tabindex]="tabstop() === row.node.id ? 0 : -1"
              [class.selected]="selectedId() === row.node.id"
              (focus)="focused.set(row.node.id)"
              (keydown)="key($event, row)"
              (click)="choose(row)"
            >
              <td role="gridcell">
                <div
                  class="atlas-hierarchy-cell"
                  [style.--atlas-tree-depth]="row.level - 1"
                >
                  <button
                    type="button"
                    tabindex="-1"
                    class="atlas-tree-disclosure"
                    [disabled]="!branch(row.node) || blocked(row)"
                    [attr.aria-label]="
                      (row.expanded ? 'Collapse ' : 'Expand ') + row.node.label
                    "
                    (click)="$event.stopPropagation(); toggle(row)"
                  >
                    {{ branch(row.node) ? (row.expanded ? "▾" : "▸") : "·" }}
                  </button>
                  <span class="atlas-tree-label"
                    ><strong>{{ row.node.label }}</strong
                    ><small>{{ row.node.description }}</small></span
                  >
                  @if (row.node.loading) {
                    <small role="status">Loading…</small>
                  }
                  @if (row.node.error) {
                    <span role="alert">{{ row.node.error }}</span
                    ><button
                      type="button"
                      tabindex="-1"
                      [disabled]="blocked(row)"
                      (click)="$event.stopPropagation(); retry(row)"
                    >
                      Retry
                    </button>
                  }
                </div>
              </td>
              @for (column of columns(); track column.key) {
                <td role="gridcell" [style.text-align]="column.align || 'left'">
                  {{ row.node.values?.[column.key] ?? "—" }}
                </td>
              }
            </tr>
          } @empty {
            <tr>
              <td [attr.colspan]="columns().length + 1">No nodes.</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTreeGrid, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-tree-grid",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <div class="atlas-table-scroll">
      <table
        class="atlas-table atlas-tree-grid"
        role="treegrid"
        [attr.aria-label]="label()"
        [attr.aria-readonly]="readonly()"
      >
        <thead>
          <tr>
            <th scope="col">{{ hierarchyLabel() }}</th>
            @for (column of columns(); track column.key) {
              <th scope="col" [style.text-align]="column.align || 'left'">
                {{ column.label }}
              </th>
            }
          </tr>
        </thead>
        <tbody>
          @for (row of visible(); track row.node.id) {
            <tr
              role="row"
              data-hierarchy-row
              [attr.aria-level]="row.level"
              [attr.aria-posinset]="row.position"
              [attr.aria-setsize]="row.size"
              [attr.aria-expanded]="branch(row.node) ? row.expanded : null"
              [attr.aria-selected]="selectedId() === row.node.id"
              [attr.aria-disabled]="blocked(row)"
              [attr.aria-busy]="row.node.loading || false"
              [attr.tabindex]="tabstop() === row.node.id ? 0 : -1"
              [class.selected]="selectedId() === row.node.id"
              (focus)="focused.set(row.node.id)"
              (keydown)="key($event, row)"
              (click)="choose(row)"
            >
              <td role="gridcell">
                <div
                  class="atlas-hierarchy-cell"
                  [style.--atlas-tree-depth]="row.level - 1"
                >
                  <button
                    type="button"
                    tabindex="-1"
                    class="atlas-tree-disclosure"
                    [disabled]="!branch(row.node) || blocked(row)"
                    [attr.aria-label]="
                      (row.expanded ? 'Collapse ' : 'Expand ') + row.node.label
                    "
                    (click)="$event.stopPropagation(); toggle(row)"
                  >
                    {{ branch(row.node) ? (row.expanded ? "▾" : "▸") : "·" }}
                  </button>
                  <span class="atlas-tree-label"
                    ><strong>{{ row.node.label }}</strong
                    ><small>{{ row.node.description }}</small></span
                  >
                  @if (row.node.loading) {
                    <small role="status">Loading…</small>
                  }
                  @if (row.node.error) {
                    <span role="alert">{{ row.node.error }}</span
                    ><button
                      type="button"
                      tabindex="-1"
                      [disabled]="blocked(row)"
                      (click)="$event.stopPropagation(); retry(row)"
                    >
                      Retry
                    </button>
                  }
                </div>
              </td>
              @for (column of columns(); track column.key) {
                <td role="gridcell" [style.text-align]="column.align || 'left'">
                  {{ row.node.values?.[column.key] ?? "—" }}
                </td>
              }
            </tr>
          } @empty {
            <tr>
              <td [attr.colspan]="columns().length + 1">No nodes.</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
                }]
        }], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], hierarchyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "hierarchyLabel", required: false }] }] } });

function atlasTransferItems(value, selection, options, add, limit = 0) {
    const enabled = new Set(options.filter((option) => !option.disabled).map((option) => option.value));
    const eligible = selection.filter((id) => enabled.has(id));
    const next = add
        ? [...new Set([...value, ...eligible])]
        : value.filter((id) => !eligible.includes(id));
    return add && limit > 0 && next.length > limit ? [...value] : next;
}
function atlasMoveItems(value, selection, options, direction) {
    const enabled = new Set(options.filter((option) => !option.disabled).map((option) => option.value));
    const selected = new Set(selection.filter((id) => enabled.has(id)));
    const next = [...value];
    const indexes = Array.from({ length: next.length }, (_, i) => i);
    if (direction === 1)
        indexes.reverse();
    for (const index of indexes) {
        const to = index + direction;
        if (selected.has(next[index]) &&
            to >= 0 &&
            to < next.length &&
            !selected.has(next[to]) &&
            enabled.has(next[to]))
            [next[index], next[to]] = [next[to], next[index]];
    }
    return next;
}
class AtlasItemSelector extends AtlasChoiceState {
    value = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    availableLabel = input("Available", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "availableLabel" }] : /* istanbul ignore next */ []));
    assignedLabel = input("Assigned", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "assignedLabel" }] : /* istanbul ignore next */ []));
    limit = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "limit" }] : /* istanbul ignore next */ []));
    reorderable = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "reorderable" }] : /* istanbul ignore next */ []));
    search = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    availableSelection = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "availableSelection" }] : /* istanbul ignore next */ []));
    assignedSelection = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "assignedSelection" }] : /* istanbul ignore next */ []));
    message = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    available = computed(() => filterCollection(this.options().filter((option) => !this.value().includes(option.value)), this.search(), (option) => `${option.label} ${option.description ?? ""}`), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "available" }] : /* istanbul ignore next */ []));
    assigned = computed(() => this.value().map((value) => this.options().find((option) => option.value === value) ?? {
        value,
        label: `Unavailable (${value})`,
        disabled: true,
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "assigned" }] : /* istanbul ignore next */ []));
    element = inject(ElementRef);
    focus(options) {
        this.element.nativeElement
            .querySelector("select:not(:disabled)")
            ?.focus(options);
    }
    choose(event, assigned) {
        (assigned ? this.assignedSelection : this.availableSelection).set([...event.target.selectedOptions].map((option) => option.value));
    }
    transfer(add) {
        if (this.disabled() || this.readonly())
            return;
        const selection = add
            ? this.availableSelection().filter((id) => this.available().some((option) => option.value === id))
            : this.assignedSelection();
        const next = atlasTransferItems(this.value(), selection, this.options(), add, this.limit());
        const count = Math.abs(next.length - this.value().length);
        this.value.set(next);
        this.touch.emit();
        this.message.set(count
            ? `${count} ${count === 1 ? "item" : "items"} ${add ? "added" : "removed"}.`
            : add && selection.length
                ? `Nothing added. Assignment limit: ${this.limit() || "unlimited"}.`
                : "No items changed.");
        if (count) {
            this.availableSelection.set([]);
            this.assignedSelection.set([]);
        }
    }
    canMove(direction) {
        return atlasMoveItems(this.value(), this.assignedSelection(), this.options(), direction).some((id, i) => id !== this.value()[i]);
    }
    move(direction) {
        if (this.disabled() || this.readonly() || !this.reorderable())
            return;
        this.value.set(atlasMoveItems(this.value(), this.assignedSelection(), this.options(), direction));
        this.touch.emit();
        this.message.set("Assignment order updated.");
    }
    key(event, assigned) {
        if (!event.altKey)
            return;
        if (!assigned && event.key === "ArrowRight") {
            event.preventDefault();
            this.transfer(true);
        }
        if (assigned && event.key === "ArrowLeft") {
            event.preventDefault();
            this.transfer(false);
        }
        if (assigned &&
            this.reorderable() &&
            ["ArrowUp", "ArrowDown"].includes(event.key)) {
            event.preventDefault();
            this.move(event.key === "ArrowUp" ? -1 : 1);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasItemSelector, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasItemSelector, isStandalone: true, selector: "atlas-item-selector", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, availableLabel: { classPropertyName: "availableLabel", publicName: "availableLabel", isSignal: true, isRequired: false, transformFunction: null }, assignedLabel: { classPropertyName: "assignedLabel", publicName: "assignedLabel", isSignal: true, isRequired: false, transformFunction: null }, limit: { classPropertyName: "limit", publicName: "limit", isSignal: true, isRequired: false, transformFunction: null }, reorderable: { classPropertyName: "reorderable", publicName: "reorderable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { listeners: { "focusout": "touch.emit()" } }, usesInheritance: true, ngImport: i0, template: `<fieldset
    class="atlas-item-selector"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
  >
    <legend>{{ label() }}</legend>
    <div class="atlas-item-selector-grid">
      <div class="atlas-item-selector-list">
        <label [for]="controlId() + '-available'"
          >{{ availableLabel() }} · {{ available().length }}</label
        >
        <input
          atlasInput
          type="search"
          [attr.aria-label]="'Search ' + availableLabel()"
          placeholder="Filter available…"
          [value]="search()"
          (input)="
            search.set($any($event.target).value); availableSelection.set([])
          "
        />
        <select
          multiple
          size="8"
          [id]="controlId() + '-available'"
          [attr.aria-describedby]="controlId() + '-help'"
          (change)="choose($event, false)"
          (keydown)="key($event, false)"
        >
          @for (option of available(); track option.value) {
            <option
              [value]="option.value"
              [disabled]="option.disabled"
              [selected]="availableSelection().includes(option.value)"
            >
              {{ option.label
              }}{{ option.description ? " · " + option.description : "" }}
            </option>
          }
        </select>
      </div>
      <div class="atlas-item-selector-actions">
        <button
          atlasButton
          type="button"
          [disabled]="readonly() || !availableSelection().length"
          (click)="transfer(true)"
        >
          Add →
        </button>
        <button
          atlasButton
          type="button"
          [disabled]="readonly() || !assignedSelection().length"
          (click)="transfer(false)"
        >
          ← Remove
        </button>
      </div>
      <div class="atlas-item-selector-list">
        <label [for]="controlId() + '-assigned'"
          >{{ assignedLabel() }} · {{ value().length
          }}{{ limit() ? " / " + limit() : "" }}</label
        >
        <select
          multiple
          size="8"
          [id]="controlId() + '-assigned'"
          [attr.aria-describedby]="controlId() + '-help'"
          (change)="choose($event, true)"
          (keydown)="key($event, true)"
        >
          @for (option of assigned(); track option.value) {
            <option
              [value]="option.value"
              [disabled]="option.disabled"
              [selected]="assignedSelection().includes(option.value)"
            >
              {{ option.label
              }}{{ option.description ? " · " + option.description : "" }}
            </option>
          }
        </select>
        @if (reorderable()) {
          <div class="atlas-item-selector-order">
            <button
              atlasButton
              type="button"
              [disabled]="readonly() || !canMove(-1)"
              (click)="move(-1)"
            >
              Move up</button
            ><button
              atlasButton
              type="button"
              [disabled]="readonly() || !canMove(1)"
              (click)="move(1)"
            >
              Move down
            </button>
          </div>
        }
      </div>
    </div>
    <p class="atlas-muted" [id]="controlId() + '-help'">
      {{ readonly() ? "Read-only. " : "" }}Use Ctrl/⌘ or Shift to select
      multiple items. Alt+Right adds, Alt+Left removes; Alt+Up/Down reorders
      assigned items.
    </p>
    <p role="status">{{ message() }}</p>
  </fieldset>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasItemSelector, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-item-selector",
                    imports: [AtlasButton, AtlasInput],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { "(focusout)": "touch.emit()" },
                    template: `<fieldset
    class="atlas-item-selector"
    [id]="controlId()"
    [disabled]="disabled()"
    [attr.aria-describedby]="describedBy()"
    [attr.aria-invalid]="invalid() && touched()"
  >
    <legend>{{ label() }}</legend>
    <div class="atlas-item-selector-grid">
      <div class="atlas-item-selector-list">
        <label [for]="controlId() + '-available'"
          >{{ availableLabel() }} · {{ available().length }}</label
        >
        <input
          atlasInput
          type="search"
          [attr.aria-label]="'Search ' + availableLabel()"
          placeholder="Filter available…"
          [value]="search()"
          (input)="
            search.set($any($event.target).value); availableSelection.set([])
          "
        />
        <select
          multiple
          size="8"
          [id]="controlId() + '-available'"
          [attr.aria-describedby]="controlId() + '-help'"
          (change)="choose($event, false)"
          (keydown)="key($event, false)"
        >
          @for (option of available(); track option.value) {
            <option
              [value]="option.value"
              [disabled]="option.disabled"
              [selected]="availableSelection().includes(option.value)"
            >
              {{ option.label
              }}{{ option.description ? " · " + option.description : "" }}
            </option>
          }
        </select>
      </div>
      <div class="atlas-item-selector-actions">
        <button
          atlasButton
          type="button"
          [disabled]="readonly() || !availableSelection().length"
          (click)="transfer(true)"
        >
          Add →
        </button>
        <button
          atlasButton
          type="button"
          [disabled]="readonly() || !assignedSelection().length"
          (click)="transfer(false)"
        >
          ← Remove
        </button>
      </div>
      <div class="atlas-item-selector-list">
        <label [for]="controlId() + '-assigned'"
          >{{ assignedLabel() }} · {{ value().length
          }}{{ limit() ? " / " + limit() : "" }}</label
        >
        <select
          multiple
          size="8"
          [id]="controlId() + '-assigned'"
          [attr.aria-describedby]="controlId() + '-help'"
          (change)="choose($event, true)"
          (keydown)="key($event, true)"
        >
          @for (option of assigned(); track option.value) {
            <option
              [value]="option.value"
              [disabled]="option.disabled"
              [selected]="assignedSelection().includes(option.value)"
            >
              {{ option.label
              }}{{ option.description ? " · " + option.description : "" }}
            </option>
          }
        </select>
        @if (reorderable()) {
          <div class="atlas-item-selector-order">
            <button
              atlasButton
              type="button"
              [disabled]="readonly() || !canMove(-1)"
              (click)="move(-1)"
            >
              Move up</button
            ><button
              atlasButton
              type="button"
              [disabled]="readonly() || !canMove(1)"
              (click)="move(1)"
            >
              Move down
            </button>
          </div>
        }
      </div>
    </div>
    <p class="atlas-muted" [id]="controlId() + '-help'">
      {{ readonly() ? "Read-only. " : "" }}Use Ctrl/⌘ or Shift to select
      multiple items. Alt+Right adds, Alt+Left removes; Alt+Up/Down reorders
      assigned items.
    </p>
    <p role="status">{{ message() }}</p>
  </fieldset>`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], availableLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "availableLabel", required: false }] }], assignedLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "assignedLabel", required: false }] }], limit: [{ type: i0.Input, args: [{ isSignal: true, alias: "limit", required: false }] }], reorderable: [{ type: i0.Input, args: [{ isSignal: true, alias: "reorderable", required: false }] }] } });

function atlasPivot(records, row, column, value, scale = 2) {
    const columns = [...new Set(records.map(column))].sort();
    const groups = new Map();
    for (const record of records) {
        const label = row(record), field = column(record);
        if (!groups.has(label))
            groups.set(label, new Map());
        const cells = groups.get(label);
        if (!cells.has(field))
            cells.set(field, []);
        cells.get(field).push(value(record));
    }
    const rows = [...groups]
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([label, cells]) => {
        const values = columns.map((key) => atlasSumDecimal(cells.get(key) ?? [], scale));
        return { label, values, total: atlasSumDecimal(values, scale) };
    });
    const totals = columns.map((_, index) => atlasSumDecimal(rows.map((row) => row.values[index]), scale));
    return { columns, rows, totals, grandTotal: atlasSumDecimal(totals, scale) };
}
class AtlasPivotTable {
    records = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "records" }] : /* istanbul ignore next */ []));
    row = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "row" }] : /* istanbul ignore next */ []));
    column = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "column" }] : /* istanbul ignore next */ []));
    measure = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "measure" }] : /* istanbul ignore next */ []));
    scale = input(2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scale" }] : /* istanbul ignore next */ []));
    label = input("Pivot totals", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    rowLabel = input("Group", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowLabel" }] : /* istanbul ignore next */ []));
    cellSelected = output();
    result = computed(() => {
        try {
            if (this.records().length > 50000)
                throw new Error("Limit this local pivot to 50,000 records or supply server aggregates.");
            if (new Set(this.records().map(this.column())).size > 24 ||
                new Set(this.records().map(this.row())).size > 500)
                throw new Error("Choose coarser dimensions: at most 24 columns and 500 row groups.");
            const data = atlasPivot(this.records(), this.row(), this.column(), this.measure(), this.scale());
            return { data, error: "" };
        }
        catch (error) {
            return {
                data: null,
                error: error instanceof Error
                    ? error.message
                    : "Unable to aggregate records.",
            };
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "result" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPivotTable, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasPivotTable, isStandalone: true, selector: "atlas-pivot-table", inputs: { records: { classPropertyName: "records", publicName: "records", isSignal: true, isRequired: true, transformFunction: null }, row: { classPropertyName: "row", publicName: "row", isSignal: true, isRequired: true, transformFunction: null }, column: { classPropertyName: "column", publicName: "column", isSignal: true, isRequired: true, transformFunction: null }, measure: { classPropertyName: "measure", publicName: "measure", isSignal: true, isRequired: true, transformFunction: null }, scale: { classPropertyName: "scale", publicName: "scale", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, rowLabel: { classPropertyName: "rowLabel", publicName: "rowLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { cellSelected: "cellSelected" }, ngImport: i0, template: `
    @if (result().data; as pivot) {
      <div class="atlas-table-scroll">
        <table class="atlas-table atlas-pivot-table">
          <caption>
            {{
              label()
            }}
            ·
            {{
              records().length
            }}
            supplied records
          </caption>
          <thead>
            <tr>
              <th scope="col">{{ rowLabel() }}</th>
              @for (column of pivot.columns; track column) {
                <th scope="col">{{ column }}</th>
              }
              <th scope="col">Total</th>
            </tr>
          </thead>
          <tbody>
            @for (row of pivot.rows; track row.label) {
              <tr>
                <th scope="row">{{ row.label }}</th>
                @for (value of row.values; track $index) {
                  <td>
                    <button
                      type="button"
                      class="atlas-pivot-cell"
                      [attr.aria-label]="
                        row.label + ', ' + pivot.columns[$index] + ': ' + value
                      "
                      (click)="
                        cellSelected.emit({
                          row: row.label,
                          column: pivot.columns[$index],
                        })
                      "
                    >
                      {{ value }}
                    </button>
                  </td>
                }
                <td>{{ row.total }}</td>
              </tr>
            } @empty {
              <tr>
                <td [attr.colspan]="pivot.columns.length + 2">
                  No matching records.
                </td>
              </tr>
            }
          </tbody>
          <tfoot>
            <tr>
              <th scope="row">Total</th>
              @for (value of pivot.totals; track $index) {
                <td>{{ value }}</td>
              }
              <td>{{ pivot.grandTotal }}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    } @else {
      <p role="alert">{{ result().error }}</p>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPivotTable, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-pivot-table",
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (result().data; as pivot) {
      <div class="atlas-table-scroll">
        <table class="atlas-table atlas-pivot-table">
          <caption>
            {{
              label()
            }}
            ·
            {{
              records().length
            }}
            supplied records
          </caption>
          <thead>
            <tr>
              <th scope="col">{{ rowLabel() }}</th>
              @for (column of pivot.columns; track column) {
                <th scope="col">{{ column }}</th>
              }
              <th scope="col">Total</th>
            </tr>
          </thead>
          <tbody>
            @for (row of pivot.rows; track row.label) {
              <tr>
                <th scope="row">{{ row.label }}</th>
                @for (value of row.values; track $index) {
                  <td>
                    <button
                      type="button"
                      class="atlas-pivot-cell"
                      [attr.aria-label]="
                        row.label + ', ' + pivot.columns[$index] + ': ' + value
                      "
                      (click)="
                        cellSelected.emit({
                          row: row.label,
                          column: pivot.columns[$index],
                        })
                      "
                    >
                      {{ value }}
                    </button>
                  </td>
                }
                <td>{{ row.total }}</td>
              </tr>
            } @empty {
              <tr>
                <td [attr.colspan]="pivot.columns.length + 2">
                  No matching records.
                </td>
              </tr>
            }
          </tbody>
          <tfoot>
            <tr>
              <th scope="row">Total</th>
              @for (value of pivot.totals; track $index) {
                <td>{{ value }}</td>
              }
              <td>{{ pivot.grandTotal }}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    } @else {
      <p role="alert">{{ result().error }}</p>
    }
  `,
                }]
        }], propDecorators: { records: [{ type: i0.Input, args: [{ isSignal: true, alias: "records", required: true }] }], row: [{ type: i0.Input, args: [{ isSignal: true, alias: "row", required: true }] }], column: [{ type: i0.Input, args: [{ isSignal: true, alias: "column", required: true }] }], measure: [{ type: i0.Input, args: [{ isSignal: true, alias: "measure", required: true }] }], scale: [{ type: i0.Input, args: [{ isSignal: true, alias: "scale", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], rowLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowLabel", required: false }] }], cellSelected: [{ type: i0.Output, args: ["cellSelected"] }] } });
function atlasChartDomain(points) {
    const values = points.map((point) => point.value).filter(Number.isFinite);
    let min = 0, max = 0;
    for (const value of values) {
        min = Math.min(min, value);
        max = Math.max(max, value);
    }
    return { min, max: max === min ? min + 1 : max };
}
class AtlasChart {
    points = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "points" }] : /* istanbul ignore next */ []));
    type = input("bar", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    label = input("Chart", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    selected = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    pointSelected = output();
    Math = Math;
    visible = computed(() => this.points()
        .filter((point) => Number.isFinite(point.value))
        .slice(0, 24), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    omitted = computed(() => this.points().length - this.visible().length, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "omitted" }] : /* istanbul ignore next */ []));
    domain = computed(() => atlasChartDomain(this.visible()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "domain" }] : /* istanbul ignore next */ []));
    ticks = computed(() => Array.from({ length: 5 }, (_, index) => this.domain().min * (1 - index / 4) + this.domain().max * (index / 4)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ticks" }] : /* istanbul ignore next */ []));
    line = computed(() => this.visible()
        .map((point, index) => `${this.x(index)},${this.y(point.value)}`)
        .join(" "), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "line" }] : /* istanbul ignore next */ []));
    x(index) {
        return 65 + ((index + 0.5) * 555) / Math.max(1, this.visible().length);
    }
    y(value) {
        const { min, max } = this.domain();
        const scale = Math.max(Math.abs(min), Math.abs(max));
        return (230 - ((value / scale - min / scale) / (max / scale - min / scale)) * 210);
    }
    barWidth() {
        return Math.min(56, 380 / Math.max(1, this.visible().length));
    }
    tickLabel(value) {
        return new Intl.NumberFormat(undefined, {
            notation: "compact",
            maximumFractionDigits: 1,
        }).format(value);
    }
    choose(point) {
        this.selected.set(point.id);
        this.pointSelected.emit(point);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasChart, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasChart, isStandalone: true, selector: "atlas-chart", inputs: { points: { classPropertyName: "points", publicName: "points", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selected: "selectedChange", pointSelected: "pointSelected" }, ngImport: i0, template: `
    <figure class="atlas-chart">
      <figcaption>{{ label() }}</figcaption>
      <svg
        viewBox="0 0 640 280"
        role="group"
        [attr.aria-label]="label() + '. Select a point or use the data table.'"
      >
        @for (tick of ticks(); track $index) {
          <line
            x1="65"
            x2="620"
            [attr.y1]="y(tick)"
            [attr.y2]="y(tick)"
            class="atlas-chart-grid"
          />
          <text x="58" [attr.y]="y(tick) + 4" text-anchor="end">
            {{ tickLabel(tick) }}
          </text>
        }
        <line
          x1="65"
          x2="620"
          [attr.y1]="y(0)"
          [attr.y2]="y(0)"
          class="atlas-chart-axis"
        />
        @if (type() === "line") {
          <polyline [attr.points]="line()" class="atlas-chart-line" />
        }
        @for (point of visible(); track point.id) {
          @if (type() === "bar") {
            <rect
              role="button"
              tabindex="0"
              [attr.aria-label]="point.label + ': ' + point.value"
              [attr.aria-pressed]="selected() === point.id"
              [attr.x]="x($index) - barWidth() / 2"
              [attr.y]="y(Math.max(0, point.value))"
              [attr.width]="barWidth()"
              [attr.height]="Math.max(2, Math.abs(y(point.value) - y(0)))"
              class="atlas-chart-mark"
              (click)="choose(point)"
              (keydown.enter)="choose(point)"
              (keydown.space)="$event.preventDefault(); choose(point)"
            />
          } @else {
            <circle
              role="button"
              tabindex="0"
              [attr.aria-label]="point.label + ': ' + point.value"
              [attr.aria-pressed]="selected() === point.id"
              [attr.cx]="x($index)"
              [attr.cy]="y(point.value)"
              r="5"
              class="atlas-chart-mark"
              (click)="choose(point)"
              (keydown.enter)="choose(point)"
              (keydown.space)="$event.preventDefault(); choose(point)"
            />
          }
          <text [attr.x]="x($index)" y="259" text-anchor="middle">
            {{
              point.label.length > 10
                ? point.label.slice(0, 9) + "…"
                : point.label
            }}
          </text>
        }
      </svg>
      @if (!visible().length) {
        <p role="status">No chart data.</p>
      }
      @if (omitted()) {
        <p role="status">
          {{ omitted() }} points omitted: charts show at most 24 finite values.
          Use the complete source for analysis.
        </p>
      }
      <details>
        <summary>Chart data</summary>
        <table class="atlas-table">
          <thead>
            <tr>
              <th scope="col">Category</th>
              <th scope="col">Value</th>
            </tr>
          </thead>
          <tbody>
            @for (point of visible(); track point.id) {
              <tr>
                <th scope="row">{{ point.label }}</th>
                <td>{{ point.value }}</td>
              </tr>
            }
          </tbody>
        </table>
      </details>
    </figure>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasChart, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-chart",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <figure class="atlas-chart">
      <figcaption>{{ label() }}</figcaption>
      <svg
        viewBox="0 0 640 280"
        role="group"
        [attr.aria-label]="label() + '. Select a point or use the data table.'"
      >
        @for (tick of ticks(); track $index) {
          <line
            x1="65"
            x2="620"
            [attr.y1]="y(tick)"
            [attr.y2]="y(tick)"
            class="atlas-chart-grid"
          />
          <text x="58" [attr.y]="y(tick) + 4" text-anchor="end">
            {{ tickLabel(tick) }}
          </text>
        }
        <line
          x1="65"
          x2="620"
          [attr.y1]="y(0)"
          [attr.y2]="y(0)"
          class="atlas-chart-axis"
        />
        @if (type() === "line") {
          <polyline [attr.points]="line()" class="atlas-chart-line" />
        }
        @for (point of visible(); track point.id) {
          @if (type() === "bar") {
            <rect
              role="button"
              tabindex="0"
              [attr.aria-label]="point.label + ': ' + point.value"
              [attr.aria-pressed]="selected() === point.id"
              [attr.x]="x($index) - barWidth() / 2"
              [attr.y]="y(Math.max(0, point.value))"
              [attr.width]="barWidth()"
              [attr.height]="Math.max(2, Math.abs(y(point.value) - y(0)))"
              class="atlas-chart-mark"
              (click)="choose(point)"
              (keydown.enter)="choose(point)"
              (keydown.space)="$event.preventDefault(); choose(point)"
            />
          } @else {
            <circle
              role="button"
              tabindex="0"
              [attr.aria-label]="point.label + ': ' + point.value"
              [attr.aria-pressed]="selected() === point.id"
              [attr.cx]="x($index)"
              [attr.cy]="y(point.value)"
              r="5"
              class="atlas-chart-mark"
              (click)="choose(point)"
              (keydown.enter)="choose(point)"
              (keydown.space)="$event.preventDefault(); choose(point)"
            />
          }
          <text [attr.x]="x($index)" y="259" text-anchor="middle">
            {{
              point.label.length > 10
                ? point.label.slice(0, 9) + "…"
                : point.label
            }}
          </text>
        }
      </svg>
      @if (!visible().length) {
        <p role="status">No chart data.</p>
      }
      @if (omitted()) {
        <p role="status">
          {{ omitted() }} points omitted: charts show at most 24 finite values.
          Use the complete source for analysis.
        </p>
      }
      <details>
        <summary>Chart data</summary>
        <table class="atlas-table">
          <thead>
            <tr>
              <th scope="col">Category</th>
              <th scope="col">Value</th>
            </tr>
          </thead>
          <tbody>
            @for (point of visible(); track point.id) {
              <tr>
                <th scope="row">{{ point.label }}</th>
                <td>{{ point.value }}</td>
              </tr>
            }
          </tbody>
        </table>
      </details>
    </figure>
  `,
                }]
        }], propDecorators: { points: [{ type: i0.Input, args: [{ isSignal: true, alias: "points", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], selected: [{ type: i0.Input, args: [{ isSignal: true, alias: "selected", required: false }] }, { type: i0.Output, args: ["selectedChange"] }], pointSelected: [{ type: i0.Output, args: ["pointSelected"] }] } });
function atlasDashboardOrder(ids, order) {
    return [...new Set([...order.filter((id) => ids.includes(id)), ...ids])];
}
function atlasMovePanel(ids, id, target) {
    if (!ids.includes(id) || !ids.includes(target) || id === target)
        return [...ids];
    const next = ids.filter((value) => value !== id);
    next.splice(ids.indexOf(target), 0, id);
    return next;
}
class AtlasDashboardPanel {
    id = input.required({ ...(ngDevMode ? { debugName: "id" } : /* istanbul ignore next */ {}), alias: "atlasDashboardPanel" });
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    template = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDashboardPanel, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.7", type: AtlasDashboardPanel, isStandalone: true, selector: "ng-template[atlasDashboardPanel]", inputs: { id: { classPropertyName: "id", publicName: "atlasDashboardPanel", isSignal: true, isRequired: true, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDashboardPanel, decorators: [{
            type: Directive,
            args: [{ selector: "ng-template[atlasDashboardPanel]" }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "atlasDashboardPanel", required: true }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }] } });
class AtlasDashboard {
    panels = contentChildren(AtlasDashboardPanel, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panels" }] : /* istanbul ignore next */ []));
    order = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "order" }] : /* istanbul ignore next */ []));
    dragged = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dragged" }] : /* istanbul ignore next */ []));
    announcement = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "announcement" }] : /* istanbul ignore next */ []));
    ordered = computed(() => atlasDashboardOrder(this.panels().map((panel) => panel.id()), this.order()).map((id) => this.panels().find((panel) => panel.id() === id)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ordered" }] : /* istanbul ignore next */ []));
    move(id, direction) {
        const ids = this.ordered().map((panel) => panel.id()), index = ids.indexOf(id), target = ids[index + direction];
        if (target)
            this.reorder(id, target);
    }
    reorder(id, target) {
        this.order.set(atlasMovePanel(this.ordered().map((panel) => panel.id()), id, target));
        this.announcement.set(`Panel moved to position ${this.order().indexOf(id) + 1}.`);
    }
    start(event, id) {
        this.dragged.set(id);
        event.dataTransfer?.setData("text/plain", id);
        if (event.dataTransfer)
            event.dataTransfer.effectAllowed = "move";
    }
    allowDrop(event) {
        if (this.dragged())
            event.preventDefault();
    }
    drop(event, target) {
        const id = this.dragged();
        if (!id)
            return;
        event.preventDefault();
        this.reorder(id, target);
        this.dragged.set(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDashboard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasDashboard, isStandalone: true, selector: "atlas-dashboard", inputs: { order: { classPropertyName: "order", publicName: "order", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { order: "orderChange" }, queries: [{ propertyName: "panels", predicate: AtlasDashboardPanel, isSignal: true }], ngImport: i0, template: `
    <p class="atlas-muted">
      Drag a panel handle or use its Earlier/Later buttons to change the layout.
    </p>
    <div class="atlas-dashboard">
      @for (panel of ordered(); track panel.id()) {
        <section
          class="atlas-dashboard-panel"
          [attr.aria-label]="panel.title()"
          (dragover)="allowDrop($event)"
          (drop)="drop($event, panel.id())"
        >
          <header>
            <strong>{{ panel.title() }}</strong>
            <div>
              <button
                atlasButton
                type="button"
                draggable="true"
                [attr.aria-label]="'Drag ' + panel.title()"
                (dragstart)="start($event, panel.id())"
                (dragend)="dragged.set(null)"
              >
                ⠿
              </button>
              <button
                atlasButton
                type="button"
                [disabled]="$first"
                [attr.aria-label]="'Move ' + panel.title() + ' earlier'"
                (click)="move(panel.id(), -1)"
              >
                ←
              </button>
              <button
                atlasButton
                type="button"
                [disabled]="$last"
                [attr.aria-label]="'Move ' + panel.title() + ' later'"
                (click)="move(panel.id(), 1)"
              >
                →
              </button>
            </div>
          </header>
          <div class="atlas-dashboard-content">
            <ng-container [ngTemplateOutlet]="panel.template" />
          </div>
        </section>
      }
    </div>
    <p role="status" class="atlas-muted">{{ announcement() }}</p>
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDashboard, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-dashboard",
                    imports: [NgTemplateOutlet, AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <p class="atlas-muted">
      Drag a panel handle or use its Earlier/Later buttons to change the layout.
    </p>
    <div class="atlas-dashboard">
      @for (panel of ordered(); track panel.id()) {
        <section
          class="atlas-dashboard-panel"
          [attr.aria-label]="panel.title()"
          (dragover)="allowDrop($event)"
          (drop)="drop($event, panel.id())"
        >
          <header>
            <strong>{{ panel.title() }}</strong>
            <div>
              <button
                atlasButton
                type="button"
                draggable="true"
                [attr.aria-label]="'Drag ' + panel.title()"
                (dragstart)="start($event, panel.id())"
                (dragend)="dragged.set(null)"
              >
                ⠿
              </button>
              <button
                atlasButton
                type="button"
                [disabled]="$first"
                [attr.aria-label]="'Move ' + panel.title() + ' earlier'"
                (click)="move(panel.id(), -1)"
              >
                ←
              </button>
              <button
                atlasButton
                type="button"
                [disabled]="$last"
                [attr.aria-label]="'Move ' + panel.title() + ' later'"
                (click)="move(panel.id(), 1)"
              >
                →
              </button>
            </div>
          </header>
          <div class="atlas-dashboard-content">
            <ng-container [ngTemplateOutlet]="panel.template" />
          </div>
        </section>
      }
    </div>
    <p role="status" class="atlas-muted">{{ announcement() }}</p>
  `,
                }]
        }], propDecorators: { panels: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => AtlasDashboardPanel), { isSignal: true }] }], order: [{ type: i0.Input, args: [{ isSignal: true, alias: "order", required: false }] }, { type: i0.Output, args: ["orderChange"] }] } });

function atlasDate(date) {
    if (!validCalendarDate(date))
        throw new Error("Invalid calendar date.");
    const [y, m, d] = date.split("-").map(Number);
    const result = new Date(0);
    result.setUTCFullYear(y, m - 1, d);
    result.setUTCHours(0, 0, 0, 0);
    return result;
}
function iso(date) {
    const year = date.getUTCFullYear();
    if (!Number.isFinite(date.getTime()) || year < 1 || year > 9999)
        throw new Error("Calendar supports years 0001–9999.");
    return `${String(year).padStart(4, "0")}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
}
function atlasShiftDate(date, days) {
    if (!Number.isInteger(days))
        throw new Error("Days must be an integer.");
    const value = atlasDate(date);
    value.setUTCDate(value.getUTCDate() + days);
    return iso(value);
}
function atlasShiftMonth(date, months) {
    if (!Number.isInteger(months))
        throw new Error("Months must be an integer.");
    const value = atlasDate(date), day = value.getUTCDate();
    value.setUTCDate(1);
    value.setUTCMonth(value.getUTCMonth() + months);
    const target = value.getUTCMonth();
    value.setUTCDate(day);
    if (value.getUTCMonth() !== target)
        value.setUTCDate(0);
    return iso(value);
}
function atlasCalendarDays(month, weekStartsOn = 1) {
    const first = atlasDate(month + "-01");
    const offset = (first.getUTCDay() - weekStartsOn + 7) % 7;
    return Array.from({ length: 42 }, (_, index) => {
        try {
            return atlasShiftDate(month + "-01", index - offset);
        }
        catch {
            return "";
        }
    });
}
function atlasEventsOn(events, date) {
    if (!validCalendarDate(date))
        return [];
    return events.filter((event) => validCalendarDate(event.date) &&
        (!event.endDate ||
            (validCalendarDate(event.endDate) && event.endDate >= event.date)) &&
        event.date <= date &&
        (event.endDate ?? event.date) >= date);
}
class AtlasCalendar {
    today = new Date();
    initial = `${this.today.getFullYear()}-${String(this.today.getMonth() + 1).padStart(2, "0")}-${String(this.today.getDate()).padStart(2, "0")}`;
    month = model(this.initial.slice(0, 7), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "month" }] : /* istanbul ignore next */ []));
    selectedDate = model(this.initial, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedDate" }] : /* istanbul ignore next */ []));
    events = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    weekStartsOn = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "weekStartsOn" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    label = input("Calendar", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    eventSelected = output();
    host = inject(ElementRef);
    days = computed(() => {
        try {
            return atlasCalendarDays(this.month(), this.weekStartsOn());
        }
        catch {
            return [];
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "days" }] : /* istanbul ignore next */ []));
    weekdays = computed(() => this.weekStartsOn() === 1
        ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        : ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "weekdays" }] : /* istanbul ignore next */ []));
    tabstop = computed(() => this.selectedDate().startsWith(this.month()) &&
        this.days().includes(this.selectedDate())
        ? this.selectedDate()
        : this.month() + "-01", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabstop" }] : /* istanbul ignore next */ []));
    heading = computed(() => {
        try {
            return new Intl.DateTimeFormat(undefined, {
                month: "long",
                year: "numeric",
                timeZone: "UTC",
            }).format(atlasDate(this.month() + "-01"));
        }
        catch {
            return this.month();
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []));
    on(date) {
        return atlasEventsOn(this.events(), date);
    }
    dayLabel(date) {
        if (!date)
            return "Outside calendar range";
        return (new Intl.DateTimeFormat(undefined, {
            dateStyle: "full",
            timeZone: "UTC",
        }).format(atlasDate(date)) + `, ${this.on(date).length} events`);
    }
    canNavigate(delta) {
        if (this.disabled())
            return false;
        try {
            atlasShiftMonth(this.month() + "-01", delta);
            return true;
        }
        catch {
            return false;
        }
    }
    navigate(delta) {
        if (this.canNavigate(delta))
            this.month.set(atlasShiftMonth(this.month() + "-01", delta).slice(0, 7));
    }
    choose(date) {
        if (this.disabled() || !validCalendarDate(date))
            return;
        this.selectedDate.set(date);
        this.month.set(date.slice(0, 7));
    }
    key(event, date) {
        if (this.disabled())
            return;
        let next;
        try {
            switch (event.key) {
                case "ArrowLeft":
                    next = atlasShiftDate(date, -1);
                    break;
                case "ArrowRight":
                    next = atlasShiftDate(date, 1);
                    break;
                case "ArrowUp":
                    next = atlasShiftDate(date, -7);
                    break;
                case "ArrowDown":
                    next = atlasShiftDate(date, 7);
                    break;
                case "Home":
                    next = atlasShiftDate(date, -((atlasDate(date).getUTCDay() - this.weekStartsOn() + 7) % 7));
                    break;
                case "End":
                    next = atlasShiftDate(date, 6 - ((atlasDate(date).getUTCDay() - this.weekStartsOn() + 7) % 7));
                    break;
                case "PageUp":
                    next = atlasShiftMonth(date, -1);
                    break;
                case "PageDown":
                    next = atlasShiftMonth(date, 1);
                    break;
                default:
                    return;
            }
        }
        catch {
            event.preventDefault();
            return;
        }
        event.preventDefault();
        this.choose(next);
        const host = this.host.nativeElement;
        requestAnimationFrame(() => {
            if (host.isConnected)
                host
                    .querySelector(`[data-calendar-date="${next}"]`)
                    ?.focus();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCalendar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasCalendar, isStandalone: true, selector: "atlas-calendar", inputs: { month: { classPropertyName: "month", publicName: "month", isSignal: true, isRequired: false, transformFunction: null }, selectedDate: { classPropertyName: "selectedDate", publicName: "selectedDate", isSignal: true, isRequired: false, transformFunction: null }, events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: false, transformFunction: null }, weekStartsOn: { classPropertyName: "weekStartsOn", publicName: "weekStartsOn", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { month: "monthChange", selectedDate: "selectedDateChange", eventSelected: "eventSelected" }, ngImport: i0, template: `
    <section class="atlas-calendar" [attr.aria-label]="label()">
      <header>
        <button
          atlasButton
          type="button"
          aria-label="Previous month"
          [disabled]="!canNavigate(-1)"
          (click)="navigate(-1)"
        >
          ←
        </button>
        <h3 aria-live="polite">{{ heading() }}</h3>
        <button
          atlasButton
          type="button"
          aria-label="Next month"
          [disabled]="!canNavigate(1)"
          (click)="navigate(1)"
        >
          →
        </button>
      </header>
      @if (days().length) {
        <table role="grid" [attr.aria-label]="heading()">
          <thead>
            <tr>
              @for (day of weekdays(); track day) {
                <th scope="col">{{ day }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (week of [0, 1, 2, 3, 4, 5]; track week) {
              <tr>
                @for (
                  day of days().slice(week * 7, week * 7 + 7);
                  track $index
                ) {
                  <td
                    [class.atlas-calendar-outside]="!day.startsWith(month())"
                    [attr.aria-selected]="selectedDate() === day"
                  >
                    <button
                      type="button"
                      [disabled]="!day || disabled()"
                      [attr.data-calendar-date]="day"
                      [attr.tabindex]="tabstop() === day ? 0 : -1"
                      [attr.aria-label]="dayLabel(day)"
                      (click)="choose(day)"
                      (keydown)="key($event, day)"
                    >
                      <strong>{{ day ? +day.slice(-2) : "" }}</strong>
                      @if (on(day).length) {
                        <small
                          >{{ on(day).length }}
                          {{ on(day).length === 1 ? "event" : "events" }}</small
                        >
                      }
                    </button>
                  </td>
                }
              </tr>
            }
          </tbody>
        </table>
        <section class="atlas-calendar-agenda" aria-label="Selected day agenda">
          <h4>{{ selectedDate() }} · Agenda</h4>
          @for (event of on(selectedDate()); track event.id) {
            <button
              atlasButton
              type="button"
              [disabled]="disabled()"
              (click)="eventSelected.emit(event)"
            >
              <strong>{{ event.title }}</strong
              ><span>{{ event.description }}</span>
            </button>
          } @empty {
            <p class="atlas-muted">No events for this date.</p>
          }
        </section>
      } @else {
        <p role="alert">Supply a valid month in YYYY-MM format.</p>
      }
    </section>
  `, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasCalendar, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-calendar",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <section class="atlas-calendar" [attr.aria-label]="label()">
      <header>
        <button
          atlasButton
          type="button"
          aria-label="Previous month"
          [disabled]="!canNavigate(-1)"
          (click)="navigate(-1)"
        >
          ←
        </button>
        <h3 aria-live="polite">{{ heading() }}</h3>
        <button
          atlasButton
          type="button"
          aria-label="Next month"
          [disabled]="!canNavigate(1)"
          (click)="navigate(1)"
        >
          →
        </button>
      </header>
      @if (days().length) {
        <table role="grid" [attr.aria-label]="heading()">
          <thead>
            <tr>
              @for (day of weekdays(); track day) {
                <th scope="col">{{ day }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (week of [0, 1, 2, 3, 4, 5]; track week) {
              <tr>
                @for (
                  day of days().slice(week * 7, week * 7 + 7);
                  track $index
                ) {
                  <td
                    [class.atlas-calendar-outside]="!day.startsWith(month())"
                    [attr.aria-selected]="selectedDate() === day"
                  >
                    <button
                      type="button"
                      [disabled]="!day || disabled()"
                      [attr.data-calendar-date]="day"
                      [attr.tabindex]="tabstop() === day ? 0 : -1"
                      [attr.aria-label]="dayLabel(day)"
                      (click)="choose(day)"
                      (keydown)="key($event, day)"
                    >
                      <strong>{{ day ? +day.slice(-2) : "" }}</strong>
                      @if (on(day).length) {
                        <small
                          >{{ on(day).length }}
                          {{ on(day).length === 1 ? "event" : "events" }}</small
                        >
                      }
                    </button>
                  </td>
                }
              </tr>
            }
          </tbody>
        </table>
        <section class="atlas-calendar-agenda" aria-label="Selected day agenda">
          <h4>{{ selectedDate() }} · Agenda</h4>
          @for (event of on(selectedDate()); track event.id) {
            <button
              atlasButton
              type="button"
              [disabled]="disabled()"
              (click)="eventSelected.emit(event)"
            >
              <strong>{{ event.title }}</strong
              ><span>{{ event.description }}</span>
            </button>
          } @empty {
            <p class="atlas-muted">No events for this date.</p>
          }
        </section>
      } @else {
        <p role="alert">Supply a valid month in YYYY-MM format.</p>
      }
    </section>
  `,
                }]
        }], propDecorators: { month: [{ type: i0.Input, args: [{ isSignal: true, alias: "month", required: false }] }, { type: i0.Output, args: ["monthChange"] }], selectedDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedDate", required: false }] }, { type: i0.Output, args: ["selectedDateChange"] }], events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: false }] }], weekStartsOn: [{ type: i0.Input, args: [{ isSignal: true, alias: "weekStartsOn", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], eventSelected: [{ type: i0.Output, args: ["eventSelected"] }] } });

/** Plain structured content only: no HTML, scripts, style strings, URLs or embedded objects. */
function atlasRichText(document) {
    return document.blocks.map((block) => block.text).join("\n");
}
function atlasUpdateRichBlock(document, id, patch) {
    return {
        blocks: document.blocks.map((block) => block.id === id ? { ...block, ...patch } : block),
    };
}
class AtlasRichText extends AtlasChoiceState {
    value = model({ blocks: [] }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    message = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    text = computed(() => atlasRichText(this.value()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    element = inject(ElementRef);
    sequence = 0;
    focus(options) {
        this.element.nativeElement
            .querySelector("textarea,button")
            ?.focus(options);
    }
    edit(id, patch) {
        if (this.disabled() || this.readonly())
            return;
        this.value.set(atlasUpdateRichBlock(this.value(), id, patch));
        this.touch.emit();
    }
    add() {
        if (this.disabled() || this.readonly())
            return;
        let id;
        do {
            id = `block-${++this.sequence}`;
        } while (this.value().blocks.some((block) => block.id === id));
        this.value.update((value) => ({
            blocks: [...value.blocks, { id, kind: "paragraph", text: "" }],
        }));
        this.message.set("Paragraph added.");
        this.touch.emit();
    }
    remove(id) {
        if (this.disabled() || this.readonly())
            return;
        this.value.update((value) => ({
            blocks: value.blocks.filter((block) => block.id !== id),
        }));
        this.message.set("Block removed.");
        this.touch.emit();
    }
    move(id, direction) {
        if (this.disabled() || this.readonly())
            return;
        const blocks = [...this.value().blocks], index = blocks.findIndex((block) => block.id === id), to = index + direction;
        if (index < 0 || to < 0 || to >= blocks.length)
            return;
        [blocks[index], blocks[to]] = [blocks[to], blocks[index]];
        this.value.set({ blocks });
        this.message.set(`Block moved to position ${to + 1}.`);
        this.touch.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRichText, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasRichText, isStandalone: true, selector: "atlas-rich-text", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { listeners: { "focusout": "touch.emit()" } }, usesInheritance: true, ngImport: i0, template: `
    <fieldset
      class="atlas-rich-editor"
      [id]="controlId()"
      [disabled]="disabled()"
      [attr.aria-invalid]="invalid() && touched()"
      [attr.aria-describedby]="describedBy()"
    >
      <legend>{{ label() }}</legend>
      <div class="atlas-rich-tools">
        <button
          atlasButton
          type="button"
          [disabled]="readonly()"
          (click)="add()"
        >
          Add paragraph</button
        ><span class="atlas-muted"
          >{{ text().length }} characters · Structured content</span
        >
      </div>
      @for (block of value().blocks; track block.id) {
        <div class="atlas-rich-block">
          <div class="atlas-rich-tools">
            <label
              >Block {{ $index + 1 }} type<select
                atlasInput
                [value]="block.kind"
                [disabled]="readonly()"
                (change)="edit(block.id, { kind: $any($event.target).value })"
              >
                <option value="paragraph">Paragraph</option>
                <option value="heading">Heading</option>
                <option value="bullet">Bullet</option>
              </select></label
            >
            <button
              atlasButton
              type="button"
              [disabled]="readonly()"
              [attr.aria-label]="'Bold block ' + ($index + 1)"
              [attr.aria-pressed]="!!block.bold"
              (click)="edit(block.id, { bold: !block.bold })"
            >
              <strong>B</strong>
            </button>
            <button
              atlasButton
              type="button"
              [disabled]="readonly()"
              [attr.aria-label]="'Italic block ' + ($index + 1)"
              [attr.aria-pressed]="!!block.italic"
              (click)="edit(block.id, { italic: !block.italic })"
            >
              <em>I</em>
            </button>
            <button
              atlasButton
              type="button"
              [disabled]="readonly() || $first"
              [attr.aria-label]="'Move block ' + ($index + 1) + ' up'"
              (click)="move(block.id, -1)"
            >
              ↑</button
            ><button
              atlasButton
              type="button"
              [disabled]="readonly() || $last"
              [attr.aria-label]="'Move block ' + ($index + 1) + ' down'"
              (click)="move(block.id, 1)"
            >
              ↓
            </button>
            <button
              atlasButton
              type="button"
              [disabled]="readonly()"
              [attr.aria-label]="'Remove block ' + ($index + 1)"
              (click)="remove(block.id)"
            >
              Remove
            </button>
          </div>
          <textarea
            atlasInput
            [attr.aria-label]="'Block ' + ($index + 1) + ' text'"
            [value]="block.text"
            [readOnly]="readonly()"
            rows="3"
            (input)="edit(block.id, { text: $any($event.target).value })"
          ></textarea>
        </div>
      } @empty {
        <p>No text blocks. Add a paragraph to begin.</p>
      }
      <section class="atlas-rich-preview" aria-label="Formatted preview">
        <h4>Formatted preview</h4>
        @for (block of value().blocks; track block.id) {
          @switch (block.kind) {
            @case ("heading") {
              <h3
                [class.atlas-rich-bold]="block.bold"
                [class.atlas-rich-italic]="block.italic"
              >
                {{ block.text }}
              </h3>
            }
            @case ("bullet") {
              <ul>
                <li
                  [class.atlas-rich-bold]="block.bold"
                  [class.atlas-rich-italic]="block.italic"
                >
                  {{ block.text }}
                </li>
              </ul>
            }
            @default {
              <p
                [class.atlas-rich-bold]="block.bold"
                [class.atlas-rich-italic]="block.italic"
              >
                {{ block.text }}
              </p>
            }
          }
        }
      </section>
      <p role="status">{{ message() }}</p>
    </fieldset>
  `, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasRichText, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-rich-text",
                    imports: [AtlasButton, AtlasInput],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { "(focusout)": "touch.emit()" },
                    template: `
    <fieldset
      class="atlas-rich-editor"
      [id]="controlId()"
      [disabled]="disabled()"
      [attr.aria-invalid]="invalid() && touched()"
      [attr.aria-describedby]="describedBy()"
    >
      <legend>{{ label() }}</legend>
      <div class="atlas-rich-tools">
        <button
          atlasButton
          type="button"
          [disabled]="readonly()"
          (click)="add()"
        >
          Add paragraph</button
        ><span class="atlas-muted"
          >{{ text().length }} characters · Structured content</span
        >
      </div>
      @for (block of value().blocks; track block.id) {
        <div class="atlas-rich-block">
          <div class="atlas-rich-tools">
            <label
              >Block {{ $index + 1 }} type<select
                atlasInput
                [value]="block.kind"
                [disabled]="readonly()"
                (change)="edit(block.id, { kind: $any($event.target).value })"
              >
                <option value="paragraph">Paragraph</option>
                <option value="heading">Heading</option>
                <option value="bullet">Bullet</option>
              </select></label
            >
            <button
              atlasButton
              type="button"
              [disabled]="readonly()"
              [attr.aria-label]="'Bold block ' + ($index + 1)"
              [attr.aria-pressed]="!!block.bold"
              (click)="edit(block.id, { bold: !block.bold })"
            >
              <strong>B</strong>
            </button>
            <button
              atlasButton
              type="button"
              [disabled]="readonly()"
              [attr.aria-label]="'Italic block ' + ($index + 1)"
              [attr.aria-pressed]="!!block.italic"
              (click)="edit(block.id, { italic: !block.italic })"
            >
              <em>I</em>
            </button>
            <button
              atlasButton
              type="button"
              [disabled]="readonly() || $first"
              [attr.aria-label]="'Move block ' + ($index + 1) + ' up'"
              (click)="move(block.id, -1)"
            >
              ↑</button
            ><button
              atlasButton
              type="button"
              [disabled]="readonly() || $last"
              [attr.aria-label]="'Move block ' + ($index + 1) + ' down'"
              (click)="move(block.id, 1)"
            >
              ↓
            </button>
            <button
              atlasButton
              type="button"
              [disabled]="readonly()"
              [attr.aria-label]="'Remove block ' + ($index + 1)"
              (click)="remove(block.id)"
            >
              Remove
            </button>
          </div>
          <textarea
            atlasInput
            [attr.aria-label]="'Block ' + ($index + 1) + ' text'"
            [value]="block.text"
            [readOnly]="readonly()"
            rows="3"
            (input)="edit(block.id, { text: $any($event.target).value })"
          ></textarea>
        </div>
      } @empty {
        <p>No text blocks. Add a paragraph to begin.</p>
      }
      <section class="atlas-rich-preview" aria-label="Formatted preview">
        <h4>Formatted preview</h4>
        @for (block of value().blocks; track block.id) {
          @switch (block.kind) {
            @case ("heading") {
              <h3
                [class.atlas-rich-bold]="block.bold"
                [class.atlas-rich-italic]="block.italic"
              >
                {{ block.text }}
              </h3>
            }
            @case ("bullet") {
              <ul>
                <li
                  [class.atlas-rich-bold]="block.bold"
                  [class.atlas-rich-italic]="block.italic"
                >
                  {{ block.text }}
                </li>
              </ul>
            }
            @default {
              <p
                [class.atlas-rich-bold]="block.bold"
                [class.atlas-rich-italic]="block.italic"
              >
                {{ block.text }}
              </p>
            }
          }
        }
      </section>
      <p role="status">{{ message() }}</p>
    </fieldset>
  `,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }] } });

function atlasVirtualRange(total, scroll, height, rowHeight, overscan = 4) {
    total = Math.max(0, Math.floor(Number.isFinite(total) ? total : 0));
    rowHeight = Math.max(1, Number.isFinite(rowHeight) ? rowHeight : 32);
    height = Math.max(1, Number.isFinite(height) ? height : 300);
    overscan = Math.max(0, Math.min(20, Math.floor(Number.isFinite(overscan) ? overscan : 4)));
    const offset = Math.max(0, Math.min(Number.isFinite(scroll) ? scroll : 0, Math.max(0, total * rowHeight - height)));
    const start = Math.max(0, Math.floor(offset / rowHeight) - overscan), end = Math.min(total, Math.ceil((offset + height) / rowHeight) + overscan);
    return {
        start,
        end,
        top: start * rowHeight,
        bottom: Math.max(0, (total - end) * rowHeight),
    };
}
let gridSequence = 0;
class AtlasVirtualGrid {
    rows = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    columns = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    keyField = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "keyField" }] : /* istanbul ignore next */ []));
    label = input("Virtual grid", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    height = input(360, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    rowHeight = input(36, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowHeight" }] : /* istanbul ignore next */ []));
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    error = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    retry = output();
    selectedKey = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedKey" }] : /* istanbul ignore next */ []));
    rowActivated = output();
    scroll = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scroll" }] : /* istanbul ignore next */ []));
    viewport = viewChild("viewport", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewport" }] : /* istanbul ignore next */ []));
    id = `atlas-virtual-${++gridSequence}`;
    size = computed(() => Math.max(24, Math.min(80, Number.isFinite(this.rowHeight()) ? this.rowHeight() : 36)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    viewportHeight = computed(() => Math.max(160, Math.min(800, Number.isFinite(this.height()) ? this.height() : 360)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewportHeight" }] : /* istanbul ignore next */ []));
    range = computed(() => atlasVirtualRange(this.rows().length, this.scroll(), this.viewportHeight() - 32, this.size()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "range" }] : /* istanbul ignore next */ []));
    visible = computed(() => this.loading() || this.error()
        ? []
        : this.rows().slice(this.range().start, this.range().end), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    activeIndex = computed(() => this.rows().findIndex((row) => this.rowKey(row) === this.selectedKey()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    activeDescendant = computed(() => !this.loading() &&
        !this.error() &&
        this.activeIndex() >= this.range().start &&
        this.activeIndex() < this.range().end
        ? this.rowId(this.activeIndex())
        : null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeDescendant" }] : /* istanbul ignore next */ []));
    tableWidth = computed(() => this.columns().reduce((sum, column) => sum + (column.width || 180), 0), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableWidth" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            this.rows();
            this.size();
            const viewport = this.viewport()?.nativeElement;
            if (!viewport)
                return;
            viewport.scrollTop = 0;
            this.scroll.set(0);
        });
    }
    rowId(index) {
        return `${this.id}-${index}`;
    }
    rowKey(row) {
        return String(row[this.keyField()]);
    }
    value(row, column) {
        return column.format ? column.format(row) : String(row[column.key] ?? "");
    }
    select(index) {
        if (this.loading() || this.error() || !this.rows()[index])
            return;
        this.selectedKey.set(this.rowKey(this.rows()[index]));
        const viewport = this.viewport()?.nativeElement;
        if (!viewport)
            return;
        const top = index * this.size(), bottom = top + this.size();
        if (top < viewport.scrollTop)
            viewport.scrollTop = top;
        else if (bottom > viewport.scrollTop + this.viewportHeight() - 32)
            viewport.scrollTop = bottom - (this.viewportHeight() - 32);
        this.scroll.set(viewport.scrollTop);
        viewport.focus();
    }
    key(event) {
        if (this.loading() || this.error() || !this.rows().length)
            return;
        const index = this.activeIndex();
        let next;
        switch (event.key) {
            case "ArrowDown":
                next = index + 1;
                break;
            case "ArrowUp":
                next = index < 0 ? 0 : index - 1;
                break;
            case "PageDown":
                next =
                    Math.max(0, index) +
                        Math.floor((this.viewportHeight() - 32) / this.size());
                break;
            case "PageUp":
                next =
                    Math.max(0, index) -
                        Math.floor((this.viewportHeight() - 32) / this.size());
                break;
            case "Home":
                next = 0;
                break;
            case "End":
                next = this.rows().length - 1;
                break;
            case "Enter":
                if (index >= 0) {
                    event.preventDefault();
                    this.rowActivated.emit(this.rows()[index]);
                }
                return;
            default:
                return;
        }
        event.preventDefault();
        this.select(Math.max(0, Math.min(this.rows().length - 1, next)));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasVirtualGrid, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasVirtualGrid, isStandalone: true, selector: "atlas-virtual-grid", inputs: { rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: true, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, keyField: { classPropertyName: "keyField", publicName: "keyField", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, rowHeight: { classPropertyName: "rowHeight", publicName: "rowHeight", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, selectedKey: { classPropertyName: "selectedKey", publicName: "selectedKey", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { retry: "retry", selectedKey: "selectedKeyChange", rowActivated: "rowActivated" }, viewQueries: [{ propertyName: "viewport", first: true, predicate: ["viewport"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div
      #viewport
      class="atlas-virtual-grid"
      role="grid"
      tabindex="0"
      [attr.aria-label]="label()"
      [attr.aria-rowcount]="rows().length + 1"
      [attr.aria-colcount]="columns().length"
      [attr.aria-activedescendant]="activeDescendant()"
      [attr.aria-busy]="loading()"
      [style.height.px]="viewportHeight()"
      [style.--atlas-virtual-row-height]="size() + 'px'"
      (scroll)="scroll.set(viewport.scrollTop)"
      (keydown)="key($event)"
    >
      <table
        role="presentation"
        class="atlas-table"
        [style.min-width.px]="tableWidth()"
      >
        <colgroup>
          @for (column of columns(); track column.key) {
            <col [style.width.px]="column.width || 180" />
          }
        </colgroup>
        <thead role="rowgroup">
          <tr role="row" aria-rowindex="1">
            @for (column of columns(); track column.key) {
              <th role="columnheader">{{ column.label }}</th>
            }
          </tr>
        </thead>
        <tbody role="rowgroup">
          @if (!loading() && !error()) {
            <tr
              aria-hidden="true"
              role="presentation"
              class="atlas-virtual-spacer"
            >
              <td
                [attr.colspan]="columns().length"
                [style.height.px]="range().top"
              ></td>
            </tr>
            @for (row of visible(); track rowKey(row)) {
              <tr
                role="row"
                class="atlas-virtual-data"
                [id]="rowId(range().start + $index)"
                [attr.aria-rowindex]="range().start + $index + 2"
                [attr.aria-selected]="selectedKey() === rowKey(row)"
                [class.selected]="selectedKey() === rowKey(row)"
                (click)="select(range().start + $index)"
                (dblclick)="rowActivated.emit(row)"
              >
                @for (column of columns(); track column.key) {
                  <td
                    role="gridcell"
                    [style.text-align]="column.align || 'left'"
                    [title]="value(row, column)"
                  >
                    {{ value(row, column) }}
                  </td>
                }
              </tr>
            }
            <tr
              aria-hidden="true"
              role="presentation"
              class="atlas-virtual-spacer"
            >
              <td
                [attr.colspan]="columns().length"
                [style.height.px]="range().bottom"
              ></td>
            </tr>
          }
        </tbody>
      </table>
    </div>
    @if (loading()) {
      <p role="status">Loading records…</p>
    } @else if (error()) {
      <p role="alert">{{ error() }}</p>
      <button type="button" (click)="retry.emit()">Retry</button>
    } @else if (!rows().length) {
      <p role="status">No matching records.</p>
    }
    <p class="atlas-muted" role="status">
      {{ rows().length }} records · {{ visible().length }} rendered rows. Arrow
      keys, Page Up/Down, Home/End navigate; Enter opens a record.
    </p>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasVirtualGrid, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-virtual-grid",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <div
      #viewport
      class="atlas-virtual-grid"
      role="grid"
      tabindex="0"
      [attr.aria-label]="label()"
      [attr.aria-rowcount]="rows().length + 1"
      [attr.aria-colcount]="columns().length"
      [attr.aria-activedescendant]="activeDescendant()"
      [attr.aria-busy]="loading()"
      [style.height.px]="viewportHeight()"
      [style.--atlas-virtual-row-height]="size() + 'px'"
      (scroll)="scroll.set(viewport.scrollTop)"
      (keydown)="key($event)"
    >
      <table
        role="presentation"
        class="atlas-table"
        [style.min-width.px]="tableWidth()"
      >
        <colgroup>
          @for (column of columns(); track column.key) {
            <col [style.width.px]="column.width || 180" />
          }
        </colgroup>
        <thead role="rowgroup">
          <tr role="row" aria-rowindex="1">
            @for (column of columns(); track column.key) {
              <th role="columnheader">{{ column.label }}</th>
            }
          </tr>
        </thead>
        <tbody role="rowgroup">
          @if (!loading() && !error()) {
            <tr
              aria-hidden="true"
              role="presentation"
              class="atlas-virtual-spacer"
            >
              <td
                [attr.colspan]="columns().length"
                [style.height.px]="range().top"
              ></td>
            </tr>
            @for (row of visible(); track rowKey(row)) {
              <tr
                role="row"
                class="atlas-virtual-data"
                [id]="rowId(range().start + $index)"
                [attr.aria-rowindex]="range().start + $index + 2"
                [attr.aria-selected]="selectedKey() === rowKey(row)"
                [class.selected]="selectedKey() === rowKey(row)"
                (click)="select(range().start + $index)"
                (dblclick)="rowActivated.emit(row)"
              >
                @for (column of columns(); track column.key) {
                  <td
                    role="gridcell"
                    [style.text-align]="column.align || 'left'"
                    [title]="value(row, column)"
                  >
                    {{ value(row, column) }}
                  </td>
                }
              </tr>
            }
            <tr
              aria-hidden="true"
              role="presentation"
              class="atlas-virtual-spacer"
            >
              <td
                [attr.colspan]="columns().length"
                [style.height.px]="range().bottom"
              ></td>
            </tr>
          }
        </tbody>
      </table>
    </div>
    @if (loading()) {
      <p role="status">Loading records…</p>
    } @else if (error()) {
      <p role="alert">{{ error() }}</p>
      <button type="button" (click)="retry.emit()">Retry</button>
    } @else if (!rows().length) {
      <p role="status">No matching records.</p>
    }
    <p class="atlas-muted" role="status">
      {{ rows().length }} records · {{ visible().length }} rendered rows. Arrow
      keys, Page Up/Down, Home/End navigate; Enter opens a record.
    </p>
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: true }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], keyField: [{ type: i0.Input, args: [{ isSignal: true, alias: "keyField", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], rowHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowHeight", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], retry: [{ type: i0.Output, args: ["retry"] }], selectedKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedKey", required: false }] }, { type: i0.Output, args: ["selectedKeyChange"] }], rowActivated: [{ type: i0.Output, args: ["rowActivated"] }], viewport: [{ type: i0.ViewChild, args: ["viewport", { isSignal: true }] }] } });

function atlasProgressValue(value, max = 100) {
    return value === null || !Number.isFinite(value)
        ? null
        : Math.max(0, Math.min(value, Number.isFinite(max) && max > 0 ? max : 100));
}
class AtlasProgress {
    value = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    max = input(100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    label = input("Progress", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    limit = computed(() => Number.isFinite(this.max()) && this.max() > 0 ? this.max() : 100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "limit" }] : /* istanbul ignore next */ []));
    amount = computed(() => atlasProgressValue(this.value(), this.limit()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "amount" }] : /* istanbul ignore next */ []));
    percent = computed(() => Math.round(((this.amount() ?? 0) / this.limit()) * 100), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "percent" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasProgress, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasProgress, isStandalone: true, selector: "atlas-progress", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<div class="atlas-progress">
    <div>
      <span>{{ label() }}</span
      ><span>{{ amount() === null ? "In progress" : percent() + "%" }}</span>
    </div>
    <progress
      [attr.aria-label]="label()"
      [max]="limit()"
      [attr.value]="amount()"
    ></progress>
  </div>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasProgress, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-progress",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<div class="atlas-progress">
    <div>
      <span>{{ label() }}</span
      ><span>{{ amount() === null ? "In progress" : percent() + "%" }}</span>
    </div>
    <progress
      [attr.aria-label]="label()"
      [max]="limit()"
      [attr.value]="amount()"
    ></progress>
  </div>`,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });
class AtlasNotice {
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    message = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    tone = input("info", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []));
    urgent = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "urgent" }] : /* istanbul ignore next */ []));
    dismissible = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dismissible" }] : /* istanbul ignore next */ []));
    dismissed = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasNotice, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasNotice, isStandalone: true, selector: "atlas-notice", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, urgent: { classPropertyName: "urgent", publicName: "urgent", isSignal: true, isRequired: false, transformFunction: null }, dismissible: { classPropertyName: "dismissible", publicName: "dismissible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dismissed: "dismissed" }, ngImport: i0, template: `<section class="atlas-notice" [attr.data-tone]="tone()">
    <div [attr.role]="urgent() ? 'alert' : 'status'" aria-atomic="true">
      <strong>{{ title() }}</strong>
      <p>{{ message() }}</p>
    </div>
    @if (dismissible()) {
      <button
        atlasButton
        type="button"
        [attr.aria-label]="'Dismiss ' + title()"
        (click)="dismissed.emit()"
      >
        ×
      </button>
    }
  </section>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasNotice, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-notice",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<section class="atlas-notice" [attr.data-tone]="tone()">
    <div [attr.role]="urgent() ? 'alert' : 'status'" aria-atomic="true">
      <strong>{{ title() }}</strong>
      <p>{{ message() }}</p>
    </div>
    @if (dismissible()) {
      <button
        atlasButton
        type="button"
        [attr.aria-label]="'Dismiss ' + title()"
        (click)="dismissed.emit()"
      >
        ×
      </button>
    }
  </section>`,
                }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], urgent: [{ type: i0.Input, args: [{ isSignal: true, alias: "urgent", required: false }] }], dismissible: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissible", required: false }] }], dismissed: [{ type: i0.Output, args: ["dismissed"] }] } });
class AtlasStatusBar {
    message = input("Ready", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    tone = input("info", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasStatusBar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasStatusBar, isStandalone: true, selector: "atlas-status-bar", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<footer class="atlas-status-bar" [attr.data-tone]="tone()">
    <span role="status" aria-atomic="true">{{ message() }}</span
    ><span class="atlas-status-detail"><ng-content /></span>
  </footer>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasStatusBar, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-status-bar",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<footer class="atlas-status-bar" [attr.data-tone]="tone()">
    <span role="status" aria-atomic="true">{{ message() }}</span
    ><span class="atlas-status-detail"><ng-content /></span>
  </footer>`,
                }]
        }], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }] } });
class AtlasLoadingRegion {
    busy = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []));
    label = input("Content", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    message = input("Loading…", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasLoadingRegion, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasLoadingRegion, isStandalone: true, selector: "atlas-loading-region", inputs: { busy: { classPropertyName: "busy", publicName: "busy", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<section
      class="atlas-loading-region"
      [attr.aria-label]="label()"
      [attr.aria-busy]="busy()"
    >
      <div
        [attr.inert]="busy() ? '' : null"
        [class.atlas-loading-content]="busy()"
      >
        <ng-content />
      </div>
      @if (busy()) {
        <div class="atlas-loading-mask" aria-hidden="true">
          <span class="atlas-spinner"></span><strong>{{ message() }}</strong>
        </div>
      }
    </section>
    <span class="atlas-feedback-sr" role="status">{{
      busy() ? message() : ""
    }}</span>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasLoadingRegion, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-loading-region",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<section
      class="atlas-loading-region"
      [attr.aria-label]="label()"
      [attr.aria-busy]="busy()"
    >
      <div
        [attr.inert]="busy() ? '' : null"
        [class.atlas-loading-content]="busy()"
      >
        <ng-content />
      </div>
      @if (busy()) {
        <div class="atlas-loading-mask" aria-hidden="true">
          <span class="atlas-spinner"></span><strong>{{ message() }}</strong>
        </div>
      }
    </section>
    <span class="atlas-feedback-sr" role="status">{{
      busy() ? message() : ""
    }}</span>`,
                }]
        }], propDecorators: { busy: [{ type: i0.Input, args: [{ isSignal: true, alias: "busy", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }] } });
function atlasPromptError(value, required, maxLength) {
    if (required && !value.trim())
        return "Enter a value to continue.";
    const limit = Number.isFinite(maxLength)
        ? Math.max(1, Math.floor(maxLength))
        : 200;
    if (value.length > limit)
        return `Use at most ${limit} characters.`;
    return "";
}
let feedbackSequence = 0;
class AtlasMessageBox {
    open = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    value = model("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    kind = input("alert", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "kind" }] : /* istanbul ignore next */ []));
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    message = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    promptLabel = input("Value", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "promptLabel" }] : /* istanbul ignore next */ []));
    required = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []));
    maxLength = input(200, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []));
    acceptLabel = input("OK", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "acceptLabel" }] : /* istanbul ignore next */ []));
    cancelLabel = input("Cancel", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelLabel" }] : /* istanbul ignore next */ []));
    danger = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "danger" }] : /* istanbul ignore next */ []));
    result = output();
    error = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    id = `atlas-prompt-${++feedbackSequence}`;
    dialog = viewChild(AtlasDialog, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dialog" }] : /* istanbul ignore next */ []));
    completed = true;
    constructor() {
        effect((onCleanup) => {
            if (this.open()) {
                this.completed = false;
                this.error.set("");
                const selector = this.kind() === "prompt"
                    ? "input"
                    : this.kind() === "confirm"
                        ? "[data-atlas-cancel]"
                        : "[data-atlas-accept]";
                const dialog = this.dialog();
                const frame = requestAnimationFrame(() => {
                    const element = dialog?.dialog()?.nativeElement;
                    if (this.open() &&
                        element?.open &&
                        element.contains(document.activeElement))
                        element.querySelector(selector)?.focus();
                });
                onCleanup(() => cancelAnimationFrame(frame));
            }
        });
    }
    finish(action) {
        if (this.completed)
            return;
        if (action === "accept" && this.kind() === "prompt") {
            const error = atlasPromptError(this.value(), this.required(), this.maxLength());
            if (error) {
                this.error.set(error);
                return;
            }
        }
        this.completed = true;
        this.open.set(false);
        this.result.emit({ action, value: this.value() });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMessageBox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasMessageBox, isStandalone: true, selector: "atlas-message-box", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, kind: { classPropertyName: "kind", publicName: "kind", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, promptLabel: { classPropertyName: "promptLabel", publicName: "promptLabel", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, maxLength: { classPropertyName: "maxLength", publicName: "maxLength", isSignal: true, isRequired: false, transformFunction: null }, acceptLabel: { classPropertyName: "acceptLabel", publicName: "acceptLabel", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null }, danger: { classPropertyName: "danger", publicName: "danger", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange", value: "valueChange", result: "result" }, viewQueries: [{ propertyName: "dialog", first: true, predicate: AtlasDialog, descendants: true, isSignal: true }], ngImport: i0, template: ` <atlas-dialog
    [open]="open()"
    (openChange)="open.set($event)"
    [title]="title()"
    (dismissed)="finish('cancel')"
    ><p>{{ message() }}</p>
    @if (kind() === "prompt") {
      <label class="atlas-prompt-label" [attr.for]="id">{{
        promptLabel()
      }}</label
      ><input
        atlasInput
        autofocus
        [id]="id"
        [value]="value()"
        [attr.aria-invalid]="!!error()"
        [attr.aria-describedby]="error() ? id + '-error' : null"
        (input)="value.set($any($event.target).value); error.set('')"
        (keydown.enter)="$event.preventDefault(); finish('accept')"
      />
      @if (error()) {
        <p [id]="id + '-error'" role="alert" class="atlas-field-error">
          {{ error() }}
        </p>
      }
    }
    <div atlasDialogActions class="atlas-feedback-actions">
      @if (kind() !== "alert") {
        <button
          atlasButton
          type="button"
          data-atlas-cancel
          (click)="finish('cancel')"
        >
          {{ cancelLabel() }}
        </button>
      }
      <button
        atlasButton
        type="button"
        data-atlas-accept
        [variant]="danger() ? 'danger' : 'primary'"
        (click)="finish('accept')"
      >
        {{ acceptLabel() }}
      </button>
    </div></atlas-dialog
  >`, isInline: true, dependencies: [{ kind: "component", type: AtlasDialog, selector: "atlas-dialog", inputs: ["open", "title", "busy"], outputs: ["openChange", "dismissed"] }, { kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMessageBox, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-message-box",
                    imports: [AtlasDialog, AtlasButton, AtlasInput],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: ` <atlas-dialog
    [open]="open()"
    (openChange)="open.set($event)"
    [title]="title()"
    (dismissed)="finish('cancel')"
    ><p>{{ message() }}</p>
    @if (kind() === "prompt") {
      <label class="atlas-prompt-label" [attr.for]="id">{{
        promptLabel()
      }}</label
      ><input
        atlasInput
        autofocus
        [id]="id"
        [value]="value()"
        [attr.aria-invalid]="!!error()"
        [attr.aria-describedby]="error() ? id + '-error' : null"
        (input)="value.set($any($event.target).value); error.set('')"
        (keydown.enter)="$event.preventDefault(); finish('accept')"
      />
      @if (error()) {
        <p [id]="id + '-error'" role="alert" class="atlas-field-error">
          {{ error() }}
        </p>
      }
    }
    <div atlasDialogActions class="atlas-feedback-actions">
      @if (kind() !== "alert") {
        <button
          atlasButton
          type="button"
          data-atlas-cancel
          (click)="finish('cancel')"
        >
          {{ cancelLabel() }}
        </button>
      }
      <button
        atlasButton
        type="button"
        data-atlas-accept
        [variant]="danger() ? 'danger' : 'primary'"
        (click)="finish('accept')"
      >
        {{ acceptLabel() }}
      </button>
    </div></atlas-dialog
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }, { type: i0.Output, args: ["openChange"] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], kind: [{ type: i0.Input, args: [{ isSignal: true, alias: "kind", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], promptLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "promptLabel", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], maxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLength", required: false }] }], acceptLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "acceptLabel", required: false }] }], cancelLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelLabel", required: false }] }], danger: [{ type: i0.Input, args: [{ isSignal: true, alias: "danger", required: false }] }], result: [{ type: i0.Output, args: ["result"] }], dialog: [{ type: i0.ViewChild, args: [i0.forwardRef(() => AtlasDialog), { isSignal: true }] }] } });
/** Viewport-clamped placement, flipping above when the lower edge would overflow. */
function atlasFeedbackPosition(anchor, panel, viewport) {
    const gap = 8;
    return {
        left: Math.max(gap, Math.min(anchor.left, viewport.width - panel.width - gap)),
        top: Math.max(gap, Math.min(anchor.bottom + gap + panel.height <= viewport.height - gap
            ? anchor.bottom + gap
            : anchor.top - panel.height - gap, viewport.height - panel.height - gap)),
    };
}
class AtlasPopover {
    label = input("More information", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    opened = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    id = `atlas-popover-${++feedbackSequence}`;
    panel = viewChild("panel", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []));
    trigger = viewChild("trigger", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    constructor() {
        const destroy = inject(DestroyRef);
        afterNextRender(() => {
            const onScroll = (event) => {
                if (this.opened() &&
                    !this.panel()?.nativeElement.contains(event.target))
                    this.close(false);
            };
            document.addEventListener("scroll", onScroll, true);
            destroy.onDestroy(() => document.removeEventListener("scroll", onScroll, true));
        });
        effect(() => {
            if (this.disabled())
                this.close(false);
        });
    }
    toggle() {
        if (this.disabled())
            return;
        const panel = this.panel()?.nativeElement, trigger = this.trigger()?.nativeElement;
        if (!panel || !trigger)
            return;
        if (panel.matches(":popover-open")) {
            this.close(true);
            return;
        }
        panel.showPopover();
        const at = atlasFeedbackPosition(trigger.getBoundingClientRect(), panel.getBoundingClientRect(), { width: innerWidth, height: innerHeight });
        panel.style.left = `${at.left}px`;
        panel.style.top = `${at.top}px`;
        this.opened.set(true);
        panel.focus({ preventScroll: true });
    }
    close(restore = true) {
        const panel = this.panel()?.nativeElement;
        if (!panel?.matches(":popover-open"))
            return;
        panel.hidePopover();
        this.opened.set(false);
        if (restore)
            this.trigger()?.nativeElement.focus({ preventScroll: true });
    }
    toggled() {
        this.opened.set(this.panel()?.nativeElement.matches(":popover-open") ?? false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPopover, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.7", type: AtlasPopover, isStandalone: true, selector: "atlas-popover", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "window:resize": "close(false)" } }, viewQueries: [{ propertyName: "panel", first: true, predicate: ["panel"], descendants: true, isSignal: true }, { propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }], ngImport: i0, template: `<button
      #trigger
      atlasButton
      type="button"
      aria-haspopup="dialog"
      [attr.aria-expanded]="opened()"
      [attr.aria-controls]="id"
      [disabled]="disabled()"
      (click)="toggle()"
    >
      {{ label() }}
    </button>
    <div
      #panel
      popover="auto"
      role="dialog"
      tabindex="-1"
      class="atlas-help-popover"
      [id]="id"
      [attr.aria-labelledby]="id + '-title'"
      (toggle)="toggled()"
      (keydown.escape)="
        $event.preventDefault(); $event.stopPropagation(); close(true)
      "
    >
      <header>
        <strong [id]="id + '-title'">{{ title() }}</strong
        ><button
          atlasButton
          type="button"
          aria-label="Close help"
          (click)="close(true)"
        >
          ×
        </button>
      </header>
      <div><ng-content /></div>
    </div>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPopover, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-popover",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { "(window:resize)": "close(false)" },
                    template: `<button
      #trigger
      atlasButton
      type="button"
      aria-haspopup="dialog"
      [attr.aria-expanded]="opened()"
      [attr.aria-controls]="id"
      [disabled]="disabled()"
      (click)="toggle()"
    >
      {{ label() }}
    </button>
    <div
      #panel
      popover="auto"
      role="dialog"
      tabindex="-1"
      class="atlas-help-popover"
      [id]="id"
      [attr.aria-labelledby]="id + '-title'"
      (toggle)="toggled()"
      (keydown.escape)="
        $event.preventDefault(); $event.stopPropagation(); close(true)
      "
    >
      <header>
        <strong [id]="id + '-title'">{{ title() }}</strong
        ><button
          atlasButton
          type="button"
          aria-label="Close help"
          (click)="close(true)"
        >
          ×
        </button>
      </header>
      <div><ng-content /></div>
    </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], panel: [{ type: i0.ViewChild, args: ["panel", { isSignal: true }] }], trigger: [{ type: i0.ViewChild, args: ["trigger", { isSignal: true }] }] } });
/** Text-only help. Focus or hover opens; Escape dismisses without moving focus. */
class AtlasTooltip {
    label = input("Help", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    text = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    id = `atlas-tooltip-${++feedbackSequence}`;
    tip = viewChild("tip", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tip" }] : /* istanbul ignore next */ []));
    trigger = viewChild("trigger", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    timer;
    constructor() {
        const destroy = inject(DestroyRef);
        afterNextRender(() => {
            const onScroll = () => this.hide();
            document.addEventListener("scroll", onScroll, true);
            destroy.onDestroy(() => document.removeEventListener("scroll", onScroll, true));
        });
        destroy.onDestroy(() => clearTimeout(this.timer));
    }
    stay() {
        clearTimeout(this.timer);
    }
    show() {
        this.stay();
        const tip = this.tip()?.nativeElement, trigger = this.trigger()?.nativeElement;
        if (!tip || !trigger)
            return;
        if (!tip.matches(":popover-open"))
            tip.showPopover();
        const at = atlasFeedbackPosition(trigger.getBoundingClientRect(), tip.getBoundingClientRect(), { width: innerWidth, height: innerHeight });
        tip.style.left = `${at.left}px`;
        tip.style.top = `${at.top}px`;
    }
    deferHide() {
        this.stay();
        this.timer = setTimeout(() => {
            if (document.activeElement !== this.trigger()?.nativeElement)
                this.hide();
        }, 150);
    }
    hide() {
        this.stay();
        const tip = this.tip()?.nativeElement;
        if (tip?.matches(":popover-open"))
            tip.hidePopover();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTooltip, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.7", type: AtlasTooltip, isStandalone: true, selector: "atlas-tooltip", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, text: { classPropertyName: "text", publicName: "text", isSignal: true, isRequired: true, transformFunction: null } }, host: { listeners: { "window:resize": "hide()", "document:keydown.escape": "hide()" } }, viewQueries: [{ propertyName: "tip", first: true, predicate: ["tip"], descendants: true, isSignal: true }, { propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }], ngImport: i0, template: `<button
      #trigger
      atlasButton
      type="button"
      class="atlas-help-trigger"
      [attr.aria-label]="label()"
      [attr.aria-describedby]="id"
      (focus)="show()"
      (blur)="deferHide()"
      (mouseenter)="show()"
      (mouseleave)="deferHide()"
      (click)="show()"
    >
      ?
    </button>
    <div
      #tip
      popover="manual"
      role="tooltip"
      class="atlas-tooltip"
      [id]="id"
      (mouseenter)="stay()"
      (mouseleave)="deferHide()"
    >
      {{ text() }}
    </div>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasTooltip, decorators: [{
            type: Component,
            args: [{
                    selector: "atlas-tooltip",
                    imports: [AtlasButton],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { "(window:resize)": "hide()", "(document:keydown.escape)": "hide()" },
                    template: `<button
      #trigger
      atlasButton
      type="button"
      class="atlas-help-trigger"
      [attr.aria-label]="label()"
      [attr.aria-describedby]="id"
      (focus)="show()"
      (blur)="deferHide()"
      (mouseenter)="show()"
      (mouseleave)="deferHide()"
      (click)="show()"
    >
      ?
    </button>
    <div
      #tip
      popover="manual"
      role="tooltip"
      class="atlas-tooltip"
      [id]="id"
      (mouseenter)="stay()"
      (mouseleave)="deferHide()"
    >
      {{ text() }}
    </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], text: [{ type: i0.Input, args: [{ isSignal: true, alias: "text", required: true }] }], tip: [{ type: i0.ViewChild, args: ["tip", { isSignal: true }] }], trigger: [{ type: i0.ViewChild, args: ["trigger", { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ATLAS_TASK, AtlasAccordionSection, AtlasActivityTimeline, AtlasAttachmentList, AtlasAutocomplete, AtlasBadge, AtlasButton, AtlasCalendar, AtlasCell, AtlasChart, AtlasCheckTree, AtlasCheckboxGroup, AtlasChoiceOverlay, AtlasChoiceState, AtlasCommandToolbar, AtlasContextMenu, AtlasDashboard, AtlasDashboardPanel, AtlasDatasheet, AtlasDateInput, AtlasDateRangeInput, AtlasDecimalInput, AtlasDialog, AtlasEditableGrid, AtlasEntryState, AtlasField, AtlasFieldset, AtlasFilterBuilder, AtlasHierarchyBase, AtlasIcon, AtlasInput, AtlasItemSelector, AtlasLatestRequest, AtlasListTemplate, AtlasListView, AtlasLoadingRegion, AtlasLookup, AtlasMasterDetail, AtlasMenuButton, AtlasMessageBox, AtlasMultiSelect, AtlasNotice, AtlasNumberInput, AtlasPanel, AtlasPivotTable, AtlasPopover, AtlasPopupMenu, AtlasProgress, AtlasPropertySheet, AtlasRadioGroup, AtlasRecordNavigator, AtlasRichText, AtlasRowDetail, AtlasSelect, AtlasSplitButton, AtlasSplitPane, AtlasStartMenu, AtlasStatusBar, AtlasTab, AtlasTable, AtlasTabs, AtlasTextInput, AtlasTextarea, AtlasToggle, AtlasTooltip, AtlasTotalsPanel, AtlasTree, AtlasTreeGrid, AtlasTreeSelect, AtlasUploadQueue, AtlasValidationNavigator, AtlasValidationSummary, AtlasValueControl, AtlasVirtualGrid, AtlasWindow, AtlasWorkspace, WorkspaceService, atlasCalendarDays, atlasChartDomain, atlasCheckLeaves, atlasCheckState, atlasCommandAllowed, atlasDashboardOrder, atlasDate, atlasEventsOn, atlasFeedbackPosition, atlasGroupRows, atlasHeaderBands, atlasMoveItems, atlasMovePanel, atlasPivot, atlasProgressValue, atlasPromptError, atlasRichText, atlasShiftDate, atlasShiftMonth, atlasSumDecimal, atlasSummaryQueryKey, atlasToggleChecks, atlasToolbarCapacity, atlasTransferItems, atlasUpdateRichBlock, atlasVirtualRange, atlasVisibleCommands, clampAtlasSplit, dateRangeError, dependentRecords, filterCollection, filterLookup, findTreeNode, flattenTree, lookupCell, matchesColumnFilters, matchesFilterRules, nextAtlasTab, nextLookupIndex, pageCollection, parseLocaleNumber, replaceEditedRow, sortByColumns, sortCollection, toggleChoice, validCalendarDate, validateEditRow };
//# sourceMappingURL=bqatlas-ui.mjs.map
