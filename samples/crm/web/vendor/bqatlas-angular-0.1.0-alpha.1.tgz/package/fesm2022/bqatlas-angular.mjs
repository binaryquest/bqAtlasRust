import * as i0 from '@angular/core';
import { Injectable, inject, signal, computed, input, forwardRef, ChangeDetectionStrategy, Component, DestroyRef, effect, untracked, ElementRef, Injector, afterNextRender, model, output } from '@angular/core';
import { WorkspaceService, AtlasValueControl, ATLAS_TASK, AtlasButton, AtlasTable, AtlasInput, AtlasLatestRequest, AtlasLookup, AtlasDialog } from '@bqatlas/ui';
import { NgComponentOutlet, NgTemplateOutlet } from '@angular/common';
import * as i1 from '@angular/forms';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, FormsModule } from '@angular/forms';
import { parseDecimalUnits } from '@bqatlas/contracts';

class ApiError extends Error {
    status;
    problem;
    constructor(status, problem) {
        super(problem.detail ?? problem.title ?? `Request failed (${status})`);
        this.status = status;
        this.problem = problem;
    }
}
class AtlasApi {
    csrf;
    generation = 0;
    onUnauthorized = () => { };
    clearSession() {
        this.generation++;
        this.csrf = undefined;
    }
    async request(path, method = "GET", body, signal, version, idempotencyKey, accept = "application/json") {
        if (!path.startsWith("/") || path.startsWith("//"))
            throw new Error("API paths must be same-origin absolute paths.");
        const generation = this.generation;
        const headers = { Accept: accept };
        if (body !== undefined)
            headers["Content-Type"] = "application/json";
        if (version !== undefined)
            headers["If-Match"] = `"${version}"`;
        if (idempotencyKey !== undefined)
            headers["Idempotency-Key"] = idempotencyKey;
        if (!["GET", "HEAD"].includes(method)) {
            if (!this.csrf) {
                const token = (await this.request("/api/v1/session/csrf", "GET", undefined, signal)).token;
                if (generation !== this.generation)
                    throw new DOMException("Session changed", "AbortError");
                this.csrf = token;
            }
            headers["X-BQATLAS-CSRF"] = this.csrf;
        }
        const response = await fetch(path, {
            method,
            body: body === undefined ? undefined : JSON.stringify(body),
            headers,
            credentials: "same-origin",
            signal,
            cache: "no-store",
        });
        if (!response.ok) {
            const problem = await response
                .json()
                .catch(() => ({ title: response.statusText }));
            if (response.status === 401 &&
                path !== "/auth/login" &&
                generation === this.generation) {
                this.clearSession();
                this.onUnauthorized();
            }
            if (problem.code === "csrf_failed")
                this.csrf = undefined;
            throw new ApiError(response.status, problem);
        }
        if (response.status === 204)
            return undefined;
        return response.json();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasApi, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasApi, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasApi, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });
class RestResourceProvider {
    api;
    endpoint;
    constructor(api, endpoint) {
        this.api = api;
        this.endpoint = endpoint;
    }
    query(query, signal) {
        return this.api.request(`${this.endpoint}/query`, "POST", query, signal);
    }
    get(id, signal) {
        return this.api.request(`${this.endpoint}/${encodeURIComponent(id)}`, "GET", undefined, signal);
    }
    create(input, signal) {
        return this.api.request(this.endpoint, "POST", input, signal);
    }
    update(id, input, version, signal) {
        return this.api.request(`${this.endpoint}/${encodeURIComponent(id)}`, "PUT", input, signal, version);
    }
    delete(id, version, signal) {
        return this.api.request(`${this.endpoint}/${encodeURIComponent(id)}`, "DELETE", undefined, signal, version);
    }
}
class RestLookupProvider {
    api;
    endpoint;
    resolve(id, signal) {
        return this.api.request(`${this.endpoint}/${encodeURIComponent(id)}`, "GET", undefined, signal);
    }
    constructor(api, endpoint) {
        this.api = api;
        this.endpoint = endpoint;
    }
    query(request, signal) {
        return this.api.request(this.endpoint, "POST", request, signal);
    }
}

class AtlasSession {
    api = inject(AtlasApi);
    generation = 0;
    workspace = inject(WorkspaceService);
    info = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "info" }] : /* istanbul ignore next */ []));
    manifest = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "manifest" }] : /* istanbul ignore next */ []));
    authenticated = computed(() => this.info()?.authenticated === true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "authenticated" }] : /* istanbul ignore next */ []));
    constructor() {
        this.api.onUnauthorized = () => this.clear();
    }
    has(permission) {
        return (this.authenticated() && this.info().permissions.includes(permission));
    }
    async refresh() {
        const generation = ++this.generation;
        const info = await this.api.request("/api/v1/session");
        if (generation !== this.generation)
            return;
        if (info.id !== this.info()?.id) {
            this.workspace.disposeAll();
            this.manifest.set(null);
        }
        this.info.set(info);
        if (info.authenticated) {
            const manifest = await this.api.request("/api/v1/manifest");
            if (generation !== this.generation)
                return;
            if (manifest.contractVersion !== "1.0")
                throw new Error("Unsupported server contract version.");
            this.manifest.set(manifest);
        }
    }
    async login(email, password) {
        await this.api.request("/auth/login", "POST", { email, password });
        this.api.clearSession();
        await this.refresh();
    }
    async logout() {
        // External logout is submitted as a browser form so the provider redirect can navigate.
        if (this.info()?.authMode === "oidc") {
            const csrf = await this.api.request("/api/v1/session/csrf");
            const form = document.createElement("form");
            form.method = "POST";
            form.action = "/auth/logout";
            const input = document.createElement("input");
            input.type = "hidden";
            input.name = "__RequestVerificationToken";
            input.value = csrf.token;
            form.append(input);
            document.body.append(form);
            this.clear();
            form.submit();
            return;
        }
        await this.api.request("/auth/logout", "POST");
        this.clear();
        await this.refresh();
    }
    clear() {
        this.generation++;
        this.api.clearSession();
        this.workspace.disposeAll();
        this.manifest.set(null);
        this.info.update((info) => info
            ? {
                ...info,
                authenticated: false,
                id: null,
                name: null,
                permissions: [],
            }
            : null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSession, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSession, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasSession, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }], ctorParameters: () => [] });

/** Each editor owns one draft; saved values never share mutable references with the draft. */
class RecordDraft {
    value = signal({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    version = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "version" }] : /* istanbul ignore next */ []));
    dirty = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dirty" }] : /* istanbul ignore next */ []));
    capabilities = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "capabilities" }] : /* istanbul ignore next */ []));
    saved;
    accept(result) {
        this.capabilities.set(result.capabilities ?? null);
        this.saved = structuredClone(result.data);
        this.value.set(structuredClone(result.data));
        this.version.set(result.version);
        this.dirty.set(false);
    }
    initialize(value) {
        this.capabilities.set(null);
        this.saved = undefined;
        this.value.set(structuredClone(value));
        this.version.set(null);
        this.dirty.set(true);
    }
    change(key, value) {
        this.value.update((current) => ({ ...current, [key]: value }));
        this.dirty.set(true);
    }
    revert() {
        if (this.saved) {
            this.value.set(structuredClone(this.saved));
            this.dirty.set(false);
        }
    }
}

/** A string-valued CVA for exact amounts. Invalid draft text is preserved for correction. */
class AtlasDecimalTextInput extends AtlasValueControl {
    required = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []));
    sheetEditor = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sheetEditor" }] : /* istanbul ignore next */ []));
    scale = input(2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scale" }] : /* istanbul ignore next */ []));
    maximum = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "maximum" }] : /* istanbul ignore next */ []));
    invalidText = computed(() => this.value() !== null &&
        this.value() !== "" &&
        parseDecimalUnits(this.value(), this.scale(), this.maximum()) === null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidText" }] : /* istanbul ignore next */ []));
    edit(value) {
        this.commit(value);
    }
    validate(control) {
        return control.value === null ||
            control.value === "" ||
            parseDecimalUnits(control.value, this.scale(), this.maximum()) !== null
            ? null
            : { decimal: true };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDecimalTextInput, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.7", type: AtlasDecimalTextInput, isStandalone: true, selector: "bqatlas-decimal-input", inputs: { required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, sheetEditor: { classPropertyName: "sheetEditor", publicName: "sheetEditor", isSignal: true, isRequired: false, transformFunction: null }, scale: { classPropertyName: "scale", publicName: "scale", isSignal: true, isRequired: false, transformFunction: null }, maximum: { classPropertyName: "maximum", publicName: "maximum", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "atlas-control" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => AtlasDecimalTextInput),
                multi: true,
            },
            {
                provide: NG_VALIDATORS,
                useExisting: forwardRef(() => AtlasDecimalTextInput),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: `<div
    class="atlas-input-shell"
    [class.is-invalid]="invalid() || invalidText()"
  >
    <input
      [attr.data-sheet-editor]="sheetEditor() ? '' : null"
      type="text"
      inputmode="decimal"
      autocomplete="off"
      [id]="controlId()"
      [value]="value() ?? ''"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [required]="required()"
      [attr.aria-required]="required()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid() || invalidText()"
      (input)="edit($any($event.target).value)"
      (blur)="markTouched()"
    />
  </div>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasDecimalTextInput, decorators: [{
            type: Component,
            args: [{
                    selector: "bqatlas-decimal-input",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => AtlasDecimalTextInput),
                            multi: true,
                        },
                        {
                            provide: NG_VALIDATORS,
                            useExisting: forwardRef(() => AtlasDecimalTextInput),
                            multi: true,
                        },
                    ],
                    host: { class: "atlas-control" },
                    template: `<div
    class="atlas-input-shell"
    [class.is-invalid]="invalid() || invalidText()"
  >
    <input
      [attr.data-sheet-editor]="sheetEditor() ? '' : null"
      type="text"
      inputmode="decimal"
      autocomplete="off"
      [id]="controlId()"
      [value]="value() ?? ''"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [required]="required()"
      [attr.aria-required]="required()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-describedby]="describedBy()"
      [attr.aria-invalid]="invalid() || invalidText()"
      (input)="edit($any($event.target).value)"
      (blur)="markTouched()"
    />
  </div>`,
                }]
        }], propDecorators: { required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], sheetEditor: [{ type: i0.Input, args: [{ isSignal: true, alias: "sheetEditor", required: false }] }], scale: [{ type: i0.Input, args: [{ isSignal: true, alias: "scale", required: false }] }], maximum: [{ type: i0.Input, args: [{ isSignal: true, alias: "maximum", required: false }] }] } });

/** Validates drafts without coercing money or timezone-free dates. Server validation remains authoritative. */
function validateFields(fields, row, validators = {}) {
    const errors = {};
    for (const field of fields) {
        if (field.readOnly)
            continue;
        const value = row[field.name];
        const fail = (message) => { errors[field.name] = [message]; };
        const custom = () => {
            if (!Object.hasOwn(validators, field.name))
                return;
            const messages = validators[field.name](structuredClone(value), structuredClone(row), structuredClone(field));
            if (messages.length)
                errors[field.name] = [...(errors[field.name] ?? []), ...messages];
        };
        if (value === null || value === undefined || value === '') {
            if (field.required)
                fail('This field is required.');
            custom();
            continue;
        }
        switch (field.type) {
            case 'string':
            case 'email':
                if (typeof value !== 'string')
                    fail('Enter text.');
                else if (field.required && !value.trim())
                    fail('This field is required.');
                else if (field.maxLength !== null && value.length > field.maxLength)
                    fail(`Use at most ${field.maxLength} characters.`);
                else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))
                    fail('Enter a valid email address.');
                break;
            case 'boolean':
                if (typeof value !== 'boolean')
                    fail('Choose true or false.');
                break;
            case 'integer':
                if (typeof value !== 'number' || !Number.isSafeInteger(value))
                    fail('Enter a whole number within the safe integer range.');
                break;
            case 'decimal':
                if (typeof value !== 'string' || parseDecimalUnits(value, field.scale ?? 2, field.maximum ?? undefined) === null)
                    fail(`Enter a non-negative decimal with at most ${field.scale ?? 2} decimal places.`);
                break;
            case 'enum':
                if (typeof value !== 'string' || !field.options?.includes(value))
                    fail('Choose an available option.');
                break;
            case 'date': {
                if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
                    fail('Enter a valid date.');
                    break;
                }
                const date = new Date(value + 'T00:00:00Z');
                if (Number.isNaN(date.valueOf()) || date.toISOString().slice(0, 10) !== value)
                    fail('Enter a valid date.');
                break;
            }
            default: if (!Object.hasOwn(validators, field.name))
                fail('This field requires a custom editor.');
        }
        custom();
    }
    return errors;
}
function editableValues(fields, row) {
    return Object.fromEntries(fields.filter(field => !field.readOnly).map(field => [field.name, structuredClone(row[field.name])]));
}

function selectListFields(descriptor, names) {
    if (!names)
        return descriptor.fields;
    if (!names.length || new Set(names).size !== names.length)
        throw new Error('List fields must be nonempty and distinct.');
    return names.map(name => {
        const field = descriptor.fields.find(field => field.name === name);
        if (!field)
            throw new Error(`Unknown list field: ${name}`);
        return field;
    });
}
class CrudWorkspace {
    workspace = inject(WorkspaceService);
    session = inject(AtlasSession);
    definitions = new Map();
    revision = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "revision" }] : /* istanbul ignore next */ []));
    returns = new Map();
    openRelated(resource, origin, selected, id, defaults) {
        const feature = this.feature(resource);
        this.descriptor(resource);
        if (feature.editorComponent)
            throw new Error("This custom editor has not registered related-record support.");
        if (!id && !this.session.has(feature.writePermission))
            throw new Error("You cannot create this record.");
        const relation = crypto.randomUUID();
        this.returns.set(relation, selected);
        try {
            const task = this.workspace.open({ screen: "bqatlas.editor", key: relation,
                title: id ? feature.title : `New ${feature.title}`, origin, data: { resource, id, relation, defaults } });
            return { task, cancel: () => this.cancelRelated(relation) };
        }
        catch (error) {
            this.cancelRelated(relation);
            throw error;
        }
    }
    cancelRelated(id) { this.returns.delete(id); }
    async returnRelated(relation, id) {
        const callback = this.returns.get(relation);
        if (!callback)
            throw new Error("The originating field is no longer available. The record remains saved.");
        await callback(id);
        this.returns.delete(relation);
    }
    constructor() {
        this.workspace.register({
            id: "bqatlas.list",
            title: "Records",
            icon: "grid",
            component: CrudList,
            instance: "keyed",
            width: 960,
            height: 610,
        }, {
            id: "bqatlas.editor",
            title: "Record",
            icon: "edit",
            component: CrudEditor,
            instance: "keyed",
            width: 660,
            height: 500,
        });
    }
    register(...features) {
        for (const feature of features) {
            if (this.definitions.has(feature.resource))
                throw new Error(`Duplicate resource: ${feature.resource}`);
            this.definitions.set(feature.resource, feature);
            if (feature.listComponent)
                this.workspace.register({
                    id: feature.resource + ".list",
                    title: feature.title,
                    icon: feature.icon,
                    component: feature.listComponent,
                    instance: "singleton",
                    width: 1000,
                    height: 620,
                });
            if (feature.editorComponent)
                this.workspace.register({
                    id: feature.resource + ".editor",
                    title: feature.title,
                    icon: feature.icon,
                    component: feature.editorComponent,
                    instance: "keyed",
                    width: 1050,
                    height: 690,
                });
        }
    }
    feature(id) {
        const value = this.definitions.get(id);
        if (!value)
            throw new Error(`Unknown feature: ${id}`);
        return value;
    }
    descriptor(id) {
        const value = this.session.manifest()?.resources.find((r) => r.id === id);
        if (!value || !this.session.has(value.readPermission))
            throw new Error("This resource is unavailable.");
        return value;
    }
    menus() {
        return [...this.definitions.values()].filter((f) => this.session
            .manifest()
            ?.resources.some((r) => r.id === f.resource && this.session.has(r.readPermission)));
    }
    openList(resource) {
        const feature = this.feature(resource);
        this.descriptor(resource);
        this.workspace.open({
            screen: feature.listComponent ? resource + ".list" : "bqatlas.list",
            key: resource,
            title: feature.title,
            data: { resource },
        });
    }
    openEditor(resource, id, origin, defaults) {
        const feature = this.feature(resource);
        this.descriptor(resource);
        if (!id && !this.session.has(feature.writePermission))
            throw new Error("You cannot create this record.");
        this.workspace.open({
            screen: feature.editorComponent ? resource + ".editor" : "bqatlas.editor",
            key: `${resource}:${id ?? crypto.randomUUID()}`,
            title: id ? feature.title : `New ${feature.title}`,
            data: { resource, id, defaults },
            origin,
        });
    }
    changed() {
        this.revision.update((v) => v + 1);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: CrudWorkspace, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: CrudWorkspace, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: CrudWorkspace, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }], ctorParameters: () => [] });
class CrudList {
    task = inject(ATLAS_TASK);
    crud = inject(CrudWorkspace);
    session = inject(AtlasSession);
    descriptor = this.crud.descriptor(this.task.data().resource);
    feature = this.crud.feature(this.descriptor.id);
    provider = this.feature.provider?.(inject(AtlasApi), this.descriptor) ?? new RestResourceProvider(inject(AtlasApi), this.descriptor.endpoint);
    columns = selectListFields(this.descriptor, this.feature.listFields).map((f) => ({
        key: f.name,
        label: f.label,
        filterable: f.type !== "boolean",
        format: (row) => f.type === "boolean"
            ? row[f.name]
                ? "Yes"
                : "No"
            : String(row[f.name] ?? ""),
    }));
    rows = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    total = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []));
    loading = signal(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    error = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    request = { page: 0, pageSize: 25, search: "" };
    controller;
    timer;
    constructor() {
        inject(DestroyRef).onDestroy(() => {
            this.controller?.abort();
            clearTimeout(this.timer);
        });
        effect(() => {
            this.crud.revision();
            untracked(() => this.reload());
        });
    }
    query(value) {
        this.request = {
            page: value.page,
            pageSize: value.pageSize,
            search: value.search,
            sort: value.sort.map((s) => ({ field: s.key, direction: s.direction })),
            filters: Object.entries(value.filters)
                .filter(([, v]) => v !== "")
                .map(([field, value]) => ({ field, operator: ["string", "email"].includes(this.descriptor.fields.find(f => f.name === field)?.type ?? "") ? "contains" : "eq", value })),
        };
        clearTimeout(this.timer);
        this.timer = setTimeout(() => void this.reload(), 180);
    }
    async reload() {
        this.controller?.abort();
        const controller = (this.controller = new AbortController());
        this.loading.set(true);
        this.error.set("");
        try {
            const result = await this.provider.query(this.request, controller.signal);
            if (!controller.signal.aborted) {
                this.rows.set(result.items);
                this.total.set(result.total);
            }
        }
        catch (error) {
            if (!controller.signal.aborted)
                this.error.set(error instanceof Error ? error.message : "Unable to load records.");
        }
        finally {
            if (!controller.signal.aborted)
                this.loading.set(false);
        }
    }
    create() {
        this.crud.openEditor(this.descriptor.id, undefined, this.task.id);
    }
    open(row) {
        this.crud.openEditor(this.descriptor.id, String(row[this.descriptor.keyField]), this.task.id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: CrudList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: CrudList, isStandalone: true, selector: "bqatlas-crud-list", ngImport: i0, template: `<section class="bqatlas-view">
    <header class="bqatlas-toolbar">
      <strong>{{ descriptor.title }}</strong
      ><span class="bqatlas-spacer"></span>
      @if (session.has(feature.writePermission)) {
        <button atlasButton variant="primary" (click)="create()">New</button>
      }
      <button atlasButton (click)="reload()">Refresh</button>
    </header>
    <atlas-table
      [rows]="rows()"
      [columns]="columns"
      [keyField]="descriptor.keyField"
      [server]="true"
      [total]="total()"
      [pageSize]="25"
      [loading]="loading()"
      [error]="error()"
      [filterable]="true"
      [multiSort]="true"
      [columnManage]="true"
      [columnFilters]="true"
      (queryChange)="query($event)"
      (retry)="reload()"
      (rowActivated)="open($event)"
    />
  </section>`, isInline: true, dependencies: [{ kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "component", type: AtlasTable, selector: "atlas-table", inputs: ["groupBy", "summaries", "serverSummary", "collapsedGroups", "rows", "columns", "keyField", "pageSize", "columnFilters", "multiSort", "columnManage", "server", "total", "error", "label", "filterable", "selectable", "columnToggle", "loading", "selectedKeys"], outputs: ["collapsedGroupsChange", "rowActivated", "retry", "queryChange", "selectedKeysChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: CrudList, decorators: [{
            type: Component,
            args: [{
                    selector: "bqatlas-crud-list",
                    imports: [AtlasButton, AtlasTable],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<section class="bqatlas-view">
    <header class="bqatlas-toolbar">
      <strong>{{ descriptor.title }}</strong
      ><span class="bqatlas-spacer"></span>
      @if (session.has(feature.writePermission)) {
        <button atlasButton variant="primary" (click)="create()">New</button>
      }
      <button atlasButton (click)="reload()">Refresh</button>
    </header>
    <atlas-table
      [rows]="rows()"
      [columns]="columns"
      [keyField]="descriptor.keyField"
      [server]="true"
      [total]="total()"
      [pageSize]="25"
      [loading]="loading()"
      [error]="error()"
      [filterable]="true"
      [multiSort]="true"
      [columnManage]="true"
      [columnFilters]="true"
      (queryChange)="query($event)"
      (retry)="reload()"
      (rowActivated)="open($event)"
    />
  </section>`,
                }]
        }], ctorParameters: () => [] });
class CrudEditor {
    element = inject((ElementRef));
    injector = inject(Injector);
    focusError(errors) {
        const name = this.descriptor.fields.find(field => errors[field.name]?.length)?.name;
        if (!name)
            return;
        afterNextRender(() => {
            if (this.controller.signal.aborted || this.workspace.activeId() !== this.task.id)
                return;
            const id = this.task.id + '-' + name;
            const root = this.element.nativeElement;
            const control = [...root.querySelectorAll('[id]')].find(element => element.id === id);
            control?.focus();
        }, { injector: this.injector });
    }
    task = inject(ATLAS_TASK);
    crud = inject(CrudWorkspace);
    session = inject(AtlasSession);
    workspace = inject(WorkspaceService);
    descriptor = this.crud.descriptor(this.task.data().resource);
    feature = this.crud.feature(this.descriptor.id);
    draft = new RecordDraft();
    loading = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    errors = signal({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
    canWrite = computed(() => this.session.has(this.feature.writePermission) && this.draft.capabilities()?.edit !== false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canWrite" }] : /* istanbul ignore next */ []));
    provider = this.feature.provider?.(inject(AtlasApi), this.descriptor) ?? new RestResourceProvider(inject(AtlasApi), this.descriptor.endpoint);
    canDelete = computed(() => this.session.has(this.feature.deletePermission) && this.draft.capabilities()?.delete !== false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canDelete" }] : /* istanbul ignore next */ []));
    controller = new AbortController();
    returning = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "returning" }] : /* istanbul ignore next */ []));
    id = this.task.data().id;
    async saveAndReturn() {
        if (this.returning() || this.loading() || this.task.saving())
            return;
        this.returning.set(true);
        try {
            if ((!this.id || this.draft.dirty()) && !(await this.save()))
                return;
            if (!this.id || this.controller.signal.aborted)
                return;
            await this.crud.returnRelated(this.task.data().relation, this.id);
            await this.workspace.requestClose(this.task.id);
        }
        catch (error) {
            this.task.error.set(error instanceof Error ? error.message : "Unable to return record.");
        }
        finally {
            this.returning.set(false);
        }
    }
    constructor() {
        inject(DestroyRef).onDestroy(() => this.controller.abort());
        this.task.lifecycle.dispose = () => { this.controller.abort(); const relation = this.task.data().relation; if (relation)
            this.crud.cancelRelated(relation); };
        this.task.lifecycle.save = () => this.persist();
        effect(() => this.task.dirty.set(this.draft.dirty()));
        if (this.id)
            void this.load();
        else
            this.draft.initialize({ ...this.feature.defaults, ...this.task.data().defaults });
    }
    fieldRenderer(name) {
        return this.feature.fieldRenderers && Object.hasOwn(this.feature.fieldRenderers, name) ? this.feature.fieldRenderers[name] : null;
    }
    fieldContext(field) {
        return {
            controlId: this.task.id + '-' + field.name, errorId: this.task.id + '-' + field.name + '-error',
            field: structuredClone(field), value: structuredClone(this.draft.value()[field.name]), row: structuredClone(this.draft.value()),
            disabled: field.readOnly || !this.canWrite() || this.loading() || this.task.saving(),
            errors: [...(this.errors()[field.name] ?? [])], change: value => this.change(field.name, value),
        };
    }
    change(key, value) {
        const field = this.descriptor.fields.find(field => field.name === key);
        if (!field || field.readOnly || !this.canWrite() || this.loading() || this.task.saving())
            return;
        this.draft.change(key, structuredClone(value));
        this.task.dirty.set(true);
    }
    async reload() {
        if (this.draft.dirty() &&
            !confirm("Discard your unsaved changes and reload?"))
            return;
        if (this.id)
            await this.load();
        else
            this.draft.initialize({ ...this.feature.defaults, ...this.task.data().defaults });
    }
    async load() {
        this.loading.set(true);
        this.task.error.set("");
        try {
            const record = await this.provider.get(this.id, this.controller.signal);
            if (!this.controller.signal.aborted) {
                this.draft.accept(record);
                this.errors.set({});
            }
        }
        catch (error) {
            if (!this.controller.signal.aborted)
                this.task.error.set(error instanceof Error ? error.message : "Unable to load record.");
        }
        finally {
            if (!this.controller.signal.aborted)
                this.loading.set(false);
        }
    }
    save() {
        return this.workspace.save(this.task.id);
    }
    saveShortcut(event) {
        if (this.workspace.activeId() !== this.task.id)
            return;
        event.preventDefault();
        if (!this.loading() && this.canWrite())
            void this.save();
    }
    async persist() {
        if (!this.canWrite() || this.loading())
            throw new Error("This record cannot be saved.");
        this.errors.set({});
        const errors = validateFields(this.descriptor.fields, this.draft.value(), this.feature.fieldValidators);
        if (Object.keys(errors).length) {
            this.errors.set(errors);
            this.focusError(errors);
            throw new Error("Correct the highlighted fields before saving.");
        }
        const value = editableValues(this.descriptor.fields, this.draft.value());
        try {
            const result = this.id
                ? await this.provider.update(this.id, value, this.draft.version(), this.controller.signal)
                : await this.provider.create(value, this.controller.signal);
            if (this.controller.signal.aborted)
                return;
            this.id = String(result.data[this.descriptor.keyField]);
            this.task.data.update(data => ({ ...data, id: this.id }));
            if (!this.task.data().relation)
                this.workspace.rekey(this.task.id, `${this.descriptor.id}:${this.id}`);
            this.draft.accept(result);
            this.crud.changed();
        }
        catch (error) {
            if (error instanceof ApiError) {
                const errors = error.problem.errors ?? {};
                this.errors.set(errors);
                this.focusError(errors);
            }
            throw error;
        }
    }
    async remove() {
        if (!this.canDelete() || this.loading() || this.task.saving() || !this.id || !this.draft.version() || !confirm("Delete this record?"))
            return;
        this.task.saving.set(true);
        this.task.error.set("");
        try {
            await this.provider.delete(this.id, this.draft.version(), this.controller.signal);
            this.task.saving.set(false);
            this.draft.dirty.set(false);
            this.task.dirty.set(false);
            this.crud.changed();
            await this.workspace.requestClose(this.task.id);
        }
        catch (error) {
            if (!this.controller.signal.aborted)
                this.task.error.set(error instanceof Error ? error.message : "Unable to delete.");
        }
        finally {
            this.task.saving.set(false);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: CrudEditor, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: CrudEditor, isStandalone: true, selector: "bqatlas-crud-editor", host: { listeners: { "keydown.control.s": "saveShortcut($event)", "keydown.meta.s": "saveShortcut($event)" } }, ngImport: i0, template: `<section class="bqatlas-view">
    <header class="bqatlas-toolbar">
      <strong>{{ descriptor.title }}</strong
      ><span class="bqatlas-spacer"></span>
      @if (canWrite()) {
        <button
          atlasButton
          variant="primary"
          [disabled]="loading() || task.saving() || !draft.dirty()"
          (click)="save()"
        >
          Save
        </button>
      }
      <button
        atlasButton
        [disabled]="loading() || task.saving()"
        (click)="reload()"
      >
        Reload
      </button>
      @if (task.data().relation) {
        <button atlasButton variant="primary" [disabled]="loading() || task.saving() || returning()"
          (click)="saveAndReturn()">{{ canWrite() ? 'Save & select' : 'Select & return' }}</button>
      }
      @if (id && canDelete() && !task.data().relation) {
        <button
          atlasButton
          variant="danger"
          [disabled]="loading() || task.saving()"
          (click)="remove()"
        >
          Delete
        </button>
      }
    </header>
    @if (task.error()) {
      <div class="atlas-alert error" role="alert">{{ task.error() }}</div>
    }
    @if (loading()) {
      <p role="status">Loading record…</p>
    }
    <form class="bqatlas-form" (ngSubmit)="save()">
      <fieldset [disabled]="loading() || task.saving() || !canWrite()">
        @for (field of descriptor.fields; track field.name) {
          <div class="bqatlas-field">
            <label [for]="task.id + '-' + field.name"
              >{{ field.label }}
              @if (field.required) {
                <span aria-hidden="true">*</span>
              }
            </label>
            @if (fieldRenderer(field.name); as renderer) {
              <ng-container *ngComponentOutlet="renderer;inputs:{context:fieldContext(field)}" />
            } @else if (field.readOnly || field.type === 'reference'  || field.type === 'dateTime') {
              <output [id]="task.id + '-' + field.name">{{ draft.value()[field.name] }}</output>
              @if (!field.readOnly) { <small>This field requires a custom editor.</small> }
            } @else if (field.type === 'enum') {
              <select [id]="task.id + '-' + field.name" [name]="field.name" [required]="field.required"
                [attr.aria-invalid]="!!errors()[field.name]" [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
                [ngModel]="draft.value()[field.name]" (ngModelChange)="change(field.name, $event)">
                <option value="">Choose…</option>
                @for (option of field.options ?? []; track option) { <option [value]="option">{{ option }}</option> }
              </select>
            } @else if (field.type === 'decimal') {
              <bqatlas-decimal-input [controlId]="task.id + '-' + field.name" [name]="field.name"
                [scale]="field.scale ?? 2" [maximum]="field.maximum ?? undefined"
                [invalid]="!!errors()[field.name]" [describedBy]="task.id + '-' + field.name + '-error'"
                [required]="field.required" [ngModel]="draft.value()[field.name]"
                (ngModelChange)="change(field.name, $event)" />
            } @else if (field.type === 'integer') {
              <input atlasInput type="number" step="1" [id]="task.id + '-' + field.name"
                [attr.aria-invalid]="!!errors()[field.name]" [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
                [name]="field.name" [required]="field.required"
                [ngModel]="draft.value()[field.name]" (ngModelChange)="change(field.name, $event)" />
            } @else if (field.type === "boolean") {
              <input
                type="checkbox"
                [attr.aria-invalid]="!!errors()[field.name]"
                [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
                [id]="task.id + '-' + field.name"
                [name]="field.name"
                [ngModel]="draft.value()[field.name]"
                (ngModelChange)="change(field.name, $event)"
              />
            } @else {
              <input
                atlasInput
                [id]="task.id + '-' + field.name"
                [name]="field.name"
                [type]="field.type === 'email' ? 'email' : field.type === 'date' ? 'date' : 'text'"
                [required]="field.required"
                [readOnly]="field.readOnly"
                [attr.maxlength]="field.maxLength"
                [ngModel]="draft.value()[field.name]"
                (ngModelChange)="change(field.name, $event)"
                [attr.aria-invalid]="!!errors()[field.name]"
                [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
              />
            }
            <small
              [id]="task.id + '-' + field.name + '-error'"
              class="bqatlas-field-error"
              >{{ errors()[field.name]?.join(" ") }}</small
            >
          </div>
        }
      </fieldset>
      <button type="submit" hidden>Save</button>
    </form>
    <footer class="bqatlas-record-status">
      {{ draft.dirty() ? "Unsaved changes" : "Saved" }}
      @if (draft.version()) {
        · Version {{ draft.version()?.slice(0, 8) }}
      }
    </footer>
  </section>`, isInline: true, dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NumberValueAccessor, selector: "input[type=number]:not([ngNoCva])[formControlName],input[type=number]:not([ngNoCva])[formControl],input[type=number]:not([ngNoCva])[ngModel]" }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]" }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }, { kind: "component", type: AtlasDecimalTextInput, selector: "bqatlas-decimal-input", inputs: ["required", "sheetEditor", "scale", "maximum"] }, { kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletEnvironmentInjector", "ngComponentOutletContent", "ngComponentOutletNgModule"], exportAs: ["ngComponentOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: CrudEditor, decorators: [{
            type: Component,
            args: [{
                    selector: "bqatlas-crud-editor",
                    imports: [FormsModule, AtlasButton, AtlasInput, AtlasDecimalTextInput, NgComponentOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        "(keydown.control.s)": "saveShortcut($event)",
                        "(keydown.meta.s)": "saveShortcut($event)",
                    },
                    template: `<section class="bqatlas-view">
    <header class="bqatlas-toolbar">
      <strong>{{ descriptor.title }}</strong
      ><span class="bqatlas-spacer"></span>
      @if (canWrite()) {
        <button
          atlasButton
          variant="primary"
          [disabled]="loading() || task.saving() || !draft.dirty()"
          (click)="save()"
        >
          Save
        </button>
      }
      <button
        atlasButton
        [disabled]="loading() || task.saving()"
        (click)="reload()"
      >
        Reload
      </button>
      @if (task.data().relation) {
        <button atlasButton variant="primary" [disabled]="loading() || task.saving() || returning()"
          (click)="saveAndReturn()">{{ canWrite() ? 'Save & select' : 'Select & return' }}</button>
      }
      @if (id && canDelete() && !task.data().relation) {
        <button
          atlasButton
          variant="danger"
          [disabled]="loading() || task.saving()"
          (click)="remove()"
        >
          Delete
        </button>
      }
    </header>
    @if (task.error()) {
      <div class="atlas-alert error" role="alert">{{ task.error() }}</div>
    }
    @if (loading()) {
      <p role="status">Loading record…</p>
    }
    <form class="bqatlas-form" (ngSubmit)="save()">
      <fieldset [disabled]="loading() || task.saving() || !canWrite()">
        @for (field of descriptor.fields; track field.name) {
          <div class="bqatlas-field">
            <label [for]="task.id + '-' + field.name"
              >{{ field.label }}
              @if (field.required) {
                <span aria-hidden="true">*</span>
              }
            </label>
            @if (fieldRenderer(field.name); as renderer) {
              <ng-container *ngComponentOutlet="renderer;inputs:{context:fieldContext(field)}" />
            } @else if (field.readOnly || field.type === 'reference'  || field.type === 'dateTime') {
              <output [id]="task.id + '-' + field.name">{{ draft.value()[field.name] }}</output>
              @if (!field.readOnly) { <small>This field requires a custom editor.</small> }
            } @else if (field.type === 'enum') {
              <select [id]="task.id + '-' + field.name" [name]="field.name" [required]="field.required"
                [attr.aria-invalid]="!!errors()[field.name]" [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
                [ngModel]="draft.value()[field.name]" (ngModelChange)="change(field.name, $event)">
                <option value="">Choose…</option>
                @for (option of field.options ?? []; track option) { <option [value]="option">{{ option }}</option> }
              </select>
            } @else if (field.type === 'decimal') {
              <bqatlas-decimal-input [controlId]="task.id + '-' + field.name" [name]="field.name"
                [scale]="field.scale ?? 2" [maximum]="field.maximum ?? undefined"
                [invalid]="!!errors()[field.name]" [describedBy]="task.id + '-' + field.name + '-error'"
                [required]="field.required" [ngModel]="draft.value()[field.name]"
                (ngModelChange)="change(field.name, $event)" />
            } @else if (field.type === 'integer') {
              <input atlasInput type="number" step="1" [id]="task.id + '-' + field.name"
                [attr.aria-invalid]="!!errors()[field.name]" [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
                [name]="field.name" [required]="field.required"
                [ngModel]="draft.value()[field.name]" (ngModelChange)="change(field.name, $event)" />
            } @else if (field.type === "boolean") {
              <input
                type="checkbox"
                [attr.aria-invalid]="!!errors()[field.name]"
                [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
                [id]="task.id + '-' + field.name"
                [name]="field.name"
                [ngModel]="draft.value()[field.name]"
                (ngModelChange)="change(field.name, $event)"
              />
            } @else {
              <input
                atlasInput
                [id]="task.id + '-' + field.name"
                [name]="field.name"
                [type]="field.type === 'email' ? 'email' : field.type === 'date' ? 'date' : 'text'"
                [required]="field.required"
                [readOnly]="field.readOnly"
                [attr.maxlength]="field.maxLength"
                [ngModel]="draft.value()[field.name]"
                (ngModelChange)="change(field.name, $event)"
                [attr.aria-invalid]="!!errors()[field.name]"
                [attr.aria-describedby]="task.id + '-' + field.name + '-error'"
              />
            }
            <small
              [id]="task.id + '-' + field.name + '-error'"
              class="bqatlas-field-error"
              >{{ errors()[field.name]?.join(" ") }}</small
            >
          </div>
        }
      </fieldset>
      <button type="submit" hidden>Save</button>
    </form>
    <footer class="bqatlas-record-status">
      {{ draft.dirty() ? "Unsaved changes" : "Saved" }}
      @if (draft.version()) {
        · Version {{ draft.version()?.slice(0, 8) }}
      }
    </footer>
  </section>`,
                }]
        }], ctorParameters: () => [] });

class ReferenceLookup {
    crud = inject(CrudWorkspace);
    session = inject(AtlasSession);
    workspace = inject(WorkspaceService);
    parent = inject(ATLAS_TASK, { optional: true });
    host = inject(ElementRef);
    resource = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "resource" }] : /* istanbul ignore next */ []));
    nameField = input("name", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nameField" }] : /* istanbul ignore next */ []));
    readonly = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
    /** Change when parent eligibility context changes; prevents late child selection. */
    contextKey = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contextKey" }] : /* istanbul ignore next */ []));
    pickerOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pickerOpen" }] : /* istanbul ignore next */ []));
    relationError = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "relationError" }] : /* istanbul ignore next */ []));
    resolvedCaption = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedCaption" }] : /* istanbul ignore next */ []));
    revision = 0;
    alive = true;
    children = new Set();
    controller = new AbortController();
    canOpen = computed(() => {
        const resource = this.resource();
        const descriptor = this.session
            .manifest()
            ?.resources.find((r) => r.id === resource);
        return (!!this.parent &&
            !!descriptor &&
            this.session.has(descriptor.readPermission));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canOpen" }] : /* istanbul ignore next */ []));
    canCreate = computed(() => this.canOpen() &&
        !this.disabled() &&
        !this.readonly() &&
        this.session.has(this.crud.feature(this.resource()).writePermission), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canCreate" }] : /* istanbul ignore next */ []));
    actions = computed(() => this.disabled() || this.readonly()
        ? []
        : [
            { id: "search", label: "Search more…" },
            ...(this.canCreate()
                ? [{ id: "create", label: `Create ${this.label()}…` }]
                : []),
        ], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []));
    cell(row, key) {
        return String(row[key] ?? "");
    }
    select(row) {
        if (this.disabled() || this.readonly())
            return;
        this.revision++;
        this.resolvedCaption.set("");
        this.value.set(row ? this.recordKey()(row) : null);
        this.recordSelected.emit(row);
    }
    runAction(action) {
        this.query = action.query;
        if (action.id === "create")
            this.openRelated(true);
        else if (!this.disabled() && !this.readonly()) {
            this.pickerOpen.set(true);
            clearTimeout(this.timer);
            void this.load(0);
        }
    }
    openRelated(create) {
        if (!this.canOpen() || this.disabled() || (create && !this.canCreate()))
            return;
        const provider = this.provider();
        if (!provider.resolve) {
            this.relationError.set("This lookup does not support record resolution.");
            return;
        }
        this.pickerOpen.set(false);
        this.relationError.set("");
        const initial = this.value(), revision = this.revision, context = this.contextKey(), session = this.session.info();
        let childId;
        const valid = () => this.alive &&
            this.revision === revision &&
            this.value() === initial &&
            this.contextKey() === context &&
            this.session.info() === session &&
            this.workspace.tasks().some((t) => t.id === this.parent.id) &&
            this.workspace.tasks().some((t) => t.id === childId);
        try {
            const handle = this.crud.openRelated(this.resource(), this.parent.id, async (id) => {
                if (!valid())
                    throw new Error("The originating field changed. The record remains saved; select it again from the lookup.");
                const row = await provider.resolve(id, this.controller.signal);
                if (!valid())
                    throw new Error("The originating field is no longer available. The record remains saved.");
                if (!row)
                    throw new Error("The record was saved but is unavailable for this lookup.");
                this.request.cancel();
                clearTimeout(this.timer);
                this.loading.set(false);
                this.rows.update((rows) => rows.map((existing) => this.recordKey()(existing) === id ? row : existing));
                if (create || id !== initial) {
                    if (this.disabled() || this.readonly())
                        throw new Error("The originating field can no longer be changed.");
                    this.select(row);
                }
                else
                    this.resolvedCaption.set(this.displayWith()(row));
                this.children.delete(handle.cancel);
                setTimeout(() => {
                    if (this.alive)
                        this.host.nativeElement
                            .querySelector('[role="combobox"]')
                            ?.focus();
                });
            }, create ? undefined : (initial ?? undefined), create ? { [this.nameField()]: this.query.trim() } : undefined);
            childId = handle.task.id;
            this.children.add(handle.cancel);
        }
        catch (error) {
            this.relationError.set(error instanceof Error ? error.message : "Unable to open record.");
        }
    }
    provider = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "provider" }] : /* istanbul ignore next */ []));
    columns = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    recordKey = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "recordKey" }] : /* istanbul ignore next */ []));
    displayWith = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayWith" }] : /* istanbul ignore next */ []));
    controlId = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    label = input("Record", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    selectedText = input("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedText" }] : /* istanbul ignore next */ []));
    describedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "describedBy" }] : /* istanbul ignore next */ []));
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    recordSelected = output();
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    required = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []));
    invalid = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    rows = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    page = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []));
    total = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []));
    loading = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    error = signal("", /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    pageSize = 20;
    request = new AtlasLatestRequest();
    query = "";
    timer;
    constructor() {
        effect(() => {
            this.value();
            this.contextKey();
            this.provider();
            this.resource();
            this.revision++;
            this.resolvedCaption.set("");
        });
        effect(() => {
            this.provider();
            this.contextKey();
            this.request.cancel();
            clearTimeout(this.timer);
            this.rows.set([]);
            this.total.set(0);
            this.pickerOpen.set(false);
        });
        inject(DestroyRef).onDestroy(() => {
            this.alive = false;
            this.controller.abort();
            for (const cancel of this.children)
                cancel();
            this.children.clear();
            this.request.cancel();
            clearTimeout(this.timer);
        });
    }
    search(query) {
        this.query = query;
        this.request.cancel();
        this.loading.set(true);
        clearTimeout(this.timer);
        this.timer = setTimeout(() => void this.load(0), 150);
    }
    load(page) {
        this.page.set(page);
        this.loading.set(true);
        this.error.set("");
        return this.request.run((signal) => this.provider().query({ page, pageSize: this.pageSize, search: this.query }, signal), (result) => {
            this.rows.set(result.items);
            this.total.set(result.total);
            this.loading.set(false);
        }, (error) => {
            this.error.set(error instanceof Error ? error.message : "Unable to load records.");
            this.loading.set(false);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: ReferenceLookup, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: ReferenceLookup, isStandalone: true, selector: "bqatlas-reference-lookup", inputs: { resource: { classPropertyName: "resource", publicName: "resource", isSignal: true, isRequired: false, transformFunction: null }, nameField: { classPropertyName: "nameField", publicName: "nameField", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, contextKey: { classPropertyName: "contextKey", publicName: "contextKey", isSignal: true, isRequired: false, transformFunction: null }, provider: { classPropertyName: "provider", publicName: "provider", isSignal: true, isRequired: true, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, recordKey: { classPropertyName: "recordKey", publicName: "recordKey", isSignal: true, isRequired: true, transformFunction: null }, displayWith: { classPropertyName: "displayWith", publicName: "displayWith", isSignal: true, isRequired: true, transformFunction: null }, controlId: { classPropertyName: "controlId", publicName: "controlId", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, selectedText: { classPropertyName: "selectedText", publicName: "selectedText", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", recordSelected: "recordSelected" }, ngImport: i0, template: `<div class="reference-shell">
      <atlas-lookup
        [controlId]="controlId()"
        [ariaLabel]="label()"
        [describedBy]="describedBy()"
        [rows]="rows()"
        [columns]="columns()"
        [recordKey]="recordKey()"
        [displayWith]="displayWith()"
        [selectedText]="resolvedCaption() || selectedText()"
        [readonly]="readonly()"
        [actions]="actions()"
        (action)="runAction($event)"
        [value]="value()"
        (recordSelected)="select($event)"
        [remote]="true"
        [disabled]="disabled()"
        [required]="required()"
        [invalid]="invalid()"
        [touched]="true"
        [loading]="loading()"
        [error]="error()"
        [page]="page()"
        [total]="total()"
        [pageSize]="pageSize"
        (queryChange)="search($event)"
        (pageChange)="load($event)"
        (retry)="load(page())"
      />
      @if (canOpen() && value()) {
        <button
          atlasButton
          type="button"
          [disabled]="disabled()"
          [attr.aria-label]="'Open ' + label()"
          (click)="openRelated(false)"
        >
          ↗
        </button>
      }
    </div>
    @if (relationError()) {
      <p class="reference-error" role="alert">{{ relationError() }}</p>
    }
    <atlas-dialog [(open)]="pickerOpen" [title]="'Select ' + label()">
      <input
        atlasInput
        [placeholder]="'Search ' + label() + '…'"
        (keydown.enter)="$event.preventDefault(); $event.stopPropagation()"
        [attr.aria-label]="'Search all ' + label()"
        [value]="query"
        (input)="search($any($event.target).value)"
      />
      @if (loading()) {
        <p role="status">Loading records…</p>
      } @else if (error()) {
        <p role="alert">{{ error() }}</p>
        <button atlasButton type="button" (click)="load(page())">Retry</button>
      } @else {
        <table class="reference-picker">
          <thead>
            <tr>
              @for (column of columns(); track column.key) {
                <th>{{ column.label }}</th>
              }
              <th>Select</th>
            </tr>
          </thead>
          <tbody>
            @for (row of rows(); track recordKey()(row)) {
              <tr>
                @for (column of columns(); track column.key) {
                  <td>{{ cell(row, column.key) }}</td>
                }
                <td>
                  <button
                    atlasButton
                    type="button"
                    (click)="select(row); pickerOpen.set(false)"
                    [attr.aria-label]="'Select ' + displayWith()(row)"
                  >
                    Select
                  </button>
                </td>
              </tr>
            } @empty {
              <tr>
                <td [attr.colspan]="columns().length + 1">
                  No matching records.
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
      <div class="reference-pages">
        <button
          atlasButton
          type="button"
          [disabled]="loading() || page() === 0"
          (click)="load(page() - 1)"
        >
          Previous
        </button>
        <span>{{ total() }} matches · Page {{ page() + 1 }}</span>
        <button
          atlasButton
          type="button"
          [disabled]="loading() || (page() + 1) * pageSize >= total()"
          (click)="load(page() + 1)"
        >
          Next
        </button>
      </div>
      <div atlasDialogActions>
        @if (canCreate()) {
          <button atlasButton type="button" (click)="openRelated(true)">
            Create {{ label() }}…
          </button>
        }
        <button atlasButton type="button" (click)="pickerOpen.set(false)">
          Cancel
        </button>
      </div>
    </atlas-dialog>`, isInline: true, styles: [".reference-shell{display:flex;gap:6px;align-items:center}.reference-shell atlas-lookup{flex:1;min-width:0}.reference-picker{width:100%;border-collapse:collapse;margin-block:12px}.reference-picker th,.reference-picker td{padding:8px;text-align:left;border-bottom:1px solid var(--atlas-border, #ddd)}.reference-pages{display:flex;align-items:center;justify-content:space-between;gap:12px}.reference-error{color:var(--atlas-danger, #b42318);margin:6px 0}\n"], dependencies: [{ kind: "component", type: AtlasLookup, selector: "atlas-lookup", inputs: ["actions", "controlId", "ariaLabel", "describedBy", "rows", "columns", "recordKey", "displayWith", "rowDisabled", "value", "disabled", "readonly", "invalid", "touched", "required", "clearable", "arrowNavigation", "placeholder", "loading", "error", "popupWidth", "remote", "selectedText", "page", "total", "pageSize"], outputs: ["action", "valueChange", "touch", "recordSelected", "retry", "queryChange", "pageChange"] }, { kind: "component", type: AtlasDialog, selector: "atlas-dialog", inputs: ["open", "title", "busy"], outputs: ["openChange", "dismissed"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }, { kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: ReferenceLookup, decorators: [{
            type: Component,
            args: [{ selector: "bqatlas-reference-lookup", imports: [AtlasLookup, AtlasDialog, AtlasInput, AtlasButton], changeDetection: ChangeDetectionStrategy.OnPush, template: `<div class="reference-shell">
      <atlas-lookup
        [controlId]="controlId()"
        [ariaLabel]="label()"
        [describedBy]="describedBy()"
        [rows]="rows()"
        [columns]="columns()"
        [recordKey]="recordKey()"
        [displayWith]="displayWith()"
        [selectedText]="resolvedCaption() || selectedText()"
        [readonly]="readonly()"
        [actions]="actions()"
        (action)="runAction($event)"
        [value]="value()"
        (recordSelected)="select($event)"
        [remote]="true"
        [disabled]="disabled()"
        [required]="required()"
        [invalid]="invalid()"
        [touched]="true"
        [loading]="loading()"
        [error]="error()"
        [page]="page()"
        [total]="total()"
        [pageSize]="pageSize"
        (queryChange)="search($event)"
        (pageChange)="load($event)"
        (retry)="load(page())"
      />
      @if (canOpen() && value()) {
        <button
          atlasButton
          type="button"
          [disabled]="disabled()"
          [attr.aria-label]="'Open ' + label()"
          (click)="openRelated(false)"
        >
          ↗
        </button>
      }
    </div>
    @if (relationError()) {
      <p class="reference-error" role="alert">{{ relationError() }}</p>
    }
    <atlas-dialog [(open)]="pickerOpen" [title]="'Select ' + label()">
      <input
        atlasInput
        [placeholder]="'Search ' + label() + '…'"
        (keydown.enter)="$event.preventDefault(); $event.stopPropagation()"
        [attr.aria-label]="'Search all ' + label()"
        [value]="query"
        (input)="search($any($event.target).value)"
      />
      @if (loading()) {
        <p role="status">Loading records…</p>
      } @else if (error()) {
        <p role="alert">{{ error() }}</p>
        <button atlasButton type="button" (click)="load(page())">Retry</button>
      } @else {
        <table class="reference-picker">
          <thead>
            <tr>
              @for (column of columns(); track column.key) {
                <th>{{ column.label }}</th>
              }
              <th>Select</th>
            </tr>
          </thead>
          <tbody>
            @for (row of rows(); track recordKey()(row)) {
              <tr>
                @for (column of columns(); track column.key) {
                  <td>{{ cell(row, column.key) }}</td>
                }
                <td>
                  <button
                    atlasButton
                    type="button"
                    (click)="select(row); pickerOpen.set(false)"
                    [attr.aria-label]="'Select ' + displayWith()(row)"
                  >
                    Select
                  </button>
                </td>
              </tr>
            } @empty {
              <tr>
                <td [attr.colspan]="columns().length + 1">
                  No matching records.
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
      <div class="reference-pages">
        <button
          atlasButton
          type="button"
          [disabled]="loading() || page() === 0"
          (click)="load(page() - 1)"
        >
          Previous
        </button>
        <span>{{ total() }} matches · Page {{ page() + 1 }}</span>
        <button
          atlasButton
          type="button"
          [disabled]="loading() || (page() + 1) * pageSize >= total()"
          (click)="load(page() + 1)"
        >
          Next
        </button>
      </div>
      <div atlasDialogActions>
        @if (canCreate()) {
          <button atlasButton type="button" (click)="openRelated(true)">
            Create {{ label() }}…
          </button>
        }
        <button atlasButton type="button" (click)="pickerOpen.set(false)">
          Cancel
        </button>
      </div>
    </atlas-dialog>`, styles: [".reference-shell{display:flex;gap:6px;align-items:center}.reference-shell atlas-lookup{flex:1;min-width:0}.reference-picker{width:100%;border-collapse:collapse;margin-block:12px}.reference-picker th,.reference-picker td{padding:8px;text-align:left;border-bottom:1px solid var(--atlas-border, #ddd)}.reference-pages{display:flex;align-items:center;justify-content:space-between;gap:12px}.reference-error{color:var(--atlas-danger, #b42318);margin:6px 0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { resource: [{ type: i0.Input, args: [{ isSignal: true, alias: "resource", required: false }] }], nameField: [{ type: i0.Input, args: [{ isSignal: true, alias: "nameField", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], contextKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextKey", required: false }] }], provider: [{ type: i0.Input, args: [{ isSignal: true, alias: "provider", required: true }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], recordKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "recordKey", required: true }] }], displayWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "displayWith", required: true }] }], controlId: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], selectedText: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedText", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], recordSelected: [{ type: i0.Output, args: ["recordSelected"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }] } });

const identifier = /^[A-Za-z_][A-Za-z0-9_]*$/;
const quote = (value) => `'${value.replaceAll("'", "''")}'`;
/** Read OData DTOs while retaining the application's REST ETag and command semantics. */
class ODataResourceProvider {
    api;
    endpoint;
    records;
    options;
    constructor(api, endpoint, records, options) {
        this.api = api;
        this.endpoint = endpoint;
        this.records = records;
        this.options = options;
        if (!endpoint.startsWith('/') || endpoint.startsWith('//') || /[?#]/.test(endpoint))
            throw new Error('OData endpoint must be a same-origin path without query or fragment.');
        this.field(options.key);
        for (const name of options.searchFields ?? []) {
            if (this.field(name).type !== 'string')
                throw new Error('Search fields must be strings.');
        }
    }
    field(name) {
        const field = Object.hasOwn(this.options.fields, name) ? this.options.fields[name] : undefined;
        if (!field || !identifier.test(field.property))
            throw new Error(`Unknown OData field: ${name}`);
        return field;
    }
    async query(request, signal) {
        if (!Number.isSafeInteger(request.page) || request.page < 0 ||
            !Number.isSafeInteger(request.pageSize) || request.pageSize < 1 || request.pageSize > 100 ||
            request.page * request.pageSize > 100000)
            throw new Error('Invalid OData page.');
        const params = new URLSearchParams({ '$count': 'true', '$top': String(request.pageSize), '$skip': String(request.page * request.pageSize) });
        const order = (request.sort ?? []).map(sort => {
            if (!['asc', 'desc'].includes(sort.direction))
                throw new Error('Invalid OData sort direction.');
            return `${this.field(sort.field).property} ${sort.direction}`;
        });
        if (!(request.sort ?? []).some(sort => sort.field === this.options.key))
            order.push(`${this.field(this.options.key).property} asc`);
        params.set('$orderby', order.join(','));
        const filters = (request.filters ?? []).map(filter => {
            const field = this.field(filter.field);
            if (!['eq', 'contains', 'startsWith'].includes(filter.operator))
                throw new Error('Unsupported OData operator.');
            if (filter.operator !== 'eq') {
                if (field.type !== 'string')
                    throw new Error('Text filters require a string field.');
                return `${filter.operator === 'startsWith' ? 'startswith' : 'contains'}(${field.property},${quote(filter.value)})`;
            }
            let value = filter.value;
            switch (field.type) {
                case 'string':
                    value = quote(value);
                    break;
                case 'boolean':
                    if (!/^(true|false)$/.test(value))
                        throw new Error('Invalid boolean filter.');
                    break;
                case 'integer':
                    if (!/^-?(0|[1-9]\d*)$/.test(value))
                        throw new Error('Invalid integer filter.');
                    break;
                case 'decimal':
                    if (!/^-?(0|[1-9]\d*)(\.\d+)?$/.test(value))
                        throw new Error('Invalid decimal filter.');
                    break;
                case 'guid':
                    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value))
                        throw new Error('Invalid GUID filter.');
                    break;
                case 'date':
                    if (!/^\d{4}-\d{2}-\d{2}$/.test(value))
                        throw new Error('Invalid date filter.');
                    break;
            }
            return `${field.property} eq ${value}`;
        });
        if (request.search.trim()) {
            if (!this.options.searchFields?.length)
                throw new Error('OData search fields are not configured.');
            filters.push('(' + this.options.searchFields.map(name => `contains(${this.field(name).property},${quote(request.search.trim())})`).join(' or ') + ')');
        }
        if (filters.length)
            params.set('$filter', filters.join(' and '));
        let next = `${this.endpoint}?${params}`;
        const items = [];
        const seen = new Set();
        let total;
        while (next) {
            if (seen.has(next))
                throw new Error('Repeated OData continuation.');
            seen.add(next);
            const page = await this.api.request(next, 'GET', undefined, signal, undefined, undefined, 'application/json;IEEE754Compatible=true');
            if (!Array.isArray(page.value) || page.value.length + items.length > request.pageSize)
                throw new Error('Invalid OData page response.');
            if (total === undefined) {
                const count = page['@odata.count'];
                total = typeof count === 'string' && /^(0|[1-9]\d*)$/.test(count) && BigInt(count) <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(count) : typeof count === 'number' ? count : undefined;
            }
            if (!Number.isSafeInteger(total) || total < 0)
                throw new Error('OData response requires an exact count.');
            items.push(...page.value.map(this.options.map));
            next = undefined;
            if (page['@odata.nextLink'] && items.length < request.pageSize) {
                if (!page.value.length)
                    throw new Error('Empty OData continuation page.');
                const base = new URL(this.endpoint, window.location.origin);
                const link = new URL(page['@odata.nextLink'], base);
                if (link.origin !== base.origin || link.pathname !== base.pathname || link.hash || link.username || link.password)
                    throw new Error('OData continuation must stay on the same resource.');
                next = link.pathname + link.search;
            }
        }
        return { items, total: total, page: request.page, pageSize: request.pageSize };
    }
    get(id, signal) { return this.records.get(id, signal); }
    create(input, signal) { return this.records.create(input, signal); }
    update(id, input, version, signal) { return this.records.update(id, input, version, signal); }
    delete(id, version, signal) { return this.records.delete(id, version, signal); }
}

function visibleMenu(nodes, permissions, resources, commands) {
    return [...nodes].sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.id.localeCompare(b.id)).flatMap(node => {
        if (node.permission && !permissions.has(node.permission))
            return [];
        if (node.kind === 'group') {
            const children = visibleMenu(node.children, permissions, resources, commands);
            return children.length ? [{ ...node, children }] : [];
        }
        if (node.kind === 'resource')
            return resources.has(node.resource) ? [{ ...node }] : [];
        const command = commands.get(node.command);
        return command && permissions.has(command.permission) ? [{ ...node }] : [];
    });
}
function validateMenu(nodes) {
    const ids = new Set();
    const walk = (items, depth) => {
        if (depth > 12)
            throw new Error('Menu nesting exceeds twelve levels.');
        for (const item of items) {
            if (!item.id || ids.has(item.id))
                throw new Error(`Duplicate or empty menu ID: ${item.id}`);
            ids.add(item.id);
            if (!item.label.trim() || !Number.isFinite(item.order ?? 0))
                throw new Error('Menu labels and ordering must be valid.');
            if (item.kind === 'group')
                walk(item.children, depth + 1);
            else if (item.kind === 'resource' ? !item.resource : item.kind === 'command' ? !item.command : true)
                throw new Error('Invalid menu target.');
        }
    };
    walk(nodes, 0);
}
class AtlasMenus {
    session = inject(AtlasSession);
    crud = inject(CrudWorkspace);
    nodes = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    commands = new Map();
    register(...nodes) { const next = [...this.nodes(), ...nodes]; validateMenu(next); this.nodes.set(structuredClone(next)); }
    registerCommand(command) {
        if (!command.id || !command.permission || this.commands.has(command.id))
            throw new Error('Menu commands require a unique ID and permission.');
        this.commands.set(command.id, command);
        this.nodes.update(nodes => [...nodes]);
    }
    visible() {
        if (!this.session.authenticated())
            return [];
        return visibleMenu(this.nodes(), new Set(this.session.info().permissions), new Set(this.crud.menus().map(feature => feature.resource)), this.commands);
    }
    async activate(id) {
        const find = (nodes) => { for (const node of nodes) {
            if (node.id === id)
                return node;
            if (node.kind === 'group') {
                const match = find(node.children);
                if (match)
                    return match;
            }
        } return undefined; };
        const node = find(this.visible());
        if (!node || node.kind === 'group')
            throw new Error('This menu action is unavailable.');
        if (node.kind === 'resource')
            this.crud.openList(node.resource);
        else
            await this.commands.get(node.command).run();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMenus, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMenus, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMenus, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class AtlasMenu {
    menus = inject(AtlasMenus);
    translate = input((_key, fallback) => fallback, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "translate" }] : /* istanbul ignore next */ []));
    pending = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pending" }] : /* istanbul ignore next */ []));
    error = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    text(key, fallback) { return key ? this.translate()(key, fallback) : fallback; }
    async activate(id) {
        if (this.pending())
            return;
        this.pending.set(id);
        this.error.set('');
        try {
            await this.menus.activate(id);
        }
        catch (error) {
            this.error.set(error instanceof Error ? error.message : 'Unable to open this menu.');
        }
        finally {
            this.pending.set(null);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasMenu, isStandalone: true, selector: "bqatlas-menu", inputs: { translate: { classPropertyName: "translate", publicName: "translate", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<nav aria-label="Application views"><ng-container *ngTemplateOutlet="items;context:{$implicit:menus.visible()}" /></nav>
  @if(error()){<p class="menu-error" role="alert">{{error()}}</p>}
  <ng-template #items let-nodes><ul>
    @for(node of nodes;track node.id){<li>
      @if(node.kind==='group'){
        <div class="menu-group">{{text(node.labelKey,node.label)}}</div>
        <ng-container *ngTemplateOutlet="items;context:{$implicit:node.children}" />
      }@else{<button type="button" [disabled]="pending()===node.id" (click)="activate(node.id)">{{text(node.labelKey,node.label)}}</button>}
    </li>}
  </ul></ng-template>`, isInline: true, styles: [":host{display:block}ul{list-style:none;margin:0;padding:0;display:grid;gap:12px}ul ul{padding-left:16px}.menu-group{font-weight:600;margin:12px 0 8px}button{font:inherit;text-align:left;border:1px solid var(--atlas-border,#d5dbe5);border-radius:10px;background:var(--atlas-surface,#fff);color:inherit;padding:16px 20px;cursor:pointer;width:100%}button:hover{background:var(--atlas-surface-hover,#f5f7fa)}button:focus-visible{outline:2px solid var(--atlas-accent,#2869d8);outline-offset:2px}.menu-error{color:#b42318}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasMenu, decorators: [{
            type: Component,
            args: [{ selector: 'bqatlas-menu', imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: `<nav aria-label="Application views"><ng-container *ngTemplateOutlet="items;context:{$implicit:menus.visible()}" /></nav>
  @if(error()){<p class="menu-error" role="alert">{{error()}}</p>}
  <ng-template #items let-nodes><ul>
    @for(node of nodes;track node.id){<li>
      @if(node.kind==='group'){
        <div class="menu-group">{{text(node.labelKey,node.label)}}</div>
        <ng-container *ngTemplateOutlet="items;context:{$implicit:node.children}" />
      }@else{<button type="button" [disabled]="pending()===node.id" (click)="activate(node.id)">{{text(node.labelKey,node.label)}}</button>}
    </li>}
  </ul></ng-template>`, styles: [":host{display:block}ul{list-style:none;margin:0;padding:0;display:grid;gap:12px}ul ul{padding-left:16px}.menu-group{font-weight:600;margin:12px 0 8px}button{font:inherit;text-align:left;border:1px solid var(--atlas-border,#d5dbe5);border-radius:10px;background:var(--atlas-surface,#fff);color:inherit;padding:16px 20px;cursor:pointer;width:100%}button:hover{background:var(--atlas-surface-hover,#f5f7fa)}button:focus-visible{outline:2px solid var(--atlas-accent,#2869d8);outline-offset:2px}.menu-error{color:#b42318}\n"] }]
        }], propDecorators: { translate: [{ type: i0.Input, args: [{ isSignal: true, alias: "translate", required: false }] }] } });

const resourceId = /^[a-z][a-z0-9-]*(\.[a-z][a-z0-9-]*)+$/;
function parseWorkspaceRoute(hash) {
    if (!hash || hash === '#' || hash === '#/')
        return { kind: 'home' };
    const parts = hash.replace(/^#/, '').split('/');
    if (parts[0] !== '' || parts.length > 4)
        throw new Error('Invalid workspace link.');
    if (parts[1] === 'draft' && parts.length === 3 && /^task-[0-9]+$/.test(parts[2]))
        return { kind: 'draft', task: parts[2] };
    const resource = decodeURIComponent(parts[2] ?? '');
    if (!resourceId.test(resource))
        throw new Error('Invalid resource link.');
    if (parts[1] === 'list' && parts.length === 3)
        return { kind: 'list', resource };
    if (parts[1] === 'record' && parts.length === 4) {
        const id = decodeURIComponent(parts[3]);
        if (!id || id.length > 200 || /[\u0000-\u001f\u007f]/.test(id))
            throw new Error('Invalid record link.');
        return { kind: 'record', resource, id };
    }
    throw new Error('Invalid workspace link.');
}
function workspaceHash(route) {
    switch (route.kind) {
        case 'home': return '#/';
        case 'list': return `#/list/${encodeURIComponent(route.resource)}`;
        case 'record': return `#/record/${encodeURIComponent(route.resource)}/${encodeURIComponent(route.id)}`;
        case 'draft': return `#/draft/${route.task}`;
    }
}
/** Hash routes keep API hosting simple. Back switches retained views; it never discards a task. */
class AtlasNavigation {
    session = inject(AtlasSession);
    crud = inject(CrudWorkspace);
    workspace = inject(WorkspaceService);
    error = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    initialized = false;
    hadSession = false;
    lastHash = '';
    storageKey = 'bqatlas.returnRoute';
    constructor() {
        const destroy = inject(DestroyRef);
        if (typeof window === 'undefined')
            return;
        const navigate = () => { if (window.location.hash !== this.lastHash)
            this.restore(window.location.hash); };
        window.addEventListener('popstate', navigate);
        window.addEventListener('hashchange', navigate);
        destroy.onDestroy(() => { window.removeEventListener('popstate', navigate); window.removeEventListener('hashchange', navigate); });
        if (window.location.hash) {
            try {
                parseWorkspaceRoute(window.location.hash);
                this.remember(window.location.hash);
            }
            catch { /* Invalid incoming links are handled after login. */ }
        }
        effect(() => {
            const authenticated = this.session.authenticated();
            const manifest = this.session.manifest();
            const active = this.workspace.active();
            const data = active?.data();
            if (!authenticated || !manifest) {
                this.initialized = false;
                if (this.hadSession) {
                    this.hadSession = false;
                    this.remember(null);
                    this.replace('#/');
                }
                return;
            }
            if (!this.initialized) {
                this.initialized = true;
                this.hadSession = true;
                const hash = window.location.hash || this.remembered() || '#/';
                this.remember(null);
                this.restore(hash);
                return;
            }
            let route = { kind: 'home' };
            if (active && data?.resource) {
                if (active.screen.endsWith('.editor') || active.screen === 'bqatlas.editor')
                    route = data.id ? { kind: 'record', resource: data.resource, id: data.id } : { kind: 'draft', task: active.id };
                else
                    route = { kind: 'list', resource: data.resource };
            }
            const hash = workspaceHash(route);
            if (window.location.hash !== hash) {
                window.history.pushState(null, '', hash);
                this.lastHash = hash;
                this.error.set('');
            }
        });
    }
    remember(hash) { try {
        if (hash === null)
            sessionStorage.removeItem(this.storageKey);
        else
            sessionStorage.setItem(this.storageKey, hash);
    }
    catch { /* Storage can be unavailable; in-page navigation still works. */ } }
    remembered() { try {
        return sessionStorage.getItem(this.storageKey);
    }
    catch {
        return null;
    } }
    replace(hash) { window.history.replaceState(null, '', hash); this.lastHash = hash; }
    restore(hash) {
        if (!this.session.authenticated() || !this.session.manifest())
            return;
        this.lastHash = hash;
        this.error.set('');
        try {
            const route = parseWorkspaceRoute(hash);
            this.replace(workspaceHash(route));
            if (route.kind === 'home')
                this.workspace.showDesktop();
            else if (route.kind === 'list')
                this.crud.openList(route.resource);
            else if (route.kind === 'record')
                this.crud.openEditor(route.resource, route.id);
            else {
                const task = this.workspace.tasks().find(task => task.id === route.task);
                if (!task)
                    throw new Error('This unsaved draft is no longer available. Draft links work only in the current workspace.');
                const data = task.data();
                if (!data.resource)
                    throw new Error('This view is unavailable.');
                this.crud.descriptor(data.resource);
                this.workspace.activate(task.id);
            }
        }
        catch (error) {
            this.workspace.showDesktop();
            this.replace('#/');
            this.error.set(error instanceof Error ? error.message : 'Unable to open this link.');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasNavigation, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasNavigation, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasNavigation, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class AtlasPasswordChange {
    api = inject(AtlasApi);
    session = inject(AtlasSession);
    workspace = inject(WorkspaceService);
    closed = output();
    busy = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []));
    error = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    currentPassword = '';
    newPassword = '';
    confirmation = '';
    cancel() { this.clear(); this.closed.emit(); }
    clear() { this.currentPassword = ''; this.newPassword = ''; this.confirmation = ''; }
    async submit() {
        if (this.busy())
            return;
        if (this.session.info()?.authMode !== 'local' || !this.session.authenticated()) {
            this.error.set('Password management is handled by your identity provider.');
            return;
        }
        if (this.workspace.hasPendingWork()) {
            this.error.set('Save or close your unsaved work before changing your password.');
            return;
        }
        if (!this.currentPassword || !this.newPassword || this.newPassword !== this.confirmation) {
            this.error.set('Enter your current password and matching new passwords.');
            return;
        }
        this.busy.set(true);
        this.error.set('');
        try {
            await this.api.request('/auth/change-password', 'POST', { currentPassword: this.currentPassword, newPassword: this.newPassword });
            this.clear();
            this.closed.emit();
            this.session.clear();
            await this.session.refresh();
        }
        catch (error) {
            this.error.set(error instanceof ApiError ? Object.values(error.problem.errors ?? {}).flat().join(' ') || error.message : error instanceof Error ? error.message : 'Unable to change password.');
        }
        finally {
            this.clear();
            this.busy.set(false);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPasswordChange, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasPasswordChange, isStandalone: true, selector: "bqatlas-password-change", outputs: { closed: "closed" }, ngImport: i0, template: `<section class="bqatlas-view" aria-label="Change password"><h2>Change password</h2>
    <p>You will sign in again after changing your password.</p>
    @if(error()){<p role="alert">{{error()}}</p>}
    <form (ngSubmit)="submit()" class="bqatlas-form"><fieldset [disabled]="busy()">
      <label>Current password<input atlasInput type="password" autocomplete="current-password" name="currentPassword" required [(ngModel)]="currentPassword" /></label>
      <label>New password<input atlasInput type="password" autocomplete="new-password" name="newPassword" required minlength="12" [(ngModel)]="newPassword" /></label>
      <label>Confirm new password<input atlasInput type="password" autocomplete="new-password" name="confirmPassword" required [(ngModel)]="confirmation" /></label>
      <p>Use at least 12 characters, including uppercase, lowercase, a number and a symbol.</p>
      <button atlasButton type="submit" variant="primary">Change password</button>
      <button atlasButton type="button" (click)="cancel()">Cancel</button>
    </fieldset></form></section>`, isInline: true, dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasPasswordChange, decorators: [{
            type: Component,
            args: [{
                    selector: 'bqatlas-password-change', imports: [FormsModule, AtlasButton, AtlasInput], changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `<section class="bqatlas-view" aria-label="Change password"><h2>Change password</h2>
    <p>You will sign in again after changing your password.</p>
    @if(error()){<p role="alert">{{error()}}</p>}
    <form (ngSubmit)="submit()" class="bqatlas-form"><fieldset [disabled]="busy()">
      <label>Current password<input atlasInput type="password" autocomplete="current-password" name="currentPassword" required [(ngModel)]="currentPassword" /></label>
      <label>New password<input atlasInput type="password" autocomplete="new-password" name="newPassword" required minlength="12" [(ngModel)]="newPassword" /></label>
      <label>Confirm new password<input atlasInput type="password" autocomplete="new-password" name="confirmPassword" required [(ngModel)]="confirmation" /></label>
      <p>Use at least 12 characters, including uppercase, lowercase, a number and a symbol.</p>
      <button atlasButton type="submit" variant="primary">Change password</button>
      <button atlasButton type="button" (click)="cancel()">Cancel</button>
    </fieldset></form></section>`,
                }]
        }], propDecorators: { closed: [{ type: i0.Output, args: ["closed"] }] } });

/** Consume once before application startup. Never retain recovery credentials in browser history. */
function consumeAccountRecoveryLink(location, history) {
    const url = new URL(location.href);
    const action = url.searchParams.get('accountAction');
    const userId = url.searchParams.get('userId');
    const token = url.searchParams.get('token');
    if (['accountAction', 'userId', 'token'].some(key => url.searchParams.has(key))) {
        for (const key of ['accountAction', 'userId', 'token'])
            url.searchParams.delete(key);
        history.replaceState(history.state, '', url.pathname + url.search + url.hash);
    }
    return (action === 'reset' || action === 'confirm') && userId && userId.length <= 256 && token && token.length <= 8192 ? { action, userId, token } : null;
}
class AtlasAccountRecovery {
    api = inject(AtlasApi);
    session = inject(AtlasSession);
    link = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "link" }] : /* istanbul ignore next */ []));
    closed = output();
    consumed = output();
    mode = signal('reset', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    busy = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []));
    done = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "done" }] : /* istanbul ignore next */ []));
    message = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    error = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    email = '';
    password = '';
    confirmation = '';
    abort = new AbortController();
    ngOnDestroy() { this.abort.abort(); this.clear(); }
    close() { if (this.busy())
        return; this.clear(); this.closed.emit(); }
    toggleMode() { this.mode.update(mode => mode === 'reset' ? 'confirm' : 'reset'); this.message.set(''); this.error.set(''); }
    clear() { this.password = ''; this.confirmation = ''; }
    async submit() {
        if (this.busy() || this.done())
            return;
        const link = this.link();
        this.error.set('');
        if (link?.action === 'reset' && (!this.password || this.password !== this.confirmation)) {
            this.error.set('Enter matching new passwords.');
            return;
        }
        if (!link && !this.email.trim()) {
            this.error.set('Enter your email address.');
            return;
        }
        this.busy.set(true);
        try {
            if (link) {
                await this.api.request(link.action === 'reset' ? '/auth/reset-password' : '/auth/confirm-email', 'POST', link.action === 'reset' ? { userId: link.userId, token: link.token, newPassword: this.password } : { userId: link.userId, token: link.token }, this.abort.signal);
                if (link.action === 'reset')
                    this.session.clear();
                this.consumed.emit();
                this.message.set(link.action === 'reset' ? 'Your password has been reset. Sign in with your new password.' : 'Your email has been confirmed. You can now sign in.');
            }
            else {
                await this.api.request(this.mode() === 'reset' ? '/auth/request-password-reset' : '/auth/request-confirmation', 'POST', { email: this.email.trim() }, this.abort.signal);
                this.message.set('If the account is eligible, an email has been sent. Check your inbox.');
            }
            this.done.set(true);
        }
        catch (error) {
            if (!this.abort.signal.aborted)
                this.error.set(error instanceof Error ? error.message : 'Unable to complete this request.');
        }
        finally {
            this.clear();
            this.busy.set(false);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAccountRecovery, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.7", type: AtlasAccountRecovery, isStandalone: true, selector: "bqatlas-account-recovery", inputs: { link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed", consumed: "consumed" }, ngImport: i0, template: `<section aria-label="Account recovery">
    <h2>{{link()?.action==='confirm'?'Confirm your email':link()?'Reset your password':mode()==='confirm'?'Request a confirmation email':'Forgot your password?'}}</h2>
    @if(message()){<p role="status">{{message()}}</p>}
    @if(error()){<p role="alert">{{error()}}</p>}
    @if(!done()){
      <form (ngSubmit)="submit()"><fieldset [disabled]="busy()">
        @if(!link()){
          <label>Email address<input atlasInput type="email" autocomplete="email" name="recoveryEmail" required maxlength="254" [(ngModel)]="email" /></label>
        } @else if(link()?.action==='reset'){
          <label>New password<input atlasInput type="password" autocomplete="new-password" name="newPassword" required minlength="12" maxlength="1024" [(ngModel)]="password" /></label>
          <label>Confirm password<input atlasInput type="password" autocomplete="new-password" name="confirmPassword" required [(ngModel)]="confirmation" /></label>
          <p>Use at least 12 characters, including uppercase, lowercase, a number and a symbol.</p>
        } @else {<p>Confirm ownership of the email address associated with this link.</p>}
        <button atlasButton variant="primary" type="submit">{{busy()?'Please wait…':link()?.action==='confirm'?'Confirm email':link()?'Reset password':'Send email'}}</button>
      </fieldset></form>
      @if(!link()) {<button atlasButton type="button" [disabled]="busy()" (click)="toggleMode()">{{mode()==='reset'?'Need a confirmation email?':'Forgot password?'}}</button>}
    }
    <button atlasButton type="button" [disabled]="busy()" (click)="close()">Return to sign in</button>
  </section>`, isInline: true, styles: ["fieldset{border:0;padding:0;margin:0}button{margin-top:.75rem}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: AtlasButton, selector: "button[atlasButton], a[atlasButton]", inputs: ["variant"] }, { kind: "directive", type: AtlasInput, selector: "input[atlasInput], textarea[atlasInput], select[atlasInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.7", ngImport: i0, type: AtlasAccountRecovery, decorators: [{
            type: Component,
            args: [{ selector: 'bqatlas-account-recovery', imports: [FormsModule, AtlasButton, AtlasInput], changeDetection: ChangeDetectionStrategy.OnPush, template: `<section aria-label="Account recovery">
    <h2>{{link()?.action==='confirm'?'Confirm your email':link()?'Reset your password':mode()==='confirm'?'Request a confirmation email':'Forgot your password?'}}</h2>
    @if(message()){<p role="status">{{message()}}</p>}
    @if(error()){<p role="alert">{{error()}}</p>}
    @if(!done()){
      <form (ngSubmit)="submit()"><fieldset [disabled]="busy()">
        @if(!link()){
          <label>Email address<input atlasInput type="email" autocomplete="email" name="recoveryEmail" required maxlength="254" [(ngModel)]="email" /></label>
        } @else if(link()?.action==='reset'){
          <label>New password<input atlasInput type="password" autocomplete="new-password" name="newPassword" required minlength="12" maxlength="1024" [(ngModel)]="password" /></label>
          <label>Confirm password<input atlasInput type="password" autocomplete="new-password" name="confirmPassword" required [(ngModel)]="confirmation" /></label>
          <p>Use at least 12 characters, including uppercase, lowercase, a number and a symbol.</p>
        } @else {<p>Confirm ownership of the email address associated with this link.</p>}
        <button atlasButton variant="primary" type="submit">{{busy()?'Please wait…':link()?.action==='confirm'?'Confirm email':link()?'Reset password':'Send email'}}</button>
      </fieldset></form>
      @if(!link()) {<button atlasButton type="button" [disabled]="busy()" (click)="toggleMode()">{{mode()==='reset'?'Need a confirmation email?':'Forgot password?'}}</button>}
    }
    <button atlasButton type="button" [disabled]="busy()" (click)="close()">Return to sign in</button>
  </section>`, styles: ["fieldset{border:0;padding:0;margin:0}button{margin-top:.75rem}\n"] }]
        }], propDecorators: { link: [{ type: i0.Input, args: [{ isSignal: true, alias: "link", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }], consumed: [{ type: i0.Output, args: ["consumed"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ApiError, AtlasAccountRecovery, AtlasApi, AtlasDecimalTextInput, AtlasMenu, AtlasMenus, AtlasNavigation, AtlasPasswordChange, AtlasSession, CrudEditor, CrudList, CrudWorkspace, ODataResourceProvider, RecordDraft, ReferenceLookup, RestLookupProvider, RestResourceProvider, consumeAccountRecoveryLink, editableValues, parseWorkspaceRoute, selectListFields, validateFields, validateMenu, visibleMenu, workspaceHash };
//# sourceMappingURL=bqatlas-angular.mjs.map
