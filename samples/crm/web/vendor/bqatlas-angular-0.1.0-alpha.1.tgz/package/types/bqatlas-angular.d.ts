import * as _bqatlas_contracts from '@bqatlas/contracts';
import { ProblemDetails, QueryRequest, PageResult, ResourceProvider, RecordResult, SessionInfo, ApplicationManifest, RecordCapabilities, FieldDescriptor, ResourceDescriptor, LookupProvider } from '@bqatlas/contracts';
import * as _angular_core from '@angular/core';
import { Type, OnDestroy } from '@angular/core';
import { WorkspaceTask, WorkspaceService, AtlasColumn, AtlasTableQuery, AtlasLookupColumn, AtlasValueControl } from '@bqatlas/ui';
import { Validator, AbstractControl, ValidationErrors } from '@angular/forms';

declare class ApiError extends Error {
    readonly status: number;
    readonly problem: ProblemDetails;
    constructor(status: number, problem: ProblemDetails);
}
declare class AtlasApi {
    private csrf?;
    private generation;
    onUnauthorized: () => void;
    clearSession(): void;
    request<T>(path: string, method?: string, body?: unknown, signal?: AbortSignal, version?: string, idempotencyKey?: string, accept?: string): Promise<T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasApi, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}
declare class RestResourceProvider<T, TInput = Partial<T>> implements ResourceProvider<T, TInput> {
    private readonly api;
    private readonly endpoint;
    constructor(api: AtlasApi, endpoint: string);
    query(query: QueryRequest, signal?: AbortSignal): Promise<PageResult<T>>;
    get(id: string, signal?: AbortSignal): Promise<RecordResult<T>>;
    create(input: TInput, signal?: AbortSignal): Promise<RecordResult<T>>;
    update(id: string, input: TInput, version: string, signal?: AbortSignal): Promise<RecordResult<T>>;
    delete(id: string, version: string, signal?: AbortSignal): Promise<void>;
}
declare class RestLookupProvider<T> {
    private readonly api;
    private readonly endpoint;
    resolve(id: string, signal?: AbortSignal): Promise<T | null>;
    constructor(api: AtlasApi, endpoint: string);
    query(request: QueryRequest, signal?: AbortSignal): Promise<PageResult<T>>;
}

declare class AtlasSession {
    private readonly api;
    private generation;
    private readonly workspace;
    readonly info: _angular_core.WritableSignal<SessionInfo | null>;
    readonly manifest: _angular_core.WritableSignal<ApplicationManifest | null>;
    readonly authenticated: _angular_core.Signal<boolean>;
    constructor();
    has(permission: string): boolean;
    refresh(): Promise<void>;
    login(email: string, password: string): Promise<void>;
    logout(): Promise<void>;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasSession, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}

/** Each editor owns one draft; saved values never share mutable references with the draft. */
declare class RecordDraft<T extends object> {
    readonly value: _angular_core.WritableSignal<T>;
    readonly version: _angular_core.WritableSignal<string | null>;
    readonly dirty: _angular_core.WritableSignal<boolean>;
    readonly capabilities: _angular_core.WritableSignal<RecordCapabilities | null>;
    private saved?;
    accept(result: RecordResult<T>): void;
    initialize(value: T): void;
    change<K extends keyof T>(key: K, value: T[K]): void;
    revert(): void;
}

type FieldValidator = (value: unknown, row: Readonly<Record<string, unknown>>, field: Readonly<FieldDescriptor>) => readonly string[];
type FieldValidators = Readonly<Record<string, FieldValidator>>;
/** Validates drafts without coercing money or timezone-free dates. Server validation remains authoritative. */
declare function validateFields(fields: readonly FieldDescriptor[], row: Record<string, unknown>, validators?: FieldValidators): Record<string, string[]>;
declare function editableValues(fields: readonly FieldDescriptor[], row: Record<string, unknown>): Record<string, unknown>;

interface FieldRendererContext {
    controlId: string;
    errorId: string;
    field: Readonly<FieldDescriptor>;
    value: unknown;
    row: Readonly<Record<string, unknown>>;
    disabled: boolean;
    errors: readonly string[];
    change: (value: unknown) => void;
}
interface CrudFeature {
    resource: string;
    title: string;
    icon: string;
    writePermission: string;
    deletePermission: string;
    defaults: Record<string, unknown>;
    /** Optional list field order; forms continue to use the resource descriptor. */
    listFields?: readonly string[];
    fieldRenderers?: Readonly<Record<string, Type<unknown>>>;
    fieldValidators?: FieldValidators;
    /** Trusted application code selects transport; server metadata never executes code. */
    provider?: (api: AtlasApi, descriptor: ResourceDescriptor) => ResourceProvider<Record<string, unknown>, Record<string, unknown>>;
    listComponent?: Type<unknown>;
    editorComponent?: Type<unknown>;
}
declare function selectListFields(descriptor: ResourceDescriptor, names?: readonly string[]): readonly FieldDescriptor[];
type Row = Record<string, unknown>;
interface EditorTask {
    resource: string;
    id?: string;
    relation?: string;
    defaults?: Row;
}
declare class CrudWorkspace {
    private readonly workspace;
    private readonly session;
    private readonly definitions;
    readonly revision: _angular_core.WritableSignal<number>;
    private readonly returns;
    openRelated(resource: string, origin: string, selected: (id: string) => Promise<void>, id?: string, defaults?: Row): {
        task: WorkspaceTask<EditorTask>;
        cancel: () => void;
    };
    cancelRelated(id: string): void;
    returnRelated(relation: string, id: string): Promise<void>;
    constructor();
    register(...features: CrudFeature[]): void;
    feature(id: string): CrudFeature;
    descriptor(id: string): ResourceDescriptor;
    menus(): CrudFeature[];
    openList(resource: string): void;
    openEditor(resource: string, id?: string, origin?: string, defaults?: Row): void;
    changed(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrudWorkspace, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}
declare class CrudList {
    readonly task: WorkspaceTask<{
        resource: string;
    }>;
    readonly crud: CrudWorkspace;
    readonly session: AtlasSession;
    readonly descriptor: ResourceDescriptor;
    readonly feature: CrudFeature;
    private readonly provider;
    readonly columns: AtlasColumn<Row>[];
    readonly rows: _angular_core.WritableSignal<Row[]>;
    readonly total: _angular_core.WritableSignal<number>;
    readonly loading: _angular_core.WritableSignal<boolean>;
    readonly error: _angular_core.WritableSignal<string>;
    private request;
    private controller?;
    private timer?;
    constructor();
    query(value: AtlasTableQuery): void;
    reload(): Promise<void>;
    create(): void;
    open(row: Row): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrudList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrudList, "bqatlas-crud-list", never, {}, {}, never, never, true, never>;
}
declare class CrudEditor {
    private readonly element;
    private readonly injector;
    private focusError;
    readonly task: WorkspaceTask<EditorTask>;
    readonly crud: CrudWorkspace;
    readonly session: AtlasSession;
    readonly workspace: WorkspaceService;
    readonly descriptor: ResourceDescriptor;
    readonly feature: CrudFeature;
    readonly draft: RecordDraft<Row>;
    readonly loading: _angular_core.WritableSignal<boolean>;
    readonly errors: _angular_core.WritableSignal<Record<string, string[]>>;
    readonly canWrite: _angular_core.Signal<boolean>;
    private readonly provider;
    readonly canDelete: _angular_core.Signal<boolean>;
    private readonly controller;
    readonly returning: _angular_core.WritableSignal<boolean>;
    id: string | undefined;
    saveAndReturn(): Promise<void>;
    constructor();
    fieldRenderer(name: string): Type<unknown> | null;
    fieldContext(field: FieldDescriptor): FieldRendererContext;
    change(key: string, value: unknown): void;
    reload(): Promise<void>;
    private load;
    save(): Promise<boolean>;
    saveShortcut(event: Event): void;
    private persist;
    remove(): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrudEditor, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrudEditor, "bqatlas-crud-editor", never, {}, {}, never, never, true, never>;
}

declare class ReferenceLookup<T> {
    private readonly crud;
    private readonly session;
    private readonly workspace;
    private readonly parent;
    private readonly host;
    readonly resource: _angular_core.InputSignal<string | undefined>;
    readonly nameField: _angular_core.InputSignal<string>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    /** Change when parent eligibility context changes; prevents late child selection. */
    readonly contextKey: _angular_core.InputSignal<string>;
    readonly pickerOpen: _angular_core.WritableSignal<boolean>;
    readonly relationError: _angular_core.WritableSignal<string>;
    readonly resolvedCaption: _angular_core.WritableSignal<string>;
    private revision;
    private alive;
    private readonly children;
    private readonly controller;
    readonly canOpen: _angular_core.Signal<boolean>;
    readonly canCreate: _angular_core.Signal<boolean>;
    readonly actions: _angular_core.Signal<{
        id: string;
        label: string;
    }[]>;
    cell(row: T, key: keyof T): string;
    select(row: T | null): void;
    runAction(action: {
        id: string;
        query: string;
    }): void;
    openRelated(create: boolean): void;
    readonly provider: _angular_core.InputSignal<LookupProvider<T>>;
    readonly columns: _angular_core.InputSignal<readonly AtlasLookupColumn<T>[]>;
    readonly recordKey: _angular_core.InputSignal<(row: T) => string>;
    readonly displayWith: _angular_core.InputSignal<(row: T) => string>;
    readonly controlId: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly selectedText: _angular_core.InputSignal<string>;
    readonly describedBy: _angular_core.InputSignal<string | undefined>;
    readonly value: _angular_core.ModelSignal<string | null>;
    readonly recordSelected: _angular_core.OutputEmitterRef<T | null>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly rows: _angular_core.WritableSignal<T[]>;
    readonly page: _angular_core.WritableSignal<number>;
    readonly total: _angular_core.WritableSignal<number>;
    readonly loading: _angular_core.WritableSignal<boolean>;
    readonly error: _angular_core.WritableSignal<string>;
    readonly pageSize = 20;
    private readonly request;
    query: string;
    private timer?;
    constructor();
    search(query: string): void;
    load(page: number): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReferenceLookup<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ReferenceLookup<any>, "bqatlas-reference-lookup", never, { "resource": { "alias": "resource"; "required": false; "isSignal": true; }; "nameField": { "alias": "nameField"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "contextKey": { "alias": "contextKey"; "required": false; "isSignal": true; }; "provider": { "alias": "provider"; "required": true; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "recordKey": { "alias": "recordKey"; "required": true; "isSignal": true; }; "displayWith": { "alias": "displayWith"; "required": true; "isSignal": true; }; "controlId": { "alias": "controlId"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "selectedText": { "alias": "selectedText"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "recordSelected": "recordSelected"; }, never, never, true, never>;
}

/** A string-valued CVA for exact amounts. Invalid draft text is preserved for correction. */
declare class AtlasDecimalTextInput extends AtlasValueControl<string> implements Validator {
    readonly required: _angular_core.InputSignal<boolean>;
    readonly sheetEditor: _angular_core.InputSignal<boolean>;
    readonly scale: _angular_core.InputSignal<number>;
    readonly maximum: _angular_core.InputSignal<string | undefined>;
    readonly invalidText: _angular_core.Signal<boolean>;
    edit(value: string): void;
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasDecimalTextInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasDecimalTextInput, "bqatlas-decimal-input", never, { "required": { "alias": "required"; "required": false; "isSignal": true; }; "sheetEditor": { "alias": "sheetEditor"; "required": false; "isSignal": true; }; "scale": { "alias": "scale"; "required": false; "isSignal": true; }; "maximum": { "alias": "maximum"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface ODataField {
    /** Public EDM property name, never an arbitrary OData expression. */
    property: string;
    type: 'string' | 'boolean' | 'integer' | 'decimal' | 'date' | 'guid';
}
interface ODataQueryOptions<TWire, T> {
    fields: Readonly<Record<string, ODataField>>;
    key: string;
    searchFields?: readonly string[];
    map: (record: TWire) => T;
}
/** Read OData DTOs while retaining the application's REST ETag and command semantics. */
declare class ODataResourceProvider<T, TInput = Partial<T>, TWire = T> implements ResourceProvider<T, TInput> {
    private readonly api;
    private readonly endpoint;
    private readonly records;
    private readonly options;
    constructor(api: AtlasApi, endpoint: string, records: ResourceProvider<T, TInput>, options: ODataQueryOptions<TWire, T>);
    private field;
    query(request: QueryRequest, signal?: AbortSignal): Promise<PageResult<T>>;
    get(id: string, signal?: AbortSignal): Promise<_bqatlas_contracts.RecordResult<T>>;
    create(input: TInput, signal?: AbortSignal): Promise<_bqatlas_contracts.RecordResult<T>>;
    update(id: string, input: TInput, version: string, signal?: AbortSignal): Promise<_bqatlas_contracts.RecordResult<T>>;
    delete(id: string, version: string, signal?: AbortSignal): Promise<void>;
}

type MenuNode = {
    id: string;
    label: string;
    labelKey?: string;
    order?: number;
    permission?: string;
} & ({
    kind: 'group';
    children: readonly MenuNode[];
} | {
    kind: 'resource';
    resource: string;
} | {
    kind: 'command';
    command: string;
});
interface MenuCommand {
    id: string;
    permission: string;
    run: () => void | Promise<void>;
}
declare function visibleMenu(nodes: readonly MenuNode[], permissions: ReadonlySet<string>, resources: ReadonlySet<string>, commands: ReadonlyMap<string, MenuCommand>): MenuNode[];
declare function validateMenu(nodes: readonly MenuNode[]): void;
declare class AtlasMenus {
    private readonly session;
    private readonly crud;
    private readonly nodes;
    private readonly commands;
    register(...nodes: MenuNode[]): void;
    registerCommand(command: MenuCommand): void;
    visible(): MenuNode[];
    activate(id: string): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasMenus, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}

declare class AtlasMenu {
    readonly menus: AtlasMenus;
    readonly translate: _angular_core.InputSignal<(key: string, fallback: string) => string>;
    readonly pending: _angular_core.WritableSignal<string | null>;
    readonly error: _angular_core.WritableSignal<string>;
    text(key: string | undefined, fallback: string): string;
    activate(id: string): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasMenu, "bqatlas-menu", never, { "translate": { "alias": "translate"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type WorkspaceRoute = {
    kind: 'home';
} | {
    kind: 'list';
    resource: string;
} | {
    kind: 'record';
    resource: string;
    id: string;
} | {
    kind: 'draft';
    task: string;
};
declare function parseWorkspaceRoute(hash: string): WorkspaceRoute;
declare function workspaceHash(route: WorkspaceRoute): string;
/** Hash routes keep API hosting simple. Back switches retained views; it never discards a task. */
declare class AtlasNavigation {
    private readonly session;
    private readonly crud;
    private readonly workspace;
    readonly error: _angular_core.WritableSignal<string>;
    private initialized;
    private hadSession;
    private lastHash;
    private readonly storageKey;
    constructor();
    private remember;
    private remembered;
    private replace;
    private restore;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasNavigation, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}

declare class AtlasPasswordChange {
    private readonly api;
    private readonly session;
    private readonly workspace;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly busy: _angular_core.WritableSignal<boolean>;
    readonly error: _angular_core.WritableSignal<string>;
    currentPassword: string;
    newPassword: string;
    confirmation: string;
    cancel(): void;
    private clear;
    submit(): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasPasswordChange, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasPasswordChange, "bqatlas-password-change", never, {}, { "closed": "closed"; }, never, never, true, never>;
}

interface AccountRecoveryLink {
    action: 'reset' | 'confirm';
    userId: string;
    token: string;
}
/** Consume once before application startup. Never retain recovery credentials in browser history. */
declare function consumeAccountRecoveryLink(location: Pick<Location, 'href'>, history: Pick<History, 'state' | 'replaceState'>): AccountRecoveryLink | null;
declare class AtlasAccountRecovery implements OnDestroy {
    private readonly api;
    private readonly session;
    readonly link: _angular_core.InputSignal<AccountRecoveryLink | null>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly consumed: _angular_core.OutputEmitterRef<void>;
    readonly mode: _angular_core.WritableSignal<"reset" | "confirm">;
    readonly busy: _angular_core.WritableSignal<boolean>;
    readonly done: _angular_core.WritableSignal<boolean>;
    readonly message: _angular_core.WritableSignal<string>;
    readonly error: _angular_core.WritableSignal<string>;
    email: string;
    password: string;
    confirmation: string;
    private readonly abort;
    ngOnDestroy(): void;
    close(): void;
    toggleMode(): void;
    private clear;
    submit(): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtlasAccountRecovery, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtlasAccountRecovery, "bqatlas-account-recovery", never, { "link": { "alias": "link"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "consumed": "consumed"; }, never, never, true, never>;
}

export { ApiError, AtlasAccountRecovery, AtlasApi, AtlasDecimalTextInput, AtlasMenu, AtlasMenus, AtlasNavigation, AtlasPasswordChange, AtlasSession, CrudEditor, CrudList, CrudWorkspace, ODataResourceProvider, RecordDraft, ReferenceLookup, RestLookupProvider, RestResourceProvider, consumeAccountRecoveryLink, editableValues, parseWorkspaceRoute, selectListFields, validateFields, validateMenu, visibleMenu, workspaceHash };
export type { AccountRecoveryLink, CrudFeature, EditorTask, FieldRendererContext, FieldValidator, FieldValidators, MenuCommand, MenuNode, ODataField, ODataQueryOptions, WorkspaceRoute };
//# sourceMappingURL=bqatlas-angular.d.ts.map
